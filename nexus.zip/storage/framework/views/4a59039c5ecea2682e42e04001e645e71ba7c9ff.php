
<?php $__env->startSection('content'); ?>

    <div class="main-wrapper">
        <!-- /Sidebar -->
        <!-- Page Wrapper -->
        <div class="page-wrapper">
            <!-- Page Content -->
            <div class="content container-fluid">
                <div class="page-header my-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title bold-heading">CSR No Of Leads</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">CSR No Of Leads</li>
                            </ul>
                        </div>

                    </div>
                </div>

                <!-- Search Filter -->
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(url('csr-no-of-leads')); ?>" id="searchForm">
                            <input type="hidden" name="search" value="1">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">CSR</label>
                                        <select name="agent_id" class="form-control selectpicker" data-container="body"
                                                data-live-search="true">
                                            <option value="" selected >Choose CSR</option>
                                            <?php if(isset($data)): ?>
                                                <?php $__currentLoopData = $data['csr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $csr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($csr->account_id); ?>"><?php echo e($csr->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <label for="">From</label>
                                    <input type="date" class="form-control" name="from_date" required/>
                                </div>

                                <div class="col-md-3">
                                    <label for="">To</label>
                                    <input type="date" class="form-control" name="to_date" required/>
                                </div>

                                <div class="col-md-1">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary" id="btn-search" style="margin-top: 30px"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
                <!-- Search Filter -->
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped table-hover">
                            <thead>

                                <tr>
                                    <th>SR#</th>
                                    <th>CSR</th>
                                    <th>Total Leads</th>
                                </tr>
                            </thead>
                            <tbody id="csrTable">
                            <?php $c=0 ?>
                            <?php if(isset($data['csrLeads'])): ?>
                                <?php $__currentLoopData = $data['csrLeads']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $c++ ?>
                            <tr>
                                <td><?php echo e($c); ?></td>
                                <td><?php echo e($row['name']); ?>

                                </td>

                                <td><?php echo e($row['totalLeads']); ?></td>
                                <td><a href="<?php echo e(url('csr-leads').'/'.$row['emp_id'].'/'.$data['from_date'].'/'.$data['to_date']); ?>"><i class="fa fa-eye"></i></a></td>

                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /Page Content -->
        </div>
    </div>


    <div id="temp_wise_leads" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            id="modalDismiss">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="card flex-fill dash-statistics">
                        <div class="card-body">

                            <div id="tempArea">
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    <script>
        $(document).ready(function() {

            $('.date_range').daterangepicker({
                opens: 'left'
            }, function(start, end, label) {
                console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end
                    .format('YYYY-MM-DD'));
            });

            $('#csrTable').on('click', '.btn-view-temp', function() {
                var csr_id = $(this).attr('csr-id');

                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '<?php echo e(url("csr-performance")); ?>',
                    data: {agent_id:csr_id},
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {
                        $(".btn-view-temp").prop("disabled", true);
                        $(".btn-view-temp").html("loading...");

                        },
                    success: function(data) {
                        var html = '';
                        var i;
                        if(data.length > 0) {
                            for (i = 0; i < data.length; i++) {
                                html += '<p><i class="fa fa-dot-circle-o text-success mr-2"></i>' + data[i].temp + '<span class="float-right">' + data[i].totalLeads + '</span></p>';
                            }
                        }
                        else
                            {
                                html += '<p><i class="fa fa-dot-circle-o text-danger mr-2"></i>Not work any lead</span></p>';
                        }
                        $('#tempArea').html(html);

                    },
                    complete : function(data){
                        $(".btn-view-temp").html("view Temp ");
                        $(".btn-view-temp").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },

                });
            });


                //search filter
            $('#searchForm1').unbind().on('submit', function(e) {
                e.preventDefault();

                var formData = $('#searchForm').serialize();
                var date_range=$('input[name=date_range]').val();
                alert(formData);

                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("save-leads-status")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {

                        $(".btnSubmit").prop("disabled", true);
                        $(".btnSubmit").html("loading...");

                    },
                    success: function(data) {

                        if (data.success) {
                            $('.close').click();
                            $('#LeadForm')[0].reset();
                            toastr.success(data.success);
                            window.location.reload();

                        }
                        if (data.errors) {

                            toastr.error(data.errors);
                            //toastr.error('missing some fileds');

                        }
                    },

                    complete : function(data){
                        $("#btnSubmit").html("Save");
                        $("#btnSubmit").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },

                });


            });


        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u443729190/domains/shahraantech.com/public_html/rgms/resources/views/call-center/reports/csr-no-of-leads.blade.php ENDPATH**/ ?>