
<?php $__env->startSection('content'); ?>
    <main id="main">
        <!-- ======= breadcrump section ======= -->
        <section class="intro-single">
            <div class="container-fluid ">
                <div class="row about-breadcrump text-center gx-0">
                    <div class="col-md-12">
                        <div class="title-single-box">
                            <h1 class="title-single text-white">
                                AUTHENTICATE FILE</h1>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active text-white-50" aria-current="page">
                                    Authenticate File
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!-- End breadcrump section-->
        <section class="authenticate-section">
            <div class="container">
                <div class="row">
                    <h1 class="text-center">Authenticate <span class="color-b">File</span></h1>
                    <div class="ass m-auto"></div>
                </div>
            </div>
        </section>
        <section class="search-section mt-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-12 text-center">
                        <h2 class="text-black">Beware Of <span class="colo-b">Frauds</span></h2>
                        <p class="mt-4">Please follow the instructions given below to verify your file</p>

                    </div>
                </div>
                <form action="<?php echo e(url('authenticate-file')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row justify-content-center">

                        <div class="col-md-7 mt-3">
                            <input class="form-search form-control" name="file_no" type="text"
                                placeholder="Enter The Authentication....." required>
                        </div>
                        <div class="col-md-2 text-center text-md-start mt-3">
                            <button class=" btn btn-search form-control" type="submit"><i
                                    class="bi bi-search"></i></button>
                        </div>

                    </div>
                </form>
                <div class="row mt-5">

                    <div class="table-responsive">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-bordered border-color">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">ID</th>
                                    <th scope="col">Plot Size</th>
                                    <th scope="col">Plot Type</th>
                                    <th scope="col">Name Of Purchaser</th>
                                    <th scope="col">Purchase Date</th>
                                </tr>
                            </thead>

                            <?php if(isset($data['files'])): ?>
                                <tr>
                                    <td><?php echo e(1); ?></td>
                                    <td><?php echo e($data['files']->reg_no); ?></td>
                                    <td><?php echo e($data['files']->products['item']); ?></td>
                                    <td><?php echo e($data['files']->type); ?></td>
                                    <td>
                                        <?php
                                            $purDate = '-';
                                        ?>
                                        <?php if($data['files']->dealer_id > 0): ?>
                                            <?php
                                                $purDate = $data['files']->updated_at;
                                                echo $dealerName = App\Models\Dealer::getAllDealerName(1);
                                            ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($purDate); ?></td>
                                </tr>
                            <?php endif; ?>
                        </table>

                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posch-city\resources\views/web-side/authenticate-file.blade.php ENDPATH**/ ?>