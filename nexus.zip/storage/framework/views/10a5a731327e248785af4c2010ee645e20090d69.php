
<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        table
        {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th
        {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th, table td
        {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Purchase</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Purchase</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="<?php echo e(url('/purchase-list')); ?>" class="btn add-btn" title="Products List"><i class="fa fa-list" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="card">
                <form action="<?php echo e(url('purchase')); ?>" method="post" id="purchaseForm" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="d-flex">
                                    <label for="" class="mr-2">Venords</label>
                                    <span class="text-danger">*</span>
                                    <select class="livesearch form-control p-3" name="vendor_id" required>
                                        <option value="">Choose One</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please choose vendor.
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-md-1 mt-4">
                               </div> -->
                            <div class="col-md-6">
                                <div class="d-flex flex-row">
                                    <label for="" class="mr-2"> Date</label>
                                    <span class="text-danger">*</span>
                                    <input type="date" class="form-control ml-5" name="pur_date" required value="<?php echo e(date('d-m-Y')); ?>"/>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="d-flex">
                                    <label for="" class="mr-2">INV#</label>
                                    <span class="text-danger">*</span>
                                    <input type="text" class="form-control" value="<?php echo e($data['invNo']); ?>" readonly >
                                </div>
                            </div>
                            <!-- <div class="col-md-1 mt-4">
                               </div> -->
                            <div class="col-md-6">
                                <div class="d-flex flex-row">
                                    <label for="" class="mr-2"> Comments</label>
                                    <input type="text" class="form-control ml-5" name="comments" placeholder="Comments" name="comments">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <!-- tabel start -->
                            <table class="table table-bordered mt-5 table-style">
                                <thead>
                                <tr>
                                    <th>Items <span class="text-danger">*</span></th>
                                    <th>Item Unit <span class="text-danger">*</span></th>
                                    <th>Size<span class="text-danger">*</span></th>
                                    <th>Qty <span class="text-danger">*</span></th>
                                    <th>Price <span class="text-danger">*</span></th>
                                    <th>Sale Price <span class="text-danger">*</span></th>
                                    <th>Total </th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody id="tblPurchase">
                                <tr>
                                    <td>
                                        <select name="item_id[]" id="" class="form-control item-id" required>
                                            <option value="">Choose Item</option>
                                            <?php if(isset($data['products'])): ?>
                                                <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </td>
                                    <td><input type="text" class="form-control item-unit" placeholder="0.00" name="item_unit[]" required readonly></td>
                                    <td><input type="text" class="form-control size" placeholder="0.00" name="size[]" required readonly></td>
                                    <td><input type="number" class="form-control qty" placeholder="0.00" name="qty[]" required></td>
                                    <td><input type="number" class="form-control price" placeholder="0.00" name="price[]" required readonly></td>
                                    <td><input type="number" class="form-control sale-price" placeholder="0.00" name="sale_price[]" required></td>
                                    <td><input type="number" class="form-control total" placeholder="0.00" name="total[]" required ></td>
                                    <td><button type="button" class="btn-success" id="addNewRow"><i class="fa fa-plus"></i></button> </td>
                                </tr>
                                </tbody>
                                <tr>
                                    <td  colspan="5">
                                        <div class="float-right">Total Discount% :</div>
                                    </td>
                                    <td><input type="number" class="form-control" placeholder="0.00"></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td  colspan="5">
                                        <div class="float-right">Grand Total% :</div>
                                    </td>
                                    <td><input type="number" class="form-control grandTotal" placeholder="0.00" name="grand_total"></td>
                                    <td></td>
                                </tr>
                            </table>
                            &nbsp;&nbsp;
                            <button class="btn btn-primary">Submit</button>
                            <!-- tabel end -->
                        </div>
                    </div>
                </form>
            </div>
            <!-- /Page Content -->
            <script type="text/javascript">
                $(function () {
                    $('#addNewRow').on('click', function () {
                        var tr = $("#dvOrders").find("Table").find("TR:has(td)").clone();
                        console.log(tr);
                        $("#tblPurchase").append(tr);
                    });
                });
            </script>
            <div id="dvOrders" style="display:none">
                <table class="table table-bordered mt-5 table-style secondtable" >
                    <tr>
                        <td>
                            <select name="item_id[]" id="" class="form-control item-id" required>
                                <option value="">Choose Item</option>
                                <?php if(isset($data['products'])): ?>
                                    <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </td>
                        <td><input type="text" class="form-control item-unit" placeholder="0.00" name="item_unit[]" required readonly ></td>
                        <td><input type="text" class="form-control size" placeholder="0.00" name="size[]" required readonly></td>
                        <td><input type="number" class="form-control qty" placeholder="0.00" name="qty[]" required></td>
                        <td><input type="number" class="form-control price" placeholder="0.00" name="price[]" required readonly></td>
                        <td><input type="number" class="form-control sale-price" placeholder="0.00" name="sale_price[]" required></td>
                        <td><input type="number" class="form-control total" placeholder="0.00" name="total[]" required ></td>
                        <td style="color:red;cursor: pointer" class="delete-row" title="Remove"><i class="fa fa-trash"></i></td>
                    </tr>
                </table>
            </div>
        </div>
        <!--add dynamic row!-->
        <script>
            $(document).ready(function () {

                // Denotes total number of rows
                var rowIdx = 0;

                // jQuery button click event to remove a row.
                $('#tblPurchase').on('click', '.delete-row', function () {

                    // Getting all the rows next to the row
                    // containing the clicked button
                    var child = $(this).closest('tr').nextAll();

                    // Iterating across all the rows
                    // obtained to change the index
                    child.each(function () {

                        // Getting <tr> id.
                        var id = $(this).attr('id');

                        // Getting the <p> inside the .row-index class.
                        var idx = $(this).children('.row-index').children('p');

                        // Gets the row number from <tr> id.
                        var dig = parseInt(id.substring(1));

                        // Modifying row index.
                        idx.html(`Row ${dig - 1}`);

                        // Modifying row id.
                        $(this).attr('id', `R${dig - 1}`);
                    });

                    // Removing the current row.
                    $(this).closest('tr').remove();

                    // Decreasing total number of rows by 1.
                    rowIdx--;
                });

                $('.livesearch').select2({

                    ajax: {
                        url: '<?php echo e(url("get-vendors-name")); ?>',
                        dataType: 'json',
                        delay: 250,
                        processResults: function (data) {

                            return {
                                results: $.map(data, function (item) {
                                    return {
                                        text: item.name,
                                        id: item.id
                                    }
                                })
                            };
                        },
                        cache: true
                    }
                });
            });
        </script>


        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script type='text/javascript'>

            $(document).ready(function (){



                // calculation of current table

                $('#tblPurchase').on('change','.item-id', function() {
                    var item_id=$(this).val();

                    var $currentRow = $(this).closest('tr');

                    var price = $currentRow.find('.price').val();
                    var qty = $currentRow.find('.qty').val();



                    $.ajax({

                        type: 'ajax',

                        method: 'get',

                        url: '<?php echo e(url("/getProductInfo")); ?>',

                        data: {product_id: item_id},

                        async: false,

                        dataType: 'json',

                        success: function(data) {
                            $currentRow.find('.item-unit').val(data.unit);
                            $currentRow.find('.price').val(data.price);
                            $currentRow.find('.size').val(data.size);
                        },

                        error: function() {

                            alert('Could not get Data from Database');

                        }

                    });



                });


                $('#tblPurchase').on('keyup','.qty', function() {
                    var qty=$(this).val();

                    var $currentRow = $(this).closest('tr');
                    var price = $currentRow.find('.price').val();
                    var total = parseFloat(price) * parseFloat(qty);
                    $currentRow.find('.total').val(total);

                    // call grand total for calculation
                    grandTotal();


                });


                function  grandTotal(){
                    var grandTotal=0;
                    $(".total").each(function() {
                        var subTotal=$(this).val();
                        (subTotal)? grandTotal=parseFloat(grandTotal) + parseFloat(subTotal):'';

                    });

                    $('input[name=grand_total]').val(grandTotal);
                }

            })
        </script>


        <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
        <script>
            <?php if(count($errors) > 0): ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            toastr.error("<?php echo e($error); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>


            <?php if(Session::has('success')): ?>
            toastr.success("Purchase items save successfully");

            <?php endif; ?>

        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zaeem-code\resources\views/accounts/purchase/index.blade.php ENDPATH**/ ?>