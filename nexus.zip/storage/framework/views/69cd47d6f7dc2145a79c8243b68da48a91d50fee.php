

<?php $__env->startSection('content'); ?>
    <main id="main">

        <!-- ======= Intro Single ======= -->
        <section class="intro-single">
            <div class="container-fluid ">
                <div class="row about-breadcrump text-center gx-0">
                    <div class="col-md-12">
                        <div class="title-single-box">
                            <h1 class="title-single text-white">
                                ABOUT US</h1>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active text-white-50" aria-current="page">
                                    About
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="container mt-5">
                <div class="row">
                    <div class="col-md-6 about-img">
                        <img src="<?php echo e(asset('public/web-assets/img/about-thumb.png')); ?>" class="img-fluid" alt="">
                    </div>
                    <div class="mt-5 pt-5 col-md-6" style="font-size: 18px;">
                        <h1>Posh<span class="color-b">City</span></h1>
                        <p>
                            Al-Rafa'a Group (Pvt) Ltd is your perfect partner for all type of property solutions both in
                            residential
                            and commercial sector. We stand out in the crowd as a different real estate company, renowned
                            due to our honest, transparent, and credible dealings. OUR MISSION To be the priority for our
                            clients and associates in their quest of finding, buying, selling, and renting their properties.
                            Our mission is to assess and manage with absolute professionalism, our client's ancestral assets
                            and their multiple investments. OUR VISION To deliver trustworthy real estate listing services
                            that our customers can avail for generations. PROPERTY INVESTMENT CONSULTATION We provide
                            extensive property consultation services to investors of all categories in a continually
                            evolving real estate domain to hold or sell their valuable real estate asset by ensuring high
                            yield within estimated time. We ensure high-risk with more significant returns to more stable
                            projects with lower but dependable returns. PROPERTY LEGAL ADVICE We have a legal team
                            specialized in all matters relating to the real estate sale, purchase, rent and land issues. We
                            offer our clients, a professional, honest, and confidential legal advice. For more details,
                            tease visit www.alrafaagroup.corn </p>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Intro Single-->

        <!-- ======= About Section ======= -->
        <section class="section-about">
            <div class="container">
                <div class="row">
                    <!-- <div class="col-sm-12 position-relative mt-4">
                                    <div class="about-img-box">
                                      <img src="assets/img/3aad67_3390eaee28834a10b83279d5a3b5e6b7~mv2.jpg" alt="" class="img-fluid">
                                    </div>
                                    <div class="sinse-box">
                                      <h3 class="sinse-title text-black">POSHCITY
                                        <span></span>
                                        <br> Sinse 2017
                                      </h3>
                                      <p>Art & Creative</p>
                                    </div>
                                  </div> -->
                    <div class="col-md-12 section-t8 position-relative">
                        <div class="row ">
                            <div class="col-md-6 col-lg-5">
                                <img src="<?php echo e(asset('public/web-assets/img/chairman_al-rafaa-group.png')); ?>" alt=""
                                    class="img-fluid">
                            </div>
                            <div class="col-lg-1  d-none d-lg-block position-relative">
                                <div class="title-vertical d-flex justify-content-start">

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 section-md-t3">
                                <div class="title-box-d">
                                    <h3 class="title-d">Nasir
                                        <span class="color-d">Mehmood</span>
                                    </h3>
                                </div>
                                <span style="font-size: 22px;" class="color-text-a">Chairman's Message</span>
                                <p style="font-size: 18px;" class="color-text-a">
                                    Prominent Businessman, Social and Political figure Ch. Nasir Mahmood is Chairman & CEO
                                    of Al-Rafa'a Group (Pvt) Ltd. The Chairman believes that a successful business does not
                                    only depend upon money but a dedicated team is the most valuable asset who can lead it
                                    to the sky. Idea behind multiple real estate projects under the umbrella of Al-Rafa'a
                                    Group (Pvt) Ltd is to contribute in economic development of country by creating
                                    employment opportunities in our projects and to ensure secure investments of our
                                    customers.
                                    OUR ASSOCIATES
                                </p>
                                <p style="font-size: 18px;" class="color-text-a">
                                    By bringing innovation, style, and the highest possible return on investment in a
                                    sustainable way at
                                    all periods and ages, we are working tirelessly to serve and support our nation's real
                                    estate
                                    industry. Posh City will lead you to greater heights. Let us handle your future returns
                                    better than
                                    anyone else. Posh City will guide you along the journey with brilliance and competence.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4 justify-content-center  text-center text-lg-start">
                    <div class="col-12">
                        <h1><span class="color-b">OUR MISSION</span></h1>
                        <div class="ass m-auto m-lg-0"></div>
                    </div>
                    <div style="font-size: 18px;" class="col-md-6 col-lg-10 mt-2">
                        <p>To be the priority for our clients and associates in their quest of finding, buying, selling, and
                            renting their properties. Our mission is to assess and manage with absolute professionalism, our
                            client's ancestral assets and their multiple investments.</p>
                    </div>
                    <div class="col-lg-2 text-center text-lg-start">
                        
                    </div>
                </div>

                <div class="row mt-4 justify-content-center  text-center text-lg-start">
                    <div class="col-12">
                        <h1><span class="color-b">OUR VISION</span></h1>
                        <div class="ass m-auto m-lg-0"></div>
                    </div>
                    <div style="font-size: 18px;" class="col-md-6 col-lg-10 mt-2">
                        <p>To deliver trustworthy real estate listing services that our customers can avail for generations.
                        </p>
                    </div>
                    <div class="col-lg-2 text-center text-lg-start">
                        
                    </div>
                </div>

                <div class="row mt-4 justify-content-center  text-center text-lg-start">
                    <div class="col-12">
                        <h1><span class="color-b">PROPERTY INVESTMENT CONSULTATION</span></h1>
                        <div class="ass m-auto m-lg-0"></div>
                    </div>
                    <div style="font-size: 18px;" class="col-md-6 col-lg-10 mt-2">
                        <p>We provide extensive property consultation services to investors of all categories in a
                            continually evolving real estate domain to hold or sell their valuable real estate asset by
                            ensuring high yield within estimated time. We ensure high-risk with more significant returns to
                            more stable projects with lower but dependable returns. </p>
                    </div>
                    <div class="col-lg-2 text-center text-lg-start">
                        
                    </div>
                </div>


                <div class="row mt-4 justify-content-center  text-center text-lg-start">
                    <div class="col-12">
                        <h1><span class="color-b">PROPERTY LEGAL ADVICE</span></h1>
                        <div class="ass m-auto m-lg-0"></div>
                    </div>
                    <div style="font-size: 18px;" class="col-md-6 col-lg-10 mt-2">
                        <p>We have a legal team specialized in all matters relating to the real estate sale, purchase, rent
                            and land issues. We offer our clients, a professional, honest, and confidential legal advice.
                            For more details. </p>
                    </div>
                    <div class="col-lg-2 text-center text-lg-start">
                        
                    </div>
                </div>

            </div>
        </section>

    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posch-city\resources\views/web-side/about.blade.php ENDPATH**/ ?>