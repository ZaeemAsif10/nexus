<?php $__env->startSection('content'); ?>
<div class="page-wrapper" id="body">
    <style type="text/css">
        body {
            font-family: Arial;
            font-size: 10pt;
        }

        table {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }

        table th {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }

        table th,
        table td {
            padding: 5px;
            border: 1px solid #ccc;
            font-size: 10px;
        }

        #table-scroll {
            overflow: auto;
        }

        .salary {
            background-color: #000;
            padding: 10px 10px;
        }
    </style>
    <!-- Page Content -->
    <div class="content container-fluid">
        <div class="card">
            <div class="card-header">


                <div class="col-auto float-left mr-auto">
                    <form action="<?php echo e(url('salary-sheet')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row" style="display: flex">

                            <div class="col-md-4">
                            <div class="form-group">

                                <select name="company_id" class="form-control selectpicker" data-container="body" data-live-search="true" title="Choose Company">

                                    <?php if(isset($data)): ?>
                                    <?php $__currentLoopData = $data['companies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <select name="month" class="form-control">
                                        <option value="" selected disabled>Month</option>
                                        <option value="1">January</option>
                                        <option value="2">February</option>
                                        <option value="3">March</option>
                                        <option value="4">April</option>
                                        <option value="5">May</option>
                                        <option value="6">June</option>
                                        <option value="7">July</option>
                                        <option value="8">August</option>
                                        <option value="9">September</option>
                                        <option value="10">October</option>
                                        <option value="11">November</option>
                                        <option value="12">December</option>

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <select name="year" class="form-control ">
                                        <option value="" selected>Year</option>

                                        <option value="2021" >2021</option>
                                        <option value="2022" >2022</option>
                                        <option value="2023" >2023</option>
                                        <option value="2024" >2024</option>
                                        <option value="2025" >2025</option>

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-1">
                            <div class="form-group ml-2" style="margin-top:px">
                                <button type="submit" class="btn btn-success"><i class="fa fa-search"></i></button>
                            </div>
                            </div>
                        </div>

                    </form>

                </div>


                <div class="col-auto float-right ml-auto">
                    <div class="btn-group btn-group-sm">
                        <button type="submit" class="btn btn-white" id="printBtn"><i class="fa fa-print fa-lg"></i> Print</button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div id="table-scroll">
                    <table class="table table-bordered mt-3" id="tablePrint">
                        <thead>
                            <tr>
                                <th colspan="16">
                                    <h5 class="text-white mt-2 salary">SALARY SHEET OF <?php echo e(empty($data['company_name'])?'': strtoupper($data['company_name'])); ?> STAFF FOR THE MONTH OF <?php echo e(date('M Y')); ?></h5>
                                </th>
                            </tr>
                        </thead>
                        <tbody>

                        <tr>
                            <td>
                                <?php
                                     $month=$data['month'];
                                     $year=$data['year'];
                                    ?>

                            </td>

                        </tr>

                            <tr>
                                <td>Sr.</td>
                                <td>Name</td>
                                <td>Designation</td>
                                <td>Salary</td>
                                <td>Days Working</td>
                                <td>Working Days Salary</td>
                                <td>Mobile Allowance</td>
                                <td>Sales Commision</td>
                                <td>Total Salary</td>
                                <td>Tax Deduction</td>
                                <td>Eobi Deduction</td>
                                <td>Loan Deduction</td>
                                <td>Net Salary</td>
                                <td>Bank Account No.</td>
                                <td>Total Salary</td>
                                <td colspan="5">Remarks</td>
                            </tr>

                            <?php if(isset($data['depts'])): ?>
                            <?php $__currentLoopData = $data['depts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $subTotal=0;
                            $emp=getEmployeesAcordingDept($dept->id);
                            $c=0;
                            ?>
                            <?php if($emp->count() > 0): ?>
                            <tr>
                                <td colspan="16" class="font-weight-bold text-center"><?php echo e($dept->departments); ?></td>
                            </tr>
                            <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $c++;

                            ?>
                            <tr>
                                <td><?php echo e($c); ?></td>
                                <td><?php echo e($emp->name); ?></td>
                                <td><?php echo e($emp->getDesignation['desig_name']); ?></td>
                                <td><?php echo e($emp->gross_salary); ?></td>
                                <td>30</td>


                                    <?php
                                        $month=2;//$data['month'];
                                        $year=$data['year'];
                                    ?>


                                <td>
                                    <?php
                                     $empSal=countEmpSalaryForViews($emp_id=$emp->id,$month=$month,$year=2022);
                                     $subTotal =$subTotal + $empSal['netSal'];
                                    ?>
                                    <?php echo e($empSal['present']); ?>

                                </td>
                                <td> <?php echo e($empSal['allowance']); ?></td>
                                <td>-</td>
                                <td> <?php echo e($empSal['netSal']); ?></td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td> <?php echo e($empSal['netSal']); ?></td>
                                <td><?php echo e($emp->bank_ac_no); ?></td>
                                <td> <?php echo e($empSal['netSal']); ?></td>
                                <td colspan="5"></td>

                            </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td>
                                    <div class="float-right"> <strong>Sub Total:</strong></div>
                                </td>
                                <td colspan="14">
                                    <div class="float-right"> <strong><?php echo e($subTotal); ?></strong></div>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {

            $('#printBtn').on('click', function() {
                $.print("#tablePrint");
            });

        });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/payroll/salary-sheet.blade.php ENDPATH**/ ?>