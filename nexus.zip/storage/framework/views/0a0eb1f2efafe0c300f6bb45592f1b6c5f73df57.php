<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">

            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Posts</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Add New Post</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="<?php echo e(url('/create-post')); ?>" class="btn add-btn" title="Add Post"><i class="fa fa-plus" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="row staff-grid-row">
                <?php if(isset($data['posts'])): ?>
                    <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                            <div class="profile-widget">
                                <div class="profile-img">
                                    <a href="">
                                        <img src="<?php echo e(asset('storage/app/public/uploads/social-posts/').'/'.$post->image); ?>" class="social-media-post" alt="">
                                    </a>
                                </div>
                                <div class="dropdown profile-action">
                                    <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="" ><i class="fa fa-pencil m-r-5"></i> Facebook</a>
                                        <a class="dropdown-item btn-delete" href="#" ><i class="fa fa-trash-o m-r-5"></i>Instagram</a>
                                        <a class="dropdown-item btn-delete" href="#" ><i class="fa fa-trash-o m-r-5"></i>Whatsapp</a>
                                        <a class="dropdown-item btn-delete" href="#" ><i class="fa fa-trash-o m-r-5"></i>Twiter</a>
                                    </div>
                                </div>
                                <h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo e(url('profile')); ?>"><?php echo e($post->title); ?></a></h4>
                                <div class="small text-muted"><?php echo e(substr($post->desc,0,30)); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/call-center/posts/index.blade.php ENDPATH**/ ?>