<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <style>
            #right_side {
                background-color: #f7f7f7;
                padding: 25px 8px;
            }
            body {
                font-family: Arial;
                font-size: 10pt;
            }
            table {
                border: 1px solid #ccc;
                border-collapse: collapse;
            }
            table th {
                background-color: #F7F7F7;
                color: #333;
                font-weight: bold;
            }
            table th,
            table td {
                padding: 5px;
                border: 1px solid #ccc;
            }
        </style>
        <!-- Page Content -->
        <div class="content">
            <!-- Page Header -->
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Balance Sheet</h3>
                    </div>

                </div>
            </div>
            <!-- /Page Header -->
            <!-- /Page Content -->
            <div class="card" id="mainCard">
                <div class="card-body">
                    <div class="container">
                        <div class="row">


                            <div class="col-lg-12 col-md-12">
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th>SR#</th>
                                        <th>Ac Holder</th>
                                        <th>Account</th>
                                        <th>Balance</th>
                                    </tr>
                                    </thead>
                                    <tbody id="accountsTable">
                                    </tbody>


                                    <tr>
                                        <td>
                                            <div class="float-right"> <strong>Total:</strong></div>
                                        </td>
                                        <td colspan="2">

                                        </td>
                                        <td> <strong>PKR <span id="total"></span></strong></td>

                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Page Content -->
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- CDN for Sweet Alert -->
    <script>
        $(document).ready(function() {


            getBalanceSheet();

            function getBalanceSheet() {

                $.ajax({

                    url: '<?php echo e(url("/balance-sheet")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',

                    success: function(data) {

                        var html = '';
                        var i;
                        var c = 0;
                        var total=0;

                        for (i = 0; i < data.length; i++) {

                            total=parseFloat(total)+ parseFloat(data[i].balance);
                            c++;
                            html += '<tr>' +
                                '<td>' + c + '</td>' +
                                '<td>' + data[i].ac_holder_name + '</td>' +
                                '<td>' + data[i].actype.ac_type + '</td>' +
                                '<td> PKR ' +data[i].balance + '</td>' +


                                '</tr>';
                        }


                        $('#accountsTable').html(html);
                        $('#total').html(total);

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/accounts/accounts/balance-sheet.blade.php ENDPATH**/ ?>