<?php $__env->startSection('content'); ?>



    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Customer Survey</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Customer Survey</li>
                        </ul>
                    </div>

                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr class="font-weight-bold">
                                <th>#</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Project</th>
                                <th>Date</th>
                                <th>Size</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="taskTable">
                            <?php if(isset($cs)): ?>
                                <?php $__currentLoopData = $cs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($c->name); ?></td>
                                        <td><?php echo e($c->contact); ?></td>
                                        <td><?php echo e($c->project); ?></td>
                                        <td><?php echo e($c->date); ?></td>
                                        <td><?php echo e($c->size); ?> Marla</td>

                                        <td>
                                            <?php


                                                if ($c->status =='not approach') {
                                                    echo '<span class="badge bg-inverse-danger">' .strtoupper( $c->status) . '</span></br>';
                                                } else {
                                                    echo '<span class="badge bg-inverse-info">'.strtoupper($c->status).'</span>';
                                                }
                                            ?>

                                        </td>
                                        <td class="text-right">

                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown"
                                                   aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a href="<?php echo e(url('survey-remarks/'.encrypt($c->id))); ?>"
                                                       class="dropdown-item bg-inverse-primary" title="Create Survey Comment">Interested</a>

                                                    <a href="<?php echo e(url('not-intrested/'.encrypt($c->id))); ?>"
                                                       class="dropdown-item bg-inverse-primary" title="Create Survey Comment">Not Interested</a>
                                                    <a href="<?php echo e(url('not-connected/'.encrypt($c->id))); ?>"
                                                       class="dropdown-item bg-inverse-primary" title="Create Survey Comment">Not Connected</a>



                                                </div>
                                            </div>
                                        </td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <tr>
                                <td colspan="12">
                                    <div class="float-right">
                                        <?php echo e($cs->links('pagination::bootstrap-4')); ?>

                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /Page Content -->
        </div>
    </div>


    <script>

        $(document).ready(function () {

            toastr.options.timeOut = 3000;
            <?php if(Session::has('error')): ?>
            toastr.error('<?php echo e(Session::get('error')); ?>');
            <?php elseif(Session::has('success')): ?>
            toastr.success('<?php echo e(Session::get('success')); ?>');
            <?php endif; ?>

        });

        $('.save_remarks').on('click', function() {
            $(".save_remarks").prop("disabled", true);
            $(".save_remarks").html("Please wait...");
            $('#remarksForm').submit();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u443729190/domains/shahraantech.com/public_html/rgms/resources/views/call-center/survey/customer-survey.blade.php ENDPATH**/ ?>