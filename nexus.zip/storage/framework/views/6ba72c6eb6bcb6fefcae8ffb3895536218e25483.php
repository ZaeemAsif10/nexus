<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Purchase</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Purchase</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="<?php echo e(url('files')); ?>" class="btn add-btn" title="Products List"><i
                                class="fa fa-list" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="card">
                <form action="<?php echo e(url('create-file')); ?>" method="post" id="purchaseForm" >
                    <?php echo csrf_field(); ?>
                    <div class="card-body">

                        <div class="row">

                            <div class="form-group col-sm-4">

                                <label>Project <span class="text-danger">*</span></label>

                                <select name="project_id" class="form-control" required>
                                    <option value="" selected disabled>Choose One</option>
                                    <?php if(isset($data['pro'])): ?>
                                        <?php $__currentLoopData = $data['pro']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <table class="table table-style">
                                <thead>
                                <tr>
                                    <th>Items <span class="text-danger">*</span></th>
                                    <th>Reg-No<span class="text-danger">*</span></th>
                                    <th>Type<span class="text-danger">*</span></th>
                                    <th>Qty<span class="text-danger">*</span></th>
                                </tr>
                                </thead>
                                <tbody id="tblPurchase">
                                <tr>
                                    <td>
                                        <select name="item_id[]" id="" class="form-control item-id" required>
                                            <option value="">Choose Item</option>
                                            <?php if(isset($data['products'])): ?>
                                                <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </td>

                                    <td><input type="text" class="form-control reg-no" placeholder="File No"
                                               name="reg_no[]" required></td>
                                    <td>
                                    <select name="type[]" id="" class="form-control" required>
                                        <option value="">Choose Type</option>
                                        <option value="1">Commercial</option>
                                        <option value="2">Residential</option>
                                    </select>
                                    </td>
                                    <td><input type="text" class="form-control " placeholder="Qty"
                                               name="qty[]" required></td>
                                    <td><button type="button" class="btn-primary" id="addNewRow"><i
                                                class="fa fa-plus"></i></button> </td>
                                </tr>
                                </tbody>

                            </table>
                            <div class="col-md-10"></div>
                            <div class="col-md-2"><button class="btn btn-primary btn-submit" type="submit">Save</button></div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- /Page Content -->
    <div id="dvOrders" style="display:none">
        <table class="table table-bordered mt-5 table-style secondtable">
            <tr>
                <td>
                    <select name="item_id[]" id="" class="form-control item-id" required>
                        <option value="">Choose Item</option>
                        <?php if(isset($data['products'])): ?>
                            <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </td>
                <td><input type="text" class="form-control reg-no" placeholder="File No" name="reg_no[]" required>
                </td>
                <td>
                    <select name="type[]" id="" class="form-control" required>
                        <option value="">Choose Type</option>
                        <option value="1">Commercial</option>
                        <option value="2">Residential</option>
                    </select>
                </td>
                <td><input type="text" class="form-control " placeholder="Qty"
                           name="qty[]" required></td>
                <td style="color:red;cursor: pointer" class="delete-row" title="Remove"><i class="fa fa-trash"></i></td>
            </tr>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {

            $(function() {
                $('#addNewRow').on('click', function() {
                    var tr = $("#dvOrders").find("Table").find("TR:has(td)").clone();
                    console.log(tr);
                    $("#tblPurchase").append(tr);
                });
            });
            var rowIdx = 0;

            // jQuery button click event to remove a row.
            $('#tblPurchase').on('click', '.delete-row', function() {

                // Getting all the rows next to the row
                // containing the clicked button
                var child = $(this).closest('tr').nextAll();

                // Iterating across all the rows
                // obtained to change the index
                child.each(function() {

                    // Getting <tr> id.
                    var id = $(this).attr('id');

                    // Getting the <p> inside the .row-index class.
                    var idx = $(this).children('.row-index').children('p');

                    // Gets the row number from <tr> id.
                    var dig = parseInt(id.substring(1));

                    // Modifying row index.
                    idx.html(`Row ${dig - 1}`);

                    // Modifying row id.
                    $(this).attr('id', `R${dig - 1}`);
                });

                // Removing the current row.
                $(this).closest('tr').remove();

                // Decreasing total number of rows by 1.
                rowIdx--;
            });

            $('#purchaseForm').validate({

                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            });

            //purchase form submit
            $('#purchaseForm').unbind().on('submit', function(e) {
                e.preventDefault();
                var $form = $(this);
                // check if the input is valid
                if (!$form.validate().form()) return false;
                var formData = $('#purchaseForm').serialize();

                $.ajax({
                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url('create-file')); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {
                        $(".btn-submit").prop("disabled", true);
                        $(".btn-submit").html("please wait...");
                    },
                    success: function(data) {

                        if (data.success) {
                            $('#purchaseForm')[0].reset();
                            toastr.success(data.success);
                        }
                        if (data.errors) {
                            toastr.error(data.errors);
                        }
                    },
                    complete: function(data) {
                        $(".btn-submit").html("Save");
                        $(".btn-submit").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');
                    },
                });
            });

        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posh-city\resources\views/admin/stock/create-files.blade.php ENDPATH**/ ?>