

<?php $__env->startSection('content'); ?>


    <div class="page-wrapper">

        <!-- Page Content -->
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="page-title">Employee</h3>
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Employee</li>
                                </ul>
                            </div>
                            <div class="col-auto float-right ml-auto">
                                <a href="<?php echo e(url('/new-employee')); ?>" class="btn add-btn" title="Add Employee"><i
                                        class="fa fa-plus"></i></a>
                                <div class="view-icons">
                                    <a href="<?php echo e(url('employees')); ?>" class="grid-view btn btn-link active"><i
                                            class="fa fa-th"></i></a>
                                    <a href="<?php echo e(url('employees-list')); ?>" class="list-view btn btn-link"><i
                                            class="fa fa-bars"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->


            <!-- Search Filter -->
            <div class="card">
                <div class="card-body">

                    <form method="post" action="<?php echo e(url('employees')); ?>" id="SearchEmpForm">

                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-md-3">

                                <select name="company_id" class="form-control selectpicker" data-container="body"
                                    data-live-search="true">
                                    <option value="">Choose Company</option>
                                    <?php if(isset($data['company'])): ?>
                                        <?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                            </div>

                            <div class="col-md-3">
                                <select name="dept_id" class="form-control selectpicker" data-container="body"
                                    data-live-search="true">

                                    <option value=""> Dept</option>
                                    <?php if(isset($data['dept'])): ?>
                                        <?php $__currentLoopData = $data['dept']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->departments); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                            </div>

                            <div class="col-md-3">


                                <select name="desig_id" class="form-control selectpicker" data-container="body"
                                    data-live-search="true">
                                    <option value=""> Designation</option>
                                    <?php if(isset($data['designation'])): ?>
                                        <?php $__currentLoopData = $data['designation']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($desig->id); ?>"><?php echo e($desig->desig_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                            </div>

                            <div class="col-md-3">

                                <select name="grade_id" class="form-control selectpicker" data-container="body"
                                    data-live-search="true">
                                    <option value=""> Grades</option>
                                    <?php if(isset($data['grade'])): ?>
                                        <?php $__currentLoopData = $data['grade']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($grade->id); ?>"><?php echo e($grade->grade); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for=""></label>
                                <input type="text" class="form-control floating" name="emp_name" placeholder="Emp Name">
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-search" style="margin-top: 30px"><i
                                            class="fa fa-search"></i></button>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
            <!-- Search Filter -->
            <?php if($data['search'] == 1): ?>
                <div class="text-primary"><?php echo e($data['foundedRec']); ?> Records Found</div>
            <?php endif; ?>
            <div class="row staff-grid-row" id="employeeBox">

                <?php if(isset($data['employee'])): ?>
                    <?php $__currentLoopData = $data['employee']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">

                            <div class="profile-widget">
                                <div class="profile-img">
                                    <a href="<?php echo e(url('user-profile/') . '/' . encrypt($emp->id)); ?>">
                                        <img src="<?php echo e(asset('storage/app/public/uploads/staff-images/') . '/' . $emp->image); ?>"
                                            class="avatar" alt="">
                                    </a>
                                </div>
                                <div class="dropdown profile-action">
                                    <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown"
                                        aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="<?php echo e(url('edit-employee/' . encrypt($emp->id))); ?>"
                                            data="<?php echo e($emp->id); ?>"><i class="la la-pencil" style="font-size:20px;"></i></a>
                                        <a class="dropdown-item change_status" href="#" data="<?php echo e($emp->id); ?>"><i
                                                class="la la-trash" style="font-size:20px;"></i></a>
                                    </div>
                                </div>
                                <h4 class="user-name m-t-10 mb-0 text-ellipsis"><a
                                        href="<?php echo e(url('profile')); ?>"><?php echo e($emp->name); ?></a></h4>
                                <div class="small text-muted"><?php echo e($emp->desig_name); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            <div class="float-right">
                <?php echo e($data['employee']->links('pagination::bootstrap-4')); ?>

            </div>

        </div>
        <!-- /Page Content -->



    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {


            //status update
            $('#employeeBox').on('click', '.change_status', function() {

                var id = $(this).attr('data');

                $.ajax({
                    url: '<?php echo e(url('/update-employee-status')); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',
                    data: {
                        id: id
                    },
                    success: function(response) {

                        if (response.status == 200) {
                            toastr.success(response.message);
                            setTimeout(() => {
                                window.location.reload();
                            }, 1000);
                        }

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });

            });

        })
    </script>



    <script>
        $('.btn-search').on('click', function() {
            $(".btn-search").prop("disabled", true);
            $(".btn-search").html("Please wait...");
            $('#SearchEmpForm').submit();
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rgms\resources\views/employee/index.blade.php ENDPATH**/ ?>