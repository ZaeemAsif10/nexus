<?php $__env->startSection('content'); ?>
    <style type="text/css">
        body {
            font-family: Arial;
            font-size: 10pt;
        }
        table {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th,
        table td {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <div class="main-wrapper">
        <!-- /Sidebar -->
        <!-- Page Wrapper -->
        <div class="page-wrapper">
            <!-- Page Content -->
            <div class="content container-fluid">
                <div class="page-header my-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title bold-heading">Today Created Leads</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Today Created Leads</li>
                            </ul>
                        </div>

                    </div>
                </div>


                <!-- Search Filter -->
                <div class="card">
                    <div class="card-body">

                        <?php if($data['leadsMarketing']->count() > 0): ?>
                        <table class="table table-striped table-hover">
                            <thead>
                            <tr>

                                <th>#</th>
                                <th>LeadID</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>City</th>
                                <th>Allocate</th>
                                <th>Source</th>
                                <th>Temp</th>
                                <th>Type</th>
                                <th>Query</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $c=0; ?>
                            <?php if(isset($data['leadsMarketing'])): ?>
                                <?php $__currentLoopData = $data['leadsMarketing']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $c++; ?>


                                        <td><?php echo e($data['leadsMarketing']->firstItem() + $key); ?></td>
                                        <td><a
                                                href="<?php echo e(url('lead-detail/') . '/' . encrypt($market->id)); ?>"><?php echo e($market->id); ?></a>
                                        </td>
                                        <td><?php echo e($market->name); ?></td>
                                        <td><?php echo e($market->contact); ?></td>
                                        <td><?php echo e($market->cityname->city_name); ?></td>
                                        <td>
                                            <?php
                                            $name='';
                                            if($market->manager_id){
                                             $emp=\App\Models\Employee::find($market->manager_id);
                                                $name=$emp->name;
                                                $className='success';
                                                }else{
                                                $lead = App\Models\AssignedLeads::with('agent')
                                                ->where('lead_id', $market->id)
                                                ->first();
                                                ($lead)?$name=$lead->agent['name']:$name='';
                                                 $className='primary';


                                                }
                                                if ($name) {
                                                echo '<span class="badge bg-inverse-'.$className.'">' . $name. '</span>';
                                                } else {
                                                echo '<span class="badge bg-inverse-danger">Open</span>';
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <?php echo e($market->platformname->platform ? $market->platformname->platform : ''); ?>

                                        </td>
                                        <td>
                                            <?php
                                             ($market->lead_type=='Inbound')? $className='success': $className='primary';
                                                $lead = App\Models\ApprochedLeads::with('temp')
                                                ->where('lead_id', $market->id)
                                                ->first();
                                                if ($lead) {
                                                echo '<span class="badge bg-inverse-warning">' . $lead->temp['temp'] . '</span>';
                                                } else {
                                                echo '<span class="badge bg-inverse-danger">Open</span>';
                                                }
                                            ?>
                                        </td>

                                        <td><span class="badge bg-inverse-<?php echo e($className); ?>"><?php echo e($market->lead_type); ?></span></td>
                                        <td><?php echo e(substr($market->interest,10)); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($market->created_at))); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <tr>
                                <td colspan="12">
                                    <div class="float-right">
                                        <?php echo e($data['leadsMarketing']->links('pagination::bootstrap-4')); ?>

                                    </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <div class="alert alert-danger">Record Not FOund</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- /Page Content -->
        </div>

        </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/call-center/leads/today-created-leads.blade.php ENDPATH**/ ?>