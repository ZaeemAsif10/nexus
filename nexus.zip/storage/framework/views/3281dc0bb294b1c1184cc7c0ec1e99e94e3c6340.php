<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
 
   
    <p>Training Mails</p>
    <h2>Its  is a fantatic mail</h2>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\crm\resources\views/emails/sendTrainingMail.blade.php ENDPATH**/ ?>