

<?php $__env->startSection('content'); ?>


<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->


        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">My Trainings</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">My Trainings</li>
                    </ul>
                </div>

            </div>
        </div>
        <!-- /Page Header -->




        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">


                    <table class="table table-striped" id="datatable">
                        <thead>
                            <tr>
                                <th style="width: 30px;">#</th>
                                <th>Training Type</th>
                                <th>Trainer</th>

                                <th>Time Duration</th>
                                <th>Description </th>
                                <th>Cost </th>
                                <th>Status </th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $c=0; ?>
                            <?php if(isset($data['training'])): ?>
                            <?php $__currentLoopData = $data['training']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $c++; ?>
                            <tr>
                                <td><?php echo e($c); ?></td>
                                <td><?php echo e($train->training_type); ?></td>

                                <td>
                                    <h2 class="table-avatar">
                                        <a href="#">
                                            <img alt="" class="target-img" src="<?php echo e(asset('public/assets/img/profiles/avatar-02.jpg')); ?>"></a>
                                        <a href="#"><?php echo e($train->trainer); ?> </a>
                                    </h2>
                                </td>

                                <td><?php echo e(date("d M Y", strtotime($train->from))); ?> - <?php echo e(date("d M Y", strtotime($train->to))); ?></td>
                                <td><?php echo e($train->desc); ?></td>
                                <td><?php echo e($train->cost); ?></td>


                                <td>
                                    <div class="dropdown action-label">
                                        <a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false" <i class="fa fa-dot-circle-o text-success"></i> <?php echo e($train->status); ?>

                                        </a>

                                    </div>
                                </td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /Page Content -->
</div>


<script>
    $(document).ready(function() {

        //Datatables
        $('#datatable').DataTable();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/hrm.alphabuzzco.com/resources/views/targets/emp-trainings.blade.php ENDPATH**/ ?>