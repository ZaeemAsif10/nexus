

<?php $__env->startSection('content'); ?>
    <main id="main">
        <!-- ======= Intro Single ======= -->
        <section class="intro-single">
            <div class="container-fluid ">
                <div class="row about-breadcrump text-center gx-0">
                    <div class="col-md-12">
                        <div class="title-single-box">
                            <h1 class="title-single text-white">
                                CONTACT US</h1>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active text-white-50" aria-current="page">
                                    Contact Us
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Intro Single-->
        <!-- ======= Contact Single ======= -->
        <section class="contact">
            <div class="container">
                <div class="row mt-4">
                    <div class="col-sm-12 mt-5">
                        <div class="row justify-content-center">
                            <h1 class="text-center"><span class="color-b">Get In Touch</span></h1>
                            <div class="col-md-8 mt-3">
                                <?php if(session()->has('message')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session()->get('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(url('contact-mail')); ?>" method="POST" class="validation-form">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <div class="form-group">
                                                <input type="text" name="name"
                                                    class="form-control form-control-lg form-control-a"
                                                    placeholder="Your Name" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <div class="form-group">
                                                <input name="email" type="email"
                                                    class="form-control form-control-lg form-control-a"
                                                    placeholder="Your Email" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <div class="form-group">
                                                <input type="text" name="subject"
                                                    class="form-control form-control-lg form-control-a"
                                                    placeholder="Subject" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <textarea name="message" class="form-control" name="message" cols="45" rows="8" placeholder="Message"
                                                    required></textarea>
                                            </div>
                                        </div>

                                        <div class="col-md-12 text-center mt-4">
                                            <button type="submit" class="btn btn-a">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 mt-5">
                        <div class="contact-map box">
                            <div id="map" class="contact-map">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1422937950147!2d-73.98731968482413!3d40.75889497932681!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes+Square!5e0!3m2!1ses-419!2sve!4v1510329142834"
                                    width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Single-->
        <section class="address-card">
            <div class="container">
                <div class="row pt-4">
                    <div class="col-sm-12 col-md-6 col-lg-4 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <div class="card-icon m-auto">
                                    <i class="bi bi-geo-alt-fill"></i>
                                </div>
                                <h2 class="text-black">Office Address</h2>
                                <p>Skylona Plaza,Sheikh Zayad Sultan Road,
                                    Near Giga Mall,Gt Road, DHA II,Islamabad</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-4 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <div class="card-icon m-auto">
                                    <i class="bi bi-stopwatch"></i>
                                </div>
                                <h2 class="text-black">Office Opening time</h2>
                                <p>Mon - Sun: 09:00am - 05:00pm +660 198 369 360 2017</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-4 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <div class="card-icon m-auto">
                                    <i class="bi bi-envelope"></i>
                                </div>
                                <h2 class="text-black">Message Us</h2>
                                <p>
                                    <a href="mailto:Info@poshcity.pk">Info@poshcity.pk</a><br>
                                    <a href="mailto:Info@poshcity.pk">demomail@example.com</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\poshcity\resources\views/web-side/contact.blade.php ENDPATH**/ ?>