<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <style>
        body {
            overflow-y: hidden;
        }

        .attendence_table {
            height: 60vh;
            overflow: scroll;
            overflow-x: scroll;
        }

        table thead th:first-child {
            position: sticky;
            left: 0;
            z-index: 2;
            background: white;
        }


        table thead th {
            position: sticky;
            top: 0;
            z-index: 1;
            background: white;
        }


        #search_user {
            border-radius: 30px;
        }
    </style>
    <!-- Page Content -->

    <div class="content container-fluid">

        <div class="card">
            <div class="card-body">
                <!-- <h4 class="card-title">Solid justified</h4> -->
                <ul class="nav nav-tabs nav-tabs-solid nav-justified">
                    <li class="nav-item"><a class="nav-link " href="<?php echo e(url('att-dashboard')); ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?php echo e(url('attendance')); ?>">Mark Attendance</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('view-attendance')); ?>">View Attendance</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('attendance-reports')); ?>">Attendance Reports</a></li>
                </ul>
            </div>
        </div>


        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <form action="<?php echo e(url('attendance')); ?>" method="get">
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group">
                                    <select name="company_id" class="form-control selectpicker" data-container="body" data-live-search="true">
                                        <option value="" selected disabled>Choose Company</option>
                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($com->id); ?>"><?php echo e($com->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary"> <i class="fa fa-search"></i> </button>
                                </div>
                            </div>

                        </div>

                    </form>
                </div>
                <div class="col-md-5">
                    <input type="text" class="form-control" id="search_user" placeholder="search...">
                </div>
                <div class="col-md-2">
                    <form action="<?php echo e(url('attendance')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success btn-block"> Mark </button>
                        </div>


                </div>
            </div>
        </div>


        <div class="row">
            <div class="table-responsive">
                <div class="attendence_table">
                    <table class="table table-striped custom-table mb-0">
                        <thead>
                            <tr>
                                <th>SR#</th>
                                <th>Employee</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $c=0; ?>
                            <?php if(isset($data['employee'])): ?>
                            <?php $__currentLoopData = $data['employee']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $c++; ?>
                            <tr>
                                <td><?php echo e($c); ?></td>
                                <td>
                                    <input type="hidden" name="emp_id[]" value="<?php echo e($emp->id); ?>">
                                    <h2 class="table-avatar">
                                        <a href="#"><img alt="" class="target-img" src="<?php echo e(asset('storage/app/public/uploads/staff-images/').'/'.$emp->image); ?>"></a>
                                        <a><?php echo e($emp->name); ?><span><?php echo e($emp->desig_name); ?></span></a>
                                    </h2>
                                </td>
                                <td><i class="fa fa-check text-success"></i> <input type="radio" name="status_<?php echo e($c); ?>" value="present" checked> &nbsp;
                                    <i class="fa fa-close text-danger"></i></i> <input type="radio" name="status_<?php echo e($c); ?>" value="absent">
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
<script>
    <?php if(count($errors) > 0): ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    toastr.error("<?php echo e($error); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <?php if(Session::has('success')): ?>
    toastr.success("Attendance marked successfully!");

    <?php endif; ?>


    //search
    $('#search_user').keyup(function(e) {
        search_table($(this).val());
    });

    function search_table(value) {
        $('table tr').each(function() {
            var found = 'false';
            $(this).each(function() {
                if ($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0) {
                    found = 'true';
                }
            });
            if (found == 'true') {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/attendance/index.blade.php ENDPATH**/ ?>