<?php echo e($slot); ?>

<?php /**PATH /home/alphmnju/crm.alphabuzzco.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>