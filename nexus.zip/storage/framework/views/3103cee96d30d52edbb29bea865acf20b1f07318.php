
    <script type="text/javascript">
        $(document).ready(function() {
            $('body').bind('cut copy', function(event) {
                event.preventDefault();
            });
        });
    </script>





<?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/call-center/general/dont-copy.blade.php ENDPATH**/ ?>