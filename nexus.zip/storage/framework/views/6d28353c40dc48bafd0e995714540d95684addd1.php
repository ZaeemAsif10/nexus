<header>
    <nav class="navbar navbar-expand-lg bg-white">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img
                    src="<?php echo e(asset('public/web-assets/img/logo/Nexus logo1 .png')); ?>" class="img-fluid logo" alt="logo"
                    srcset=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('about')); ?>">About</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink"
                            role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Projects
                        </a>
                        <ul class="dropdown-menu dropdown-menu-white p-menue" aria-labelledby="navbarDarkDropdownMenuLink">
                            <?php
                                $navbars = App\Models\Project::all();
                            ?>
                            <?php $__currentLoopData = $navbars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navbarItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="dropdown-item" href="<?php echo e(url('projects/'.$navbarItem->id)); ?>"><?php echo e($navbarItem->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('blogs')); ?>">Blog</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <a href="<?php echo e(url('contact')); ?>" class="btn btn-gold">Contact Us</a>
                </form>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\nexus\resources\views/web-side/setup/header.blade.php ENDPATH**/ ?>