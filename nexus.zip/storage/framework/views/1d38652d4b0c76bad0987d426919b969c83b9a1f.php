<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>

                <?php if(Auth::user()->role == 'admin'): ?>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-user"></i> <span> House Keeping </span> <span
                                class="menu-arrow"></span></a>
                        <ul>

                            <li class="submenu">
                                <a href="#"> <span>Configuration</span> <span class="menu-arrow"></span></a>
                                <ul>

                                    <li class="submenu">
                                        <a href="#"> <span>Location Setup</span> <span
                                                class="menu-arrow"></span></a>
                                        <ul>
                                            <li><a href="<?php echo e(url('/company')); ?>">Company Info</a></li>
                                            <li><a href="<?php echo e(url('/company-branches')); ?>">Company Location</a></li>
                                            <li><a href="<?php echo e(url('/time')); ?>">Time Settings</a></li>

                                        </ul>
                                    </li>

                                    <li class="submenu">
                                        <a href="#"> <span>Roles Management</span> <span
                                                class="menu-arrow"></span></a>
                                        <ul>
                                            <li> <a href="<?php echo e(url('roles')); ?>"> <span>Roles</span></a> </li>
                                            <li> <a href="<?php echo e(url('role-permissions')); ?>"> <span>Role
                                                        Permissions</span></a> </li>
                                            <li> <a href="<?php echo e(url('users')); ?>"> <span>Users</span></a> </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <li class="submenu">
                                <a href="#"> <span> HRM</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(url('/departments')); ?>">Department/Designation</a></li>
                                    <li><a href="<?php echo e(url('/grades')); ?>">Grades</a></li>
                                    <li><a href="<?php echo e(url('/employees')); ?>">Add Employee</a></li>

                                    <li class="submenu">
                                        <a href="#"><span> Payroll </span> <span
                                                class="menu-arrow"></span></a>
                                        <ul style="display: none;">
                                            <li><a href="<?php echo e(url('salary')); ?>"> Salary Slips </a></li>
                                            <li><a href="<?php echo e(url('salary-sheet')); ?>"> Salary Sheet</a></li>
                                            <li><a href="<?php echo e(url('payroll-items')); ?>"> Payroll Items </a></li>
                                            <li><a href="<?php echo e(url('/expense')); ?>">Expenses List</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <li class="submenu">
                                <a href="#"><i class="la la-briefcase"></i> <span> Job Seeker </span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <li><a href="<?php echo e(url('recruitment/existing')); ?>">CV Bank</a></li>
                                    <li><a href="<?php echo e(url('recruitment/new')); ?>">Jobs</a></li>
                                    <li><a href="<?php echo e(url('job-applicants')); ?>">Applicants</a></li>
                                    <li><a href="<?php echo e(url('interviews')); ?>">Interviews</a></li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"><i class="la la-files-o"></i> <span> OnBoarding </span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <li><a href="<?php echo e(url('/policies')); ?>">Policies</a></li>
                                    <li><a href="<?php echo e(url('/offer-letter')); ?>">Offer Letter</a></li>
                                    <li><a href="<?php echo e(url('/exp-letter')); ?>">Experience Letter</a></li>
                                    <li><a href="<?php echo e(url('/clearance-letter')); ?>">Clearance Letter</a></li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"><i class="la la-external-link-square"></i> <span> Resignations </span>
                                    <span class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <li><a href="<?php echo e(url('/resignations')); ?>">Resignations</a></li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"><i class="la la-external-link-square"></i> <span> Attendance </span>
                                    <span class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <li><a href="<?php echo e(url('/emp-attendance')); ?>">Self Attendance</a></li>
                                    <li><a href="<?php echo e(url('/att-dashboard')); ?>">Time / Attendance</a></li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"><i class="la la-edit"></i> <span>Learning/Development</span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <li><a href="<?php echo e(url('/trainers')); ?>">Trainers</a></li>
                                    <li><a href="<?php echo e(url('/targets')); ?>">Targets</a></li>
                                    <li><a href="<?php echo e(url('/trainings')); ?>">Trainings</a></li>
                                    <li><a href="<?php echo e(url('/trainer-reviews')); ?>">Trainer Feedbacks</a></li>
                                    <li><a href="<?php echo e(url('/emp-reviews')); ?>">Employee Feedbacks</a></li>
                                </ul>
                            </li>












                            <li class="submenu">
                                <a href="#"><i class="la la-edit"></i> <span>Leaves Management</span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <li><a href="<?php echo e(url('/leaves-settings')); ?>">Leaves Settings</a></li>
                                    <li><a href="<?php echo e(url('/leaves-request')); ?>">Leaves Request</a></li>
                                    <li><a href="<?php echo e(url('/off-week')); ?>">Off Week</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-ticket"></i> <span>Help Desk</span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="<?php echo e(url('/ticket')); ?>">Tickets</a></li>

                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-ticket"></i> <span>Reports</span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">


                            <li class="submenu">
                                <a href="#"><i class="la la-edit"></i> <span>Attendance Report</span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">

                                    <li><a href="<?php echo e(url('/daily-att-report')); ?>">Daily Report</a></li>
                                    <li><a href="<?php echo e(url('/monthly-att-report')); ?>">Monthly Report</a></li>



                                </ul>
                            </li>

                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if(Auth::user()->role == 'employee'): ?>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-user"></i> <span> House Keeping </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li> <a href="<?php echo e(url('leaves')); ?>"><i class="la la-info"></i> <span>Leaves</span></a>
                            </li>
                            <li> <a href="<?php echo e(url('resignation')); ?>"><i class="la la-external-link-square"></i>
                                    <span>Resignation Letter</span></a> </li>
                            <li> <a href="<?php echo e(url('help-desk')); ?>"><i class="la la-file-pdf-o"></i> <span>Help Desk
                                        Ticket</span></a> </li>
                            <li> <a href="<?php echo e(url('my-expenses')); ?>"><i class="la la-user-secret"></i>
                                    <span>Expenses</span></a> </li>
                            <li> <a href="<?php echo e(url('call-recording')); ?>"><i class="la la-user-secret"></i> <span>Call
                                        Recordings</span></a> </li>

                            <li class="submenu">
                                <a href="#"><i class="la la-edit"></i> <span>Learning/Development</span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">

                                    <li><a href="<?php echo e(url('/emp-trainings')); ?>">My Trainings</a></li>
                                    <li><a href="<?php echo e(url('/trainer-feedback')); ?>">My Feedbacks</a></li>
                                    <li><a href="<?php echo e(url('/write-feedback')); ?>">Write Feedbacks</a></li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"><i class="la la-rocket"></i> <span>Projects Management</span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <?php if(App\Models\User::join('leads', 'leads.leader_id', '=', 'users.account_id')->where('users.account_id', Auth::user()->account_id)->first()): ?>
                                        <li><a href="<?php echo e(url('/my-projects')); ?>">My Projects</a></li>
                                    <?php endif; ?>
                                    <li><a href="<?php echo e(url('/my-tasks')); ?>">My Project Tasks</a></li>
                                    <li><a href="<?php echo e(url('my-daily-task')); ?>">My Daily Tasks</a></li>
                                </ul>
                            </li>

                            <li class="submenu">
                                <a href="#"><i class="la la-files-o"></i> <span>Attendance</span> <span
                                        class="menu-arrow"></span></a>
                                <ul style="display: none;">
                                    <li><a href="<?php echo e(url('/emp-attendance')); ?>">Attendance</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <?php
                        $mod = App\Models\Module::get();
                    ?>
                    <?php $__currentLoopData = $mod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="submenu">
                            <?php
                                $allow = 0;
                                $chekSm = App\Models\SubModule::where('module_id', $mod->id)->get();
                                foreach ($chekSm as $chekSm) {
                                    $chekPerm = App\Models\RoleHasPermission::where('sub_module_id', $chekSm->id)->get();
                                    foreach ($chekPerm as $chek) {
                                        if ($chek->role_id == Auth::user()->role_id && $chek->is_allow == 1) {
                                            $allow = 1;
                                        }
                                    }
                                }
                            ?>
                            <?php if($chekSm && $allow == 1): ?>
                                <a href="#"><i class="la la-user"></i> <span><?php echo e($mod->module); ?></span> <span
                                        class="menu-arrow"></span></a>
                                <ul>
                                    <?php
                                        $m = App\Models\SubModule::where('module_id', $mod->id)->get();
                                    ?>
                                    <?php $__currentLoopData = $m; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $chekPerm = App\Models\RoleHasPermission::where('sub_module_id', $sm->id)->get();
                                        ?>
                                        <?php $__currentLoopData = $chekPerm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chekPerm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($chekPerm->role_id == Auth::user()->role_id && $chekPerm->is_allow == 1): ?>
                                                <li> <a
                                                        href="<?php echo e($sm->route); ?>"><span><?php echo e($sm->title); ?></span></a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(Auth::user()->role == 'trainer'): ?>
                    <li> <a href="<?php echo e(url('/')); ?>"><i class="la la-dashboard"></i> <span>Dashboard</span></a>
                    </li>
                    <li> <a href="<?php echo e(url('trainee-list')); ?>"><i class="la la-child"></i> <span>My Trainee</span></a>
                    </li>
                    <li> <a href="<?php echo e(url('trainee-feedback')); ?>"><i class="la la-commenting"></i> <span>Trainee
                                Feedbacks</span></a> </li>
                <?php endif; ?>

                <?php if(Auth::user()->role == 'accounts'): ?>
                    <li> <a href="<?php echo e(url('/')); ?>"> <span>Dashboard</span></a> </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-user"></i> <span> Accounts </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li class="submenu">
                                <a href="#"> <span> Chart Of Accounts </span> <span
                                        class="menu-arrow"></span></a>
                                <ul>
                                    <li> <a href="<?php echo e(url('coa')); ?>"> <span>COA Lists</span></a> </li>
                                    <li> <a href="<?php echo e(url('coa-mapping')); ?>"> <span>COA Mapping</span></a> </li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"> <span>Cash A/C </span> <span
                                        class="menu-arrow"></span></a>
                                <ul>

                                    <li> <a href="<?php echo e(url('accounts')); ?>"> <span>A/C Trial Balance</span></a> </li>
                                    <li> <a href="<?php echo e(url('ledgers')); ?>"> <span>Ledgers</span></a> </li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"><span>Bank A/C</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(url('/bank')); ?>">Bank Trial Balance</a></li>

                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"> <span>Transactions</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li> <a href="<?php echo e(url('payments')); ?>"> <span>Payments Voucher</span></a> </li>
                                    <li> <a href="<?php echo e(url('receipt')); ?>"> <span>Receipts Voucher</span></a> </li>
                                    <li> <a href="<?php echo e(url('jv')); ?>"> <span>Journal Voucher</span></a> </li>


                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"><span>Manage Expense</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(url('/manage-expense')); ?>">Add Expense</a></li>
                                    <li><a href="<?php echo e(url('/expense-summary')); ?>">Expense Summary</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#"><i class="la la-user-circle"></i> <span>Peoples</span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li> <a href="<?php echo e(url('vendors')); ?>"> <span>Add Vendor</span></a> </li>
                            <li> <a href="<?php echo e(url('clients')); ?>"> <span>Add Customer </span></a> </li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#"><i class="la la-product-hunt"></i> <span>Item Management</span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li><a href="<?php echo e(url('/category')); ?>">Add Category</a></li>
                            <li><a href="<?php echo e(url('/products')); ?>">Add Items</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-files-o"></i> <span> Purchase </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li><a href="<?php echo e(url('/purchase')); ?>">Add Purchase</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-files-o"></i> <span> Sales </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li><a href="<?php echo e(url('sale')); ?>">Dealers Sale</a></li>
                            <li><a href="<?php echo e(url('bulk-sale')); ?>">Bulk Sales</a></li>
                            <li><a href="<?php echo e(url('regular-sale')); ?>">Regular Sale</a></li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#"><i class="la la-files-o"></i> <span>Attendance</span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="<?php echo e(url('/emp-attendance')); ?>">Attendance</a></li>
                        </ul>
                    </li>
                    
                    
                    
                    
                    
                    
                    
                    
                    <li class="submenu">
                        <a href="#"><i class="la la-pie-chart"></i> <span> Reports </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li><a href="<?php echo e(url('/stock')); ?>">Inventory Reports</a></li>
                            <li><a href="<?php echo e(url('/sale-report')); ?>">Sale Reports </a></li>
                            <li><a href="<?php echo e(url('/purchase-list')); ?>">Purchase Reports </a></li>
                            <li><a href="<?php echo e(url('/monthly-profit-loss-report')); ?>">Monthly Profit Report </a></li>
                            <li><a href="<?php echo e(url('commission-report')); ?>">Commission Report</a></li>
                            <li><a href="<?php echo e(url('/loss-profit-report')); ?>">Loss & Profit Reports </a></li>
                            <li><a href="<?php echo e(url('/balance-sheet/1/1')); ?>">Balance Sheet</a></li>


                        </ul>
                    </li>


                        <li class="submenu">
                            <a href="#"><i class="la la-user"></i> <span>House Keeping</span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="<?php echo e(url('/society')); ?>">Projects </a></li>
                                <li> <a href="<?php echo e(url('role-permissions')); ?>"> <span>Role
                                                        Permissions</span></a> </li>
                            </ul>
                        </li>
                <?php endif; ?>
                <?php if(Auth::user()->role == 'call-center'): ?>
                    <li> <a href="<?php echo e(url('/')); ?>"> <span>Dashboard</span></a> </li>

                    <li class="submenu">
                        <a href="#"><i class="la la-user"></i> <span> Social Media </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li class="submenu">
                                <a href="#"> <span>Posts</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li> <a href="<?php echo e(url('posts')); ?>"> <span>Posts</span></a> </li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"> <span>Campaigns</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li> <a href="#"> <span>Social Media Campaign</span></a> </li>
                                    <li> <a href="sms"> <span>SMS Campaign</span></a> </li>
                                    <li> <a href="email"> <span>Email Campaign</span></a> </li>
                                    <li> <a href="<?php echo e(url('email-attachment')); ?>"> <span>Random Email Campaign</span></a> </li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"> <span>Response</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li> <a href="#"> <span>Posts Response</span></a> </li>
                                </ul>
                            </li>

                            <li class="submenu">
                                <a href="#"><i class="la la-user"></i> <span>Chat</span> <span
                                        class="menu-arrow"></span></a>
                                <ul>
                                    <li class="submenu">
                                        <a href="#"> <span>Chat</span> <span class="menu-arrow"></span></a>
                                        <ul>
                                            <li> <a href="<?php echo e(url('chat')); ?>"> <span>Chat</span></a> </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-user"></i> <span>Projects & Targets</span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li class="submenu">
                                <a href="#"> <span>Targets Management</span> <span
                                        class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(url('/targets')); ?>">Create Targets</a></li>
                                </ul>
                            </li>
                            <li class="submenu">
                                <a href="#"> <span>Team Management</span> <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(url('/team')); ?>">Team Management</a></li>
                                </ul>
                            </li>
                            
                            
                            
                            
                            
                            
                            
                            
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-user"></i> <span>Leads Management</span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            
                            <li> <a href="<?php echo e(url('leads-list')); ?>"> <span>Leads List</span></a> </li>
                            <li> <a href="<?php echo e(url('my-leads')); ?>"> <span>My Leads</span></a> </li>
                            <li> <a href="<?php echo e(url('allocated-leads')); ?>"> <span>CSR Leads</span></a> </li>
                            <li> <a href="<?php echo e(url('manager-allocated-leads')); ?>"> <span>Manager Leads</span></a> </li>
                            <li> <a href="<?php echo e(url('open-leads')); ?>"> <span>Open Leads</span></a> </li>
                            
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-user"></i> <span>Meetings & Sales</span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li> <a href="<?php echo e(url('walkin-customer')); ?>"> <span>Customer Form</span></a> </li>
                            <li> <a href="<?php echo e(url('meetings')); ?>"> <span>Meetings List</span></a> </li>
                            <li> <a href="<?php echo e(url('my-meetings')); ?>"> <span>My Meetings</span></a> </li>
                            <li> <a href="<?php echo e(url('my-sales')); ?>"> <span>My Sales</span></a> </li>
                        </ul>
                    </li>
                        <li class="submenu">
                            <a href="#"><i class="la la-user"></i> <span>Customer Survey</span> <span
                                    class="menu-arrow"></span></a>
                            <ul>
                                <li> <a href="<?php echo e(url('create-survey')); ?>"> <span>Create Survey</span></a> </li>


                            </ul>
                        </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-files-o"></i> <span>Attendance</span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="<?php echo e(url('/emp-attendance')); ?>">Attendance</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-edit"></i> <span>Reports</span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">

                            <li><a href="<?php echo e(url('/leads-response')); ?>">Leads Response Report</a></li>
                            <li><a href="<?php echo e(url('/csr-no-of-leads')); ?>">CSR NO of Leads</a></li>
                            <li><a href="<?php echo e(url('/manager-no-of-leads')); ?>">Manager NO of Leads</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="la la-home"></i><span>Property Management</span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="<?php echo e(url('/property-type')); ?>">Property Type</a></li>
                            <li><a href="<?php echo e(url('/create-property')); ?>">Create Property</a></li>
                            <li><a href="<?php echo e(url('/property-variation')); ?>">Property Variation</a></li>
                            <li><a href="<?php echo e(url('/property-projects')); ?>">Property Projects</a></li>
                            <li><a href="<?php echo e(url('/get-seller')); ?>">Seller</a></li>
                            <li><a href="<?php echo e(url('/get-buyer')); ?>">Buyer</a></li>
                        </ul>
                    </li>
                    <li class="submenu">
                        <a href="#"><i class="fa fa-user"></i> <span>House Keeping</span> <span
                                class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <li><a href="<?php echo e(url('/leads-settings')); ?>">Leads Settings</a></li>
                            <li><a href="<?php echo e(url('/leads-source-settings')); ?>">Leads Source Settings</a></li>

                            <li class="submenu">
                                <a href="#"> <span>General Settings</span> <span
                                        class="menu-arrow"></span></a>
                                <ul>
                                    <li> <a href="<?php echo e(url('temp')); ?>"> <span>Temperatures</span></a> </li>
                                    <li> <a href="<?php echo e(url('city')); ?>"> <span>Cities</span></a> </li>
                                    <li> <a href="<?php echo e(url('platforms')); ?>"> <span>Social Platforms</span></a> </li>
                                    <li><a href="<?php echo e(url('/society')); ?>">Societies </a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>


                <?php if(Auth::user()->role == 'super-admin'): ?>
                    <?php echo $__env->make('setup.super-admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
<?php /**PATH /home/u443729190/domains/shahraantech.com/public_html/rgms/resources/views/setup/sidebar.blade.php ENDPATH**/ ?>