  <!-- ======= Header/Navbar ======= -->
  <nav class="navbar navbar-default navbar-trans navbar-expand-lg fixed-top">
      <div class="container">
          <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault"
              aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
              <span></span>
              <span></span>
              <span></span>
          </button>
          <a class="navbar-brand text-brand" href="<?php echo e(url('/')); ?>">Posh<span class="color-b">City</span></a>

          <div class="navbar-collapse collapse justify-content-center" id="navbarDefault">
              <ul class="navbar-nav">

                  <li class="nav-item">
                      <a class="nav-link <?php echo e(Route::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link <?php echo e(Route::is('about') ? 'active' : ''); ?>" href="<?php echo e(url('about')); ?>">About</a>
                  </li>

                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle <?php echo e(Route::is('projects') ? 'active' : ''); ?>" href="#" id="navbarDropdown" role="button"
                          data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Our Projects</a>

                      <div class="dropdown-menu">
                          <?php
                              $navbars = App\Models\Project::where('status', '!=', 1)->get();
                          ?>
                          <?php $__currentLoopData = $navbars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navbarItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <a class="dropdown-item" href="<?php echo e(url('projects/'.$navbarItem->id)); ?>"><?php echo e($navbarItem->title); ?></a>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>

                  </li>
                  <li class="nav-item">
                      <a class="nav-link <?php echo e(Route::is('payment-plans') ? 'active' : ''); ?>" href="<?php echo e(url('payment-plans')); ?>">Payment Plan</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link <?php echo e(Route::is('authorize.dealers') ? 'active' : ''); ?>" href="<?php echo e(url('authorize-dealers')); ?>">Our Dealers</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link <?php echo e(Route::is('authenticate') ? 'active' : ''); ?>" href="<?php echo e(url('authenticate-file')); ?>">Authentication</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link <?php echo e(Route::is('contact') ? 'active' : ''); ?>" href="<?php echo e(url('contact')); ?>">Get in Touch</a>
                  </li>
              </ul>
          </div>

          <!-- <button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button> -->

      </div>
  </nav>
  <!-- End Header/Navbar -->
<?php /**PATH C:\xampp\htdocs\posch-city\resources\views/web-side/setup/header.blade.php ENDPATH**/ ?>