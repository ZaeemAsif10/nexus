<?php $__env->startSection('content'); ?>



    <div class="page-wrapper">

        <!-- Page Content -->
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title"><?php echo e($data['letterTitle']); ?></h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Clearance Letter</li>
                        </ul>
                    </div>

                    <div class="col-auto float-right ml-auto">
                        <div class="btn-group btn-group-sm">
                            <button type="submit" class="btn btn-white" id="printBtn"><i class="fa fa-print fa-lg"></i> Print</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            <div class="row">
                <div class="col-md-12">
                    <div class="card" id="tablePrint">
                        <div class="card-body">
                            <h4 class="text-center">EMPLOYEE CLEARANCE CERTIFICATE <br>
                               <span><?php echo e($data['companyName']); ?></span> <br>

                            </h4>


                            <div class="row">
                                <div class="col-sm-6 m-b-20">

                                    <ul class="list-unstyled">
                                        <li><?php echo date('d M Y')?></li>


                                    </ul>
                                </div>

                            </div>


                            <div class="invoice-info">

                                <p contenteditable="true">
                                    His is certify that   <strong><?php echo e($data['employee']->name); ?> </strong> Son/Daughter of
                                    Mr.<strong ><?php echo e($data['employee']->father_name); ?></strong> was employed by
                                    Alpha Buzz Co as <strong ><?php echo e($data['employee']->desig_name); ?></strong>  from
                                    <strong <?php echo e($data['employee']->doj); ?> </strong>to
                                        <strpng ><?php echo e($data['employee']->resign_date); ?> </strpng>
                                    He/She has no standing obligations or accountability to settle with <?php echo e($data['companyName']); ?>. He/She is, thus, cleared of all
                                        accountabilities from the company. so, now, we have no dealings with him.
                                    This certificate of clearance is issued for whatever purpose it may serve best.
                                </p>

                                <p>
                                    Sincerely yours, <br>
                                    Name ………… <br>
                                    Designation …………. <br>
                                    Alpha Buzz Co
                                </p>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Content -->

    </div>

    <script>
        $(document).ready(function() {

            $('#printBtn').on('click', function() {
                $.print("#tablePrint");
            });

        });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/policies/clearance-letter-create.blade.php ENDPATH**/ ?>