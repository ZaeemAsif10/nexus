<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1>Welcome <?php echo e($details['name']); ?></h1>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\posch-city\resources\views/web-side/mail/contact-mail.blade.php ENDPATH**/ ?>