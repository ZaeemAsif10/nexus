<?php $__env->startSection('content'); ?>
    <div class="main-wrapper">
        <!-- /Sidebar -->
        <!-- Page Wrapper -->
        <div class="page-wrapper">
            <!-- Page Content -->
            <div class="content container-fluid">
                <div class="page-header my-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title bold-heading">Role Permissions</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Role Permissions</li>
                            </ul>
                        </div>

                    </div>
                </div>

                <div class="card">
                    <div class="card-body">

                        <form action="<?php echo e(url('test-permissions')); ?>" method="post" id="rolePermission">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <select name="role_id" class="select">
                                            <option value="" selected >--Select--</option>
                                            <?php if(isset($data['roles'])): ?>
                                                <?php $__currentLoopData = $data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>



                            </div>

                            <table class="table table-striped table-hover data-table" >
                                <tbody id="permissionTable">


                                </tbody>

                            </table>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /Page Content -->
        </div>

    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {

            getPermission();
            //get all permisisions in role base
            $('select[name=role_id]').change(function() {
                var role_id = $('select[name=role_id]').val();

                $.ajax({

                    url: '<?php echo e(url("test-permissions")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',
                    data:{role_id:role_id},
                    success: function(data){

                        $('#permissionTable').html(data);
                    },
                    error:function()

                    {
                        toastr.error('something went wrong');
                    }

                });

            });

            $("#permissionTable").delegate(".checkbox","click",function(){

                var role_id=$('select[name=role_id]').val();
                if(!role_id){
                    toastr.error('choose role please');
                    $(this).prop('checked',false);

                }else {
                    var sum_module_id = $(this).attr('data');

                    var status = 0;
                    ($(this).prop("checked") == true) ? status = 1 : status = 0;


                    $.ajax({

                        type: 'ajax',
                        method: 'get',
                        url: '<?php echo e(url("update-role-has-permissions")); ?>',
                        data: {sub_module_id: sum_module_id, status: status, role_id: role_id},
                        async: false,
                        dataType: 'json',
                        beforeSend: function () {

                            // $("#btnSubmit").prop("disabled", true);
                            // $("#btnSubmit").html("loading...");

                        },
                        success: function (data) {
                            console.log(data);
                            if (data.success) {
                                toastr.success(data.success);
                            }
                            if (data.errors) {
                                toastr.error(data.errors);
                            }
                        },

                        complete: function (data) {
                            // $("#btnSubmit").html("Save");
                            // $("#btnSubmit").prop("disabled", false);
                        },
                        error: function () {
                            toastr.error('something went wrong');

                        },

                    });
                }
            });

            function  getPermission(){


                $.ajax({

                    url: '<?php echo e(url("test-permissions")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',

                    success: function(data){

                        $('#permissionTable').html(data);
                    },
                    error:function()

                    {
                        toastr.error('something went wrong');
                    }

                });
            }


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/call-center/roles/permission.blade.php ENDPATH**/ ?>