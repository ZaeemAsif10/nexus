
<section class="section-footer">
  <div class="container text-center text-md-start">
    <div class="row justify-content-center">
      <div class="col-sm-12 col-md-6 col-lg-4">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand">Get in Touch</h3>
          </div>
          <div class="w-body-a">
            <p class="w-text-a color-text-a">
              Skylona Plaza,Sheikh Zayad Sultan Road,<br>Near Giga Mall,Gt Road, DHA II,Islamabad
            </p>
          </div>
          <div class="w-footer-a">
            <ul class="list-unstyled">
              <li class="color-a">
                <span class="color-text-a">For any inquiries, questions or commendations,</span>
              </li>
              <li class="color-a">
                <span class="color-text-a">Phone:</span> 0311-1121244
              </li>
              <li class="color-a">
                <span class="color-text-a">Email:</span> Info@poshcity.pk
              </li>
              <li class="item-list-a">
                Website: <a href="#"> www.poshcity.pk</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-4 section-md-t2">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand">Projects</h3>
          </div>
          <div class="w-body-a">
            <ul class="list-unstyled">
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="#">Posh City</a>
              </li>
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="#">Posh Heights Murree</a>
              </li>
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="#">
                  Posh Farmhouses</a>
              </li>
              <li class="item-list-a">
                <i class="bi bi-chevron-right"></i> <a href="#">Posh Heights Islamabad</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-3 section-md-t2">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand">Subscribe</h3>
          </div>
          <div class="w-body-a">
            <ul class="list-unstyled">
              <li class="item-list-a">
                <p>Subscribe to our newsletter to
                  receive exclusive information </p>
              </li>
              <li class="item-list-a">
                <input type="text" placeholder="Mail"><button class="btn">join</button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <nav class="nav-footer">
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="#">Home</a>
              </li>
              <li class="list-inline-item">
                <a href="#">About</a>
              </li>
              <li class="list-inline-item">
                <a href="#">Payment Plan</a>
              </li>
              <li class="list-inline-item">
                <a href="#">Get in Touch</a>
              </li>
            </ul>
          </nav>
          <div class="socials-a">
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="https://www.facebook.com/poshcitypak" target="_blank">
                  <i class="bi bi-facebook" aria-hidden="true"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="https://twitter.com/poshcitypak" target="_blank">
                  <i class="bi bi-twitter" aria-hidden="true"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="https://www.instagram.com/poshcitypak/" target="_blank">
                  <i class="bi bi-instagram" aria-hidden="true"></i>
                </a>
              </li>
              
            </ul>
          </div>
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright
              <span class="color-a"> by Posh City.</span> All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- End  Footer --><?php /**PATH C:\xampp\htdocs\posh-city\resources\views/web-side/setup/footer.blade.php ENDPATH**/ ?>