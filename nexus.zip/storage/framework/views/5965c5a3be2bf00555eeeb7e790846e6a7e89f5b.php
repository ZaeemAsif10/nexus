

<?php $__env->startSection('content'); ?>

<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Bank</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                        <li class="breadcrumb-item active">Bank</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_bank_modal"><i class="fa fa-plus"></i> Add Bank</a>
                </div>
            </div>
        </div>
        <!-- /Page Header -->

        <div class="row">
            <div class="col-md-12">
                <div>
                    <table class="table table-striped custom-table mb-0 datatable">
                        <thead>
                            <tr>
                                <th style="width: 30px;">#</th>
                                <th>Bank Name</th>
                                <th>Created At</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody id="bankTable">


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <!-- Add Department Modal -->
    <div id="add_bank_modal" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Bank</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="modalDismiss">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(url('bank')); ?>" id="AddBankForm">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Bank Name <span class="text-danger">*</span></label>
                            <input class="form-control" type="text" name="bank_name" required>
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn " type="submit">Submit Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Add Department Modal -->

    <!-- Edit Department Modal -->
    <div id="edit_bank_modal" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Bank</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="btnDissmissEdit">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="EditBankForm" method="post">
                        <input type="hidden" name="bank_id">
                        <div class="form-group">
                            <label>Bank Name <span class="text-danger">*</span></label>
                            <input class="form-control" type="text" name="bank_name">
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn update_bank" id="btnUpdate" type="button">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Edit Department Modal -->


</div>


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- CDN for Sweet Alert -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(document).ready(function() {

        getBank();

        function getBank() {


            $.ajax({

                url: '<?php echo e(url("/get-bank")); ?>',
                type: 'get',
                async: false,
                dataType: 'json',

                success: function(data) {

                    var html = '';
                    var i;
                    var c = 0;

                    for (i = 0; i < data.length; i++) {

                        c++;
                        html += '<tr>' +
                            '<td>' + c + '</td>' +

                            '<td>' + data[i].bank_name + '</td>' +
                            '<td>' + data[i].created_at + '</td>' +

                            '<td class="text-right">' +
                            '<div class="dropdown dropdown-action">' +
                            '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>' +
                            '<div class="dropdown-menu dropdown-menu-right">' +
                            '<a class="dropdown-item btn_edit_bank" href="#" data-toggle="modal"  data="' + data[i].id + '"><i class="fa fa-pencil m-r-5n "></i> Edit</a>' +
                            '<a class="dropdown-item btn_delete_bank" href="#" " data="' + data[i].id + '"><i class="fa fa-trash-o m-r-5 "></i> Delete</a>' +
                            '</div>' +
                            '</div>' +
                            '</td>' +

                            '</tr>';
                    }


                    $('#bankTable').html(html);

                },
                error: function() {
                    toastr.error('something went wrong');
                }

            });
        }

        // save designation
        $('#AddBankForm').on('submit', function(e) {
            e.preventDefault();

            var formData = $('#AddBankForm').serialize();

            $.ajax({

                type: 'ajax',
                method: 'post',
                url: '<?php echo e(url("bank")); ?>',
                data: formData,
                async: false,
                dataType: 'json',
                success: function(data) {


                    if (data.success) {
                        $('#add_bank_modal').modal('hide');
                        getBank();
                        $('#AddBankForm')[0].reset();
                        toastr.success(data.success);
                    }


                },

                error: function() {
                    toastr.error('something went wrong');

                }

            });



        });


        //edit data
        $('#bankTable').on('click', '.btn_edit_bank', function() {


            var id = $(this).attr('data');

            $('#edit_bank_modal').modal('show');

            $.ajax({

                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("edit-bank")); ?>',
                data: {
                    id: id
                },
                async: false,
                dataType: 'json',
                success: function(data) {

                    $('input[name=bank_id]').val(data.id);
                    $('input[name=bank_name]').val(data.bank_name);



                },

                error: function() {

                    toastr.error('something went wrong');

                }

            });




        });


        //update designation
        $('.update_bank').on('click', function() {


            var formData = $('#EditBankForm').serialize();

            $.ajax({

                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("udpate-bank")); ?>',
                data: formData,
                async: false,
                dataType: 'json',
                success: function(data) {

                    getBank();
                    $('#edit_bank_modal').modal('hide');
                    toastr.success(data.success);



                },

                error: function() {
                    toastr.error('something went wrong');

                }

            });

        });


        // script for delete data
        $('#bankTable').on('click', '.btn_delete_bank', function(e) {
            e.preventDefault();

            var id = $(this).attr('data');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to Delete this Data!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(url('/delete-bank/')); ?>/" + id,
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        dataType: "json",
                        success: function(response) {
                            toastr.success(response.success);
                            getBank();
                        }
                    });
                }
            })

        });


    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zaeem-code\resources\views/bank/index.blade.php ENDPATH**/ ?>