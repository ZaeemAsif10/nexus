<!-- Sidebar -->

<style>
    .menuss-active {
        color: #006dce !important;
    }
</style>

<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>

                <?php if(Auth::user()->role == 'admin'): ?>
                    <li>
                        <a href="<?php echo e(url('admin')); ?>" class=""><i class="la la-dashboard"></i><span> Dashboard </span></a> </li>

                    <li class="submenu">
                        <a href="#" class=""><i class="la la-project-diagram"></i> <span>Project Management</span> <span
                                class="menu-arrow"></span></a>
                        <ul
                            <?php if(Route::is('projects') || Route::is('project/details')): ?> style="display: block;"
                            <?php else: ?>
                            style="display: none;" <?php endif; ?>>

                            <li><a  href="<?php echo e(route('features')); ?>"> <span>Features & Amenities</span></a> </li>

                            <li>
                                <a class="<?php echo e(Route::is('projects') ? 'menuss-active' : ''); ?>"
                                    href="<?php echo e(route('projects')); ?>"> <span>Projects</span></a>
                            </li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#" class=""><i class="la la-users"></i> <span>Peoples</span>
                            <span class="menu-arrow"></span></a>
                        <ul
                            <?php if(Route::is('dealers')): ?> style="display: block;"
                            <?php else: ?>
                            style="display: none;" <?php endif; ?>>
                            <li>
                                <a class="<?php echo e(Route::is('dealers') ? 'menuss-active' : ''); ?>"
                                    href="<?php echo e(route('dealers')); ?>"> <span>Dealers Management</span></a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('customers')); ?>"> <span>Customers Management</span></a>
                            </li>
                        </ul>
                    </li>


                    <li>
                        <a class="<?php echo e(Route::is('contact-list') ? 'menuss-active' : ''); ?>"
                           href="<?php echo e(route('contact-list')); ?>"><i class="la la-comment"></i> <span>Get In Touch Queries</span></a>
                    </li>

                    <li>
                        <a class="<?php echo e(Route::is('payment-plan') ? 'menuss-active' : ''); ?>"
                           href="<?php echo e(route('payment-plan')); ?>"><i class="fa fa-paypal"></i> <span>Payment Plans</span></a>
                    </li>




                    <li class="submenu">
                        <a href="#" class="">
                            <i class="la la-file"></i> <span>Inventory/Stock </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li>
                                <a class="" href="<?php echo e(url('products')); ?>"> <span>Products Management</span></a>
                                <a class="" href="<?php echo e(url('files')); ?>"> <span>Files Management</span></a>
                                <a class="" href="<?php echo e(url('issue-files')); ?>"> <span>Issue Files</span></a>
                                <a class="" href="<?php echo e(url('processing-files')); ?>"> <span>Processing Files</span></a>
                            </li>
                        </ul>
                    </li>


                <?php endif; ?>


            <?php if(Auth::user()->role == 'client'): ?>

                <li><a class="" href="<?php echo e(url('/admin')); ?>"> <span>Dashboard</span></a></li>

                <li class="submenu">
                    <a href="#" class="">
                        <i class="la la-user"></i> <span>My Invoices </span> <span
                            class="menu-arrow"></span></a>
                    <ul>
                        <li>
                            <a class="" href="<?php echo e(url('my-invoices')); ?>"> <span>My Invoices</span></a>

                        </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
<?php /**PATH C:\xampp\htdocs\poshcity\resources\views/setup/sidebar.blade.php ENDPATH**/ ?>