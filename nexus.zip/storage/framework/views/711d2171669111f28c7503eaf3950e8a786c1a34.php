<?php $__env->startSection('content'); ?>


    <style type="text/css">
        body {
            font-family: Arial;
            font-size: 10pt;
        }
    </style>
    </style>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <!-- Page Header -->
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Sale Report</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Sale Report</li>
                        </ul>
                    </div>


                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(url('sale-report')); ?>" method="POST" id="saleFilter">
                        <?php echo csrf_field(); ?>
                        <div class="row filter-row">
                            <div class="col-sm-6 col-md-3">
                                <div class="form-group">
                                    <label class="focus-label">From Date</label>
                                    <input type="date" name="from" class="form-control">
                                </div>
                            </div>

                            <div class="col-sm-6 col-md-3">
                                <div class="form-group">
                                    <label class="focus-label">To Date</label>
                                    <input type="date" name="to" class="form-control">
                                </div>
                            </div>

                            <div class="col-sm-6 col-md-2">
                                <label for=""></label>
                                <button type="submit" class="btn btn-primary btn-block searchDate"> <i class="fa fa-search"></i> </button>
                            </div>


                        </div>
                    </form>
                </div>
            </div>
            <table class="table table-bordered mt-5 table-hover table-striped" id="datatable">
                <thead>
                <tr class="bold-tr">
                    <th># </th>
                    <th>INV#</th>
                    <th>Client Name </th>
                    <th>Amount </th>
                    <th>Comment </th>
                    <th>Created At </th>
                    <th>Action </th>

                </tr>
                </thead>
                <tbody>
                <!-- <?php $c=0; ?> -->
                <?php if(isset( $data['sale_invoices'])): ?>
                    <?php $__currentLoopData = $data['sale_invoices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- <?php $c++; ?> -->
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td>INV-<?php echo e($invoice->id); ?></td>
                            <td><?php echo e($invoice->name); ?></td>
                            <td> <?php echo e($invoice->amount); ?></td>
                            <td><?php echo e($invoice->comment); ?></td>
                            <td><?php echo e($invoice->created_at); ?></td>
                            <td class="text-center"><a href="<?php echo e(url('invoice-details/').'/'.encrypt($invoice->id).'/sale-report'); ?>" title="view details"><i class="fa fa-eye"></i></a></td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
    <!-- /Page Content -->
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {

            //Datatables
            $('#datatable').DataTable();


            $('.searchDate').on('click', function() {
                $(".searchDate").prop("disabled", true);
                $(".searchDate").html("Please wait...");
                $('#saleFilter').submit();
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/reports/sale-report.blade.php ENDPATH**/ ?>