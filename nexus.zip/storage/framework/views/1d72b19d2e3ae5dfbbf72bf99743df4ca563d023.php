
<?php $__env->startSection('content'); ?>


<style type="text/css">
    body {
        font-family: Arial;
        font-size: 10pt;
    }
</style>
</style>
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title bold-heading">Sale Report</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Sale Report</li>
                    </ul>
                </div>


            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <!-- <form action="" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row filter-row">
                        <input type="hidden" name="search" value="1">

                        <div class="col-sm-6 col-md-3">
                            <div class="form-group form-focus">

                                <select class="livesearch form-control p-3" name="emp_id"></select>
                                <label class="focus-label">Vandor Name</label>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="form-group form-focus">
                                <div class="cal">
                                    <select class="form-control floating select " name="search_month">
                                        <option value="">Month</option>
                                        <option value="1">Jan</option>
                                        <option value="2">Feb </option>
                                        <option value="3">Mar</option>
                                        <option value="4">Apr</option>
                                        <option value="5">May</option>
                                        <option value="6">June</option>
                                        <option value="7">Jul</option>
                                        <option value="8">Aug</option>
                                        <option value="9">Sep</option>
                                        <option value="10">Oct</option>
                                        <option value="11">Nov</option>
                                        <option value="12">Dec</option>

                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="form-group form-focus">
                                <div class="cal">
                                    <select class="form-control floating select" name="year">
                                        <option value="">Year</option>
                                        <?php for($y=2021; $y<=date('Y');$y++): ?>
                                            <option  value="<?php echo e($y); ?>"><?php echo e($y); ?> </option>
                                        <?php endfor; ?>

                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-md-2">
                            <button type="submit" class="btn btn-success btn-block"> Search </button>
                        </div>


                    </div>
                </form> -->
                <table class="table table-bordered mt-5 table-hover table-striped" id="datatable">
                    <thead>
                        <tr class="bold-tr">
                            <th># </th>
                            <th>INV#</th>
                            <th>Client Name </th>
                            <th>Amount </th>
                            <th>Comment </th>
                            <th>Created At </th>
                            <th>Action </th>

                        </tr>
                    </thead>
                    <tbody>
                        <!-- <?php $c=0; ?> -->
                        <?php if(isset( $data['sale_invoices'])): ?>
                        <?php $__currentLoopData = $data['sale_invoices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- <?php $c++; ?> -->
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td>INV-<?php echo e($invoice->id); ?></td>
                            <td><?php echo e($invoice->name); ?></td>
                            <td><?php echo e($invoice->amount); ?></td>
                            <td><?php echo e($invoice->comment); ?></td>
                            <td><?php echo e($invoice->created_at); ?></td>
                            <td class="text-center"><a href="<?php echo e(url('invoice-details/').'/'.encrypt($invoice->id).'/sale-report'); ?>" title="view details"><i class="fa fa-eye"></i></a></td>


                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
        <!-- /Page Content -->
    </div>


    <script>
        $(document).ready(function() {

            //Datatables
            $('#datatable').DataTable();
        });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/reports/sale-report.blade.php ENDPATH**/ ?>