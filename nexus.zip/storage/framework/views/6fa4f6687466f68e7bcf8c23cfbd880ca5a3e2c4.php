<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('public/assets/img/logo/favicon.png')); ?>">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
    <title>HRM</title>
</head>
<style>
    html{
        overflow-x: hidden;
        margin: 0px;
        padding: 0px;
    }
    body {
        overflow-x: hidden;
        margin: 0px;
        padding: 0px;
    }
    .login-section .left-login {
        padding: 7rem 4rem;
    }
    .login-section .head {
        font-size: 20px;
        color: #ab72c3;
        margin-left: 6px;
    }
    .login-section .input {
        border: 2px solid #9d66b0;
        border-radius: 25px;
        padding: 12px 15px;
    }
    .form-control:focus {
        box-shadow: none;
    }
    .login-section .btn-login {
        padding: 10px 30px;
        background-color: #a52ada;
        border-radius: 30px;
        color: #fff;
        font-weight: bold;
    }
    .login-section .right-img{
        width: 100%;
        height: 100vh;
        background-size: 100% 100%;
    }
    /* Media Quires  Start*/
    @media  screen and (max-width: 767px){
        .login-section .btn-login {
            padding: 10px 30px;
            font-size: 13px;
        }
        .login-section .left-login {
            padding: 14rem 3rem;
        }
        .login-section .right-img {
            display: none;
        }
        .login-section .ddd{
            text-align: center;
        }
    }
    @media  screen and (max-width: 400px){
        .login-section .left-login {
            padding: 14rem 2rem;
        }
    }
</style>
<body>
<section class="login-section">
    <div class="row">
        <div class="col-lg-8 col-md-8" id="right-col">
            <img src="<?php echo e(asset('public/assets/img/login/login-screen-image.jpg')); ?>" class="img-fluid right-img" alt="">
        </div>
        <div class="col-lg-4 col-md-4">
            <div class="left-login">
                <form method="POST" action="<?php echo e(route('login')); ?>">


                    <input type="hidden" name="latitude" id="latitude">
                    <input type="hidden" name="longitude" id="longitude">

                    <?php echo csrf_field(); ?>
                    <p class="head">Login to your Account</p>
                    <?php if($message=Session::get('error')): ?>
                        <span class="text-center text-danger"> <?php echo e($message); ?></span>
                    <?php endif; ?>
                    <div class="form-group mt-5">
                        <input type="text" class="form-control input" placeholder="example@gmail.com" name="email"  id="username" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control mt-4 input" placeholder="Password" name="password" id="password" required>
                    </div>

                    <div class="ddd">
                        <button  class="btn btn-defalut btn-login mt-4 ml-2">Login </button>
                    </div>
                    <div class="ddd">
                        <a  clas="mt-5 ml-3"  style="font-size:12px" href="<?php echo e(url('password/reset')); ?>">Forgot Password</a> <br>
                        <a  style="font-size:12px" href="<?php echo e(url('job/list')); ?>">Apply For Job</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
</body>
</html>



<div id="x"></div>
<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>

<script type="text/javascript" defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAB6y4kRx41p5krahkuc_dT2n5HJJwQP7w&amp"></script>



<script type="text/javascript">
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (p) {
            var LatLng = new google.maps.LatLng(p.coords.latitude, p.coords.longitude);

            //document.getElementById('x').innerHTML = "Latitude: "+p.coords.latitude+"<br>Longitude: "+p.coords.longitude;
            document.getElementById('latitude').value = p.coords.latitude;
            document.getElementById('longitude').value = p.coords.longitude;

            var mapOptions = {
                center: LatLng,
                zoom: 13,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
            var marker = new google.maps.Marker({
                position: LatLng,
                map: map,
                title: "<div style = 'height:60px;width:200px'><b>Your location:</b><br />Latitude: " + p.coords.latitude + "<br />Longitude: " + p.coords.longitude
            });
            google.maps.event.addListener(marker, "click", function (e) {
                var infoWindow = new google.maps.InfoWindow();
                infoWindow.setContent(marker.title);
                infoWindow.open(map, marker);
            });
        });
    } else {
        alert('Geo Location feature is not supported in this browser.');
    }
</script>






<?php /**PATH /home/alphmnju/hrm.alphabuzzco.com/resources/views/auth/login.blade.php ENDPATH**/ ?>