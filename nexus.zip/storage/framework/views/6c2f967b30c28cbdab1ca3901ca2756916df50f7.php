
<?php $__env->startSection('content'); ?>

<div class="page-wrapper">

    <style>
        .leave-img {
            width: 126%;
            border-radius: 40px;
        }
    </style>

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Leaves</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Leaves</li>
                    </ul>
                </div>

            </div>
        </div>
        <!-- /Page Header -->

        <!-- Leave Statistics -->
        <div class="row">
            <div class="col-md-3">
                <div class="stats-info">
                    <h6> Leaves Request</h6>
                    <h4><?php echo e($data['totalRequest']); ?> <span>Today</span></h4>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-info">
                    <h6>Approved Request</h6>
                    <h4><?php echo e($data['approvedRequest']); ?> <span>Today</span></h4>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stats-info">
                    <h6>Pending Requests</h6>
                    <h4><?php echo e($data['pendingRequest']); ?> <span>Today</span></h4>
                </div>
            </div>


            <div class="col-md-3">
                <div class="stats-info">
                    <h6>Decline Request</h6>
                    <h4><?php echo e($data['declineRequest']); ?> <span>Today</span></h4>
                </div>
            </div>
        </div>
        <!-- /Leave Statistics -->



        <!-- Search Filter -->
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(url('leaves-request')); ?>" method="post" id="searchForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="getdata" value="1">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <select name="company_id" class="select">
                                    <option value="" selected disabled>Choose Company</option>
                                    <?php if(isset($data['company'])): ?>
                                    <?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($comp->id); ?>"><?php echo e($comp->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <select name="desg_id" class="select">
                                    <option value="" selected disabled>Choose Department</option>
                                    <?php if(isset($data['department'])): ?>
                                    <?php $__currentLoopData = $data['department']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->departments); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="Search Employee Name">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Search Filter -->



        <div class="card">
            <div class="card-body">
                <div class="row mt-3">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-striped table-responsive" id="datatable">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Leave Type</th>
                                        <th>From</th>
                                        <th>To</th>
                                        <th>No of Days</th>
                                        <th>Reason</th>
                                        <th class="text-center">Status</th>

                                    </tr>
                                </thead>
                                <tbody id="leaveTable">



                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Page Content -->


</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $(document).ready(function() {

        getLeaves();

        function getLeaves() {


            $.ajax({

                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("leaves-request")); ?>',
                async: false,
                dataType: 'json',
                data: {
                    getdata: 1
                },
                success: function(data) {
                    var html = '';
                    var i;
                    var c = 0;
                    var class_name = '';

                    for (i = 0; i < data.length; i++) {
                        (data[i].leave_status == 'APPROVED') ? class_name = 'text-success': class_name = 'text-danger';


                        c++;

                        html += '<tr>' +
                            '<td>' +
                            '<h2 class="table-avatar">' +
                            ' <a href="#"><img alt="" class="target-img" src="storage/app/public/uploads/staff-images/' + data[i].image + '"></a>' +
                            ' <a>' + data[i].emp_name + ' <span>' + data[i].desig_name + '</span></a>' +
                            ' </h2>' +
                            '</td>' +
                            '<td>' + data[i].leave_type + '</td>' +
                            '<td>' + data[i].from + '</td>' +
                            '<td>' + data[i].to + '</td>' +
                            '<td>2 days</td>' +
                            '<td>' + data[i].reason + '</td>' +
                            '<td class="text-center">' +
                            '<div class="dropdown action-label">' +
                            ' <a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">' +
                            ' <i class="fa fa-dot-circle-o ' + class_name + '"></i> ' + data[i].leave_status + ' </a>' +

                            '       <div class="dropdown-menu dropdown-menu-right">' +

                            '           <a class="dropdown-item btn-status" id=' + data[i].id + '  leave_status="pending"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>' +
                            '           <a class="dropdown-item btn-status" id=' + data[i].id + '  leave_status="approved" data-toggle="modal" data-target="#approve_leave"><i class="fa fa-dot-circle-o text-success"></i> Approved</a>' +
                            '           <a class="dropdown-item btn-status" id=' + data[i].id + '  leave_status="declined"><i class="fa fa-dot-circle-o text-danger"></i> Declined</a>' +
                            '       </div>' +
                            '   </div>' +
                            '</td>' +

                            '</tr>';
                    }


                    $('#leaveTable').html(html);

                },

                error: function() {
                    toastr.error('something went wrong');

                }

            });
        }

        //ajax call for serach record
        $('#searchForm').on('submit', function(e) {
            e.preventDefault();

            var formData = $('#searchForm').serialize();

            $.ajax({

                type: 'ajax',
                method: 'post',
                url: '<?php echo e(url("leaves-request")); ?>',
                data: formData,
                async: false,
                dataType: 'json',
                success: function(data) {
                    var html = '';
                    var i;
                    var c = 0;
                    var class_name = '';

                    for (i = 0; i < data.length; i++) {
                        (data[i].leave_status == 'APPROVED') ? class_name = 'text-success': class_name = 'text-danger';


                        c++;

                        html += '<tr>' +
                            '<td>' +
                            '<h2 class="table-avatar">' +
                            ' <a href="#"><img alt="" class="target-img" src="storage/app/public/uploads/staff-images/' + data[i].image + '"></a>' +
                            ' <a>' + data[i].emp_name + ' <span>' + data[i].desig_name + '</span></a>' +
                            ' </h2>' +
                            '</td>' +
                            '<td>' + data[i].leave_type + '</td>' +
                            '<td>' + data[i].from + '</td>' +
                            '<td>' + data[i].to + '</td>' +
                            '<td>2 days</td>' +
                            '<td>' + data[i].reason + '</td>' +
                            '<td class="text-center">' +
                            '<div class="dropdown action-label">' +
                            ' <a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">' +
                            ' <i class="fa fa-dot-circle-o ' + class_name + '"></i> ' + data[i].leave_status + ' </a>' +

                            '       <div class="dropdown-menu dropdown-menu-right">' +

                            '           <a class="dropdown-item btn-status" id=' + data[i].id + '  leave_status="pending"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>' +
                            '           <a class="dropdown-item btn-status" id=' + data[i].id + '  leave_status="approved" data-toggle="modal" data-target="#approve_leave"><i class="fa fa-dot-circle-o text-success"></i> Approved</a>' +
                            '           <a class="dropdown-item btn-status" id=' + data[i].id + '  leave_status="declined"><i class="fa fa-dot-circle-o text-danger"></i> Declined</a>' +
                            '       </div>' +
                            '   </div>' +
                            '</td>' +

                            '</tr>';
                    }


                    $('#leaveTable').html(html);

                },
                error: function() {
                    toastr.error('something went wrong');

                },
            });
        });

        $('#leaveTable').on('click', '.btn-status', function() {


            var leave_status = $(this).attr('leave_status');
            var id = $(this).attr('id');


            $.ajax({

                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("update-leave-request")); ?>',
                data: {
                    id: id,
                    leaves: leave_status
                },
                async: false,
                dataType: 'json',
                success: function(data) {

                    console.log(data);
                    if (data.success) {
                        getLeaves();
                        toastr.success(data.success);

                    }


                },

                error: function() {

                    // toastr.error('something went wrong');

                }

            });



        });

        //Datatables
        $('#datatable').DataTable();

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/leaves/leaves-request.blade.php ENDPATH**/ ?>