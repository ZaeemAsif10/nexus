<?php $__env->startSection('content'); ?>


<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>


<div class="main-wrapper">

	<style>
		.att-btn{
            width: 72%;
        }
	</style>

	<!-- /Sidebar -->

	<!-- Page Wrapper -->
	<div class="page-wrapper">

		<!-- Page Content -->
		<div class="content container-fluid">

			<!-- Page Header -->
			<div class="page-header">
				<div class="row">
					<div class="col-sm-12">
						<h3 class="page-title">Attendance Reports</h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
							<li class="breadcrumb-item active">Attendance Reports</li>
						</ul>
					</div>
				</div>

			</div>
			<!-- /Page Header -->



			<div class="card">
				<div class="card-body">
					<!-- <h4 class="card-title">Solid justified</h4> -->
					<ul class="nav nav-tabs nav-tabs-solid nav-justified">
						<li class="nav-item"><a class="nav-link att-btn" href="<?php echo e(url('att-dashboard')); ?>">Dashboard</a></li>

						<li class="nav-item"><a class="nav-link att-btn" href="<?php echo e(url('attendance')); ?>">Mark Attendance</a></li>
						<li class="nav-item"><a class="nav-link att-btn" href="<?php echo e(url('view-attendance')); ?>">View Attendance</a></li>
						<li class="nav-item"><a class="nav-link att-btn active" href="<?php echo e(url('attendance-reports')); ?>">Attendance Reports</a></li>

					</ul>
				</div>

			</div>

			<!-- Search Filter -->
			<form action="<?php echo e(url('attendance-reports')); ?>" method="post">
				<input type="hidden" name="search" value="1">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-2">
						<div class="form-group">
						<select name="company_id" class="select">
									<option value="" selected disabled>Choose Company</option>
									<?php if(isset($data['company'])): ?>
										<?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($comp->id); ?>"><?php echo e($comp->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<select class="livesearch form-control p-3" name="emp_id">
								<option value="" selected disabled>Choose Employee Name</option>
							</select>
						</div>
					</div>
					<div class="col-md-2">
						<div class="cal">

							<select class="select " name="search_month">
								<option value="" selected disabled>Choose Month</option>
								<option value="1">Jan</option>
								<option value="2">Feb </option>
								<option value="3">Mar</option>
								<option value="4">Apr</option>
								<option value="5">May</option>
								<option value="6">June</option>
								<option value="7">Jul</option>
								<option value="8">Aug</option>
								<option value="9">Sep</option>
								<option value="10">Oct</option>
								<option value="11">Nov</option>
								<option value="12">Dec</option>

							</select>
						</div>
					</div>
					<div class="col-md-2">
						<div class="cal">

							<select class="select" name="year">
								<option value="">Choose Year</option>
								<?php for($y=2021; $y<=date('Y');$y++): ?> <option value="<?php echo e($y); ?>"><?php echo e($y); ?> </option>
									<?php endfor; ?>

							</select>
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<button type="submit" class="btn btn-primary btn-block"> Search </button>
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<button class="btn btn-white" id="btnExport">Export</button>
						</div>
					</div>
				</div>
			</form>
			<!-- Search Filter -->

			<div class="row">
				<div class="col-md-12">
					<div class="table-responsive">
						<table class="table table-striped custom-table mb-0 datatable" id="tblPdf">
							<thead>
								<tr>
									<th>#</th>
									<th>Employee</th>
									<th>Date</th>
									<th>Clock In</th>
									<th>Clock Out</th>
									<th> Status</th>
								</tr>
							</thead>
							<tbody>
								<?php $c=0; ?>
								<?php if(isset($data['report'])): ?>
								<?php $__currentLoopData = $data['report']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $c++ ?>
								<tr>
									<td><?php echo e($c); ?></td>
									<td>
										<h2 class="table-avatar">
											<a href="#"><img alt="" class="target-img" src="<?php echo e(asset('storage/app/public/uploads/staff-images/').'/'.$report->image); ?>"></a>
											<a href="#"><?php echo e($report->name); ?><span><?php echo e($report->desig_name); ?></span></a>
										</h2>
									</td>
									<td><?php echo e(date('d M Y',strtotime($report->date))); ?></td>
									<?php if($report->status=='Present'): ?>
									<td><?php echo e(date('H:i:s a',strtotime($report->created_at))); ?></td>
									<?php else: ?>
									<td>-</td>
									<?php endif; ?>
									<?php if($report->chek_out==1): ?>
									<td><?php echo e($report->updated_at); ?></td>
									<?php else: ?>
									<td>-</td>
									<?php endif; ?>
									<td><?php echo e($report->status); ?></td>

								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>

							</tbody>
						</table>
					</div>
				</div>
			</div>

			<!-- /Content End -->

		</div>
		<!-- /Page Content -->

	</div>
	<!-- /Page Wrapper -->



</div>



<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script type="text/javascript">
	$("body").on("click", "#btnExport", function() {
		html2canvas($('#tblPdf')[0], {
			onrendered: function(canvas) {
				var data = canvas.toDataURL();
				var docDefinition = {
					content: [{
						image: data,
						width: 500
					}]
				};
				pdfMake.createPdf(docDefinition).download("Table.pdf");
			}
		});
	});
</script>

<script type="text/javascript">
	$('.livesearch').select2({

		ajax: {
			url: '<?php echo e(url("ajax-autocomplete-search")); ?>',
			dataType: 'json',
			delay: 250,
			processResults: function(data) {
				console.log(data);
				return {
					results: $.map(data, function(item) {
						return {
							text: item.name,
							id: item.id
						}
					})
				};
			},
			cache: true
		}
	});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/attendance/att-reports.blade.php ENDPATH**/ ?>