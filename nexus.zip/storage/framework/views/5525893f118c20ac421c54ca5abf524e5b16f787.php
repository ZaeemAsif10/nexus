
<?php $__env->startSection('content'); ?>
    <style type="text/css">
        body {
            font-family: Arial;
            font-size: 10pt;
        }
        table {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th,
        table td {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">

            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Files</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Files List</li>
                        </ul>
                    </div>

                    <div class="col-auto float-right ml-auto">
                        <a href="<?php echo e(url('create-file')); ?>" class="btn add-btn"
                           title="Add New File"><i class="fa fa-plus" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">

                    <table class="table table-striped table-hover" id="datatable">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Project</th>
                            <th>Files</th>
                            <th>Type</th>
                            <th>Size</th>
                            <th>Dealer Name</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if(isset($data['files'])): ?>
                            <?php $__currentLoopData = $data['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($file->projects['title']); ?></td>
                                    <td><?php echo e($file->reg_no); ?></td>
                                    <td><?php echo e($file->type); ?></td>
                                    <td><?php echo e($file->products['item']); ?></td>
                                    <td>
                                        <?php if($file->dealer_id > 0): ?>
                                    <?php
                                        echo $dealerName= App\Models\Dealer::getAllDealerName(1)
                                         ?>
                                        <?php else: ?>
                                     -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <tr>
                            <td colspan="12">
                                <div class="float-right">
                                    <?php echo e($data['files']->links('pagination::bootstrap-4')); ?>

                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <!-- tabel end -->
                </div>
            </div>
            <!-- /Page Content -->
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posch-city\resources\views/admin/stock/files-list.blade.php ENDPATH**/ ?>