<?php $__env->startSection('content'); ?>


<style type="text/css">
    body {
        font-family: Arial;
        font-size: 10pt;
    }
</style>
</style>
<div class="page-wrapper">
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title bold-heading">Invoice Details</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Invoice Details</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="<?php echo e(url('sale-report')); ?>" class="btn add-btn" title="Back"><i class="fas fa-arrow-left"></i></a>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        <div class="card">
            <div class="card-body">



                <table class="table table-bordered mt-5 table-hover table-striped">
                    <thead>
                    <tr class="bold-tr">
                        <th># </th>
                        <th>Item </th>
                        <th>Qty </th>
                        <th>Price </th>
                        <?php if(isset($data['is_purchase'])): ?>
                        <th>Sale Price </th>
                        <?php endif; ?>
                        <th>Sub Total</th>
                        <th>Created At </th>

                    </tr>
                    </thead>
                    <tbody id="purchaseTable">
                    <?php $c=0;
                     $subTotal=0;
                     $grandTotal=0;

                    ?>
                    <?php if(isset($data['invoice_items'])): ?>
                        <?php $__currentLoopData = $data['invoice_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $c++;
                            $subTotal=$items->qty * $items->price;
                            $grandTotal=$grandTotal+ $subTotal;
                            ?>
                            <tr>
                                <td><?php echo e($c); ?></td>
                                <td><?php echo e($items->item); ?> <?php echo e(($items->reg_no)? '-'.$items->reg_no:''); ?></td>
                                <td><?php echo e($items->qty); ?></td>
                                <td><?php echo e($items->price); ?></td>
                                <?php if(isset($data['is_purchase'])): ?>
                                <td><?php echo e($items->sale_price); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($subTotal); ?></td>
                                <td><?php echo e($items->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr>
                        <td  colspan="4">
                            <div class="float-right"><strong> Grand Total: </strong></div>
                        </td>
                        <td> <strong><?php echo e($grandTotal); ?> </strong></td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- /Page Content -->
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/reports/invoice-details.blade.php ENDPATH**/ ?>