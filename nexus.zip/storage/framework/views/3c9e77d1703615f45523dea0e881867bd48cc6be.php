
<!-- Header -->
<div class="header">

    <!-- Logo -->

    <?php
    $company=App\Models\Company::first();
    ?>
    <div class="header-left">
        <a href="<?php echo e(url('/')); ?>" class="logo">
            <?php if($company): ?>
            <img src="<?php echo e(asset('storage/app/public/uploads/company-assets/').'/'.$company->logo); ?>"  alt="Logo"  width="40" height="40">
            <?php else: ?>
            <img src="<?php echo e(asset('public/assets/img/logo/logo.png')); ?>" width="40" height="40" alt="Logo" >
                <?php endif; ?>
        </a>
    </div>
    <!-- /Logo -->

    <a id="toggle_btn" href="javascript:void(0);">
					<span class="bar-icon">
						<span></span>
						<span></span>
						<span></span>
					</span>
    </a>

    <!-- Header Title -->
    <div class="page-title-box">
        <?php if($company): ?>
        <h3><?php echo e($company->name); ?></h3>
        <?php else: ?>
            <h3>Alpha Buzz Co</h3>
            <?php endif; ?>
    </div>
    <!-- /Header Title -->

    <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>

    <!-- Header Menu -->
    <ul class="nav user-menu">

        <!-- Search -->
        <li class="nav-item">
            <div class="top-nav-search">
                <a href="javascript:void(0);" class="responsive-search">
                    <i class="fa fa-search"></i>
                </a>
                <form action="#">
                    <input class="form-control" type="text" placeholder="Search here">
                    <button class="btn" type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
        </li>
        <!-- /Search -->

        <!-- Flag -->
        <li class="nav-item dropdown has-arrow flag-nav">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button">
                <img src="<?php echo e(asset('public/assets/img/flags/us.png')); ?>" alt="" height="20"> <span>English</span>
            </a>

        </li>
        <!-- /Flag -->

        <!-- Notifications -->
        <li class="nav-item dropdown">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <i class="fa fa-bell-o"></i> <span class="badge badge-pill">0</span>
            </a>
            <div class="dropdown-menu notifications">
                <div class="topnav-dropdown-header">
                    <span class="notification-title">Notifications</span>
                    <a href="javascript:void(0)" class="clear-noti"> Clear All </a>
                </div>
                <div class="noti-content">
                    <ul class="notification-list">

                        <li class="notification-message">
                            <a href="#">
                                <div class="media">
												<span class="avatar">
													<img alt="" src="<?php echo e(asset('public/assets/img/profiles/avatar-02.jpg')); ?>">
												</span>
                                    <div class="media-body">
                                        <p class="noti-details"><span class="noti-title">John Doe</span> added new task <span class="noti-title">Patient appointment booking</span></p>
                                        <p class="noti-time"><span class="notification-time">4 mins ago</span></p>
                                    </div>
                                </div>
                            </a>
                        </li>

                    </ul>
                </div>
                <div class="topnav-dropdown-footer">
                    <a href="#">View all Notifications</a>
                </div>
            </div>
        </li>
        <!-- /Notifications -->

        <!-- Message Notifications -->
        <!-- /Message Notifications -->

        <li class="nav-item dropdown has-arrow main-drop">
            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">

                <?php if(auth()): ?>
                    <?php
                    $id=auth()->user()->account_id;
                   $res= App\Models\Employee::find($id);

                    if($res){
                $image=$res->image;
                    }else{
                    $image='user1-128x128.png';
                    }

                    ?>
                <?php endif; ?>


							<span class="user-img"><img src="<?php echo e(asset('storage/app/public/uploads/staff-images/').'/'.$image); ?>" >


							<span class="status online"></span></span>
                <span>    <?php if(auth()): ?> <?php echo e(auth()->user()->name); ?> <?php endif; ?> </span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo e(url('my-profile')); ?>">My Profile</a>
                <a class="dropdown-item" href="<?php echo e(url('logout')); ?>">Logout</a>
            </div>
        </li>
    </ul>
    <!-- /Header Menu -->

    <!-- Mobile Menu -->
    <div class="dropdown mobile-user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="<?php echo e(url('my-profile')); ?>">My Profile</a>

            <a class="dropdown-item" href="<?php echo e(url('logout')); ?>">Logout</a>
        </div>
    </div>
    <!-- /Mobile Menu -->

</div>
<!-- /Header -->
<?php /**PATH C:\xampp\htdocs\zaeem-code\resources\views/setup/header.blade.php ENDPATH**/ ?>