

<?php $__env->startSection('content'); ?>
    <main id="main">
        <!-- ======= breadcrump section ======= -->
        <section class="intro-single">
            <div class="container-fluid ">
                <div class="row about-breadcrump text-center gx-0">
                    <div class="col-md-12">
                        <div class="title-single-box">
                            <h1 class="title-single text-white">
                                <?php echo e($data['web_project']->title ?? ''); ?></h1>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active text-white-50" aria-current="page">
                                    <?php echo e($data['web_project']->title ?? ''); ?>

                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!-- End breadcrump section-->

        <!-- ======= Testimonials Section ======= -->
        <section class="section-testimonials mt-5 nav-arrow-a">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-wrap d-flex justify-content-between">
                            <div class="title-box">
                                <h1><?php echo e($data['web_project']->title ?? ''); ?></h1>
                                <div class="ass mb-2"></div>
                            </div>
                        </div>
                    </div>
                </div>


                <div id="testimonial-carousel" class="swiper">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $data['pro_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item-a swiper-slide">
                                <div class="testimonials-box">
                                    <div class="row text-center">
                                        <div class="col-sm-12 col-md-6">
                                            <div class="testimonial-img">
                                                <img src="<?php echo e(asset('storage/app/public/uploads/project/images/' . $project_img->p_images)); ?>"
                                                    alt="" class="img-fluid" style="height: 18rem;">
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-6">
                                            <div class="testimonial-ico">
                                                
                                                <img src="<?php echo e(asset('public/web-assets/img/logo/details.png')); ?>"
                                                    alt="">
                                            </div>
                                            <div class="testimonials-content">
                                                <p class="testimonial-text">
                                                    <?php echo e($project_img->img_description ?? ''); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- End carousel item -->
                    </div>
                </div>
                

            </div>
        </section>
        <!-- End Testimonials Section -->


        
        <section class="section-partner mt-5">
            <div class="container">
                <div class="row">
                    <h2 class="text-center text-black"><span class="color-b">WHAT MAKES US UNIQUE</span></h2>
                    <div class="ass m-auto"></div>
                </div>
                <div class="row mt-4 text-center">

                    <div class="col-md-4">
                        <img src="<?php echo e(asset('public/web-assets/img/comunity/GatedCommunity1.png')); ?>" alt=""
                            class="uniq_img" srcset="">
                        <p class="mt-3 img-p">
                            Posh City is a Gated Community. It is a concept of modern lifestyle to ensure safety and surety
                            of the residents in any housing society.
                        </p>
                    </div>

                    <div class="col-md-4">
                        <img src="<?php echo e(asset('public/web-assets/img/comunity/Serene Outdoor-01.png')); ?>" alt=""
                            class="uniq_img" srcset="">
                        <p class="mt-3 img-p">
                            The luxurious living in Posh City is surrounded by lush green parks and green belts all around
                            to get feel of pleasant nature.
                        </p>
                    </div>

                    <div class="col-md-4">
                        <img src="<?php echo e(asset('public/web-assets/img/comunity/Uitilites Supply-01.png')); ?>" alt=""
                            class="uniq_img" srcset="">
                        <p class="mt-3 img-p">
                            Posh City is ensuring the provision of utilities like 24/7 electricity, gas and water supply
                            along with modern sewage system & garbage collection at doorstep etc.
                        </p>
                    </div>

                    <div class="col-md-4">
                        <img src="<?php echo e(asset('public/web-assets/img/comunity/TREATMENT PLANT-01.png')); ?>" alt=""
                            class="uniq_img" srcset="">
                        <p class="mt-3 img-p">
                            To prevent the contamination and water and environment, the latest technology sewage treatment
                            plant has been installed in Posh City.
                        </p>
                    </div>

                    <div class="col-md-4">
                        <img src="<?php echo e(asset('public/web-assets/img/comunity/WATER-01.png')); ?>" alt=""
                            class="uniq_img" srcset="">
                        <p class="mt-3 img-p">
                            Posh City is making sure the purity to be delivered to the people. To supply pure water to the
                            residents, the German Technology plant has been installed.
                        </p>
                    </div>


                    <div class="col-md-4">
                        <img src="<?php echo e(asset('public/web-assets/img/comunity/COMMERCIAL-01.png')); ?>" alt=""
                            class="uniq_img" srcset="">
                        <p class="mt-3 img-p">
                            Posh City is going to be next commercial hub. The sky-high buildings in the business zone will
                            be creating immense business opportunities for the people; in and around the society.
                        </p>
                    </div>

                </div>
            </div>
        </section>
        

        
        <section class="project-section mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        
                        <h3>Project Detail</h3>
                        
                        <p class="mt-4">
                            <?php echo e($data['web_project']->description ?? ''); ?>

                        </p>
                        
                        <p style="font-size: 18px;" class="color-b pt-3 text-center">"NEEDS AND LUXURIES, BOTH ARE CATERED
                            UNDER ONE ROOF"</p>
                    </div>

                    <div class="col-md-6">

                        <h3 class="text-center">Features & Amenities </h3>

                        <?php if(count($data['pro_features']) > 0): ?>
                            <div class="row size-row mt-5">
                                <?php $__currentLoopData = $data['pro_features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro_feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-4 mb-3">
                                        <div class="row">
                                            <div class="col-3 m-auto">
                                                <img src="<?php echo e(asset('storage/app/public/uploads/features/' . $pro_feature->feture->icon ?? '')); ?>"
                                                    class="fe-img" alt="">
                                            </div>
                                            <div class="col-9">
                                                
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        

                    </div>
                </div>
            </div>
        </section>
        

    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/poshcity/resources/views/web-side/projects.blade.php ENDPATH**/ ?>