<?php $__env->startSection('content'); ?>


            <div class="page-wrapper">

				<!-- Page Content -->
                <div class="content container-fluid">

					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<h3 class="page-title">Profile</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Profile</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
                    <?php if($data['employee']): ?>
					<div class="card mb-0">
						<div class="card-body">

							<div class="row">
								<div class="col-md-12">
									<div class="profile-view">
										<div class="profile-img-wrap">
											<div class="profile-img">
												<a href="#">

                                                    <img src="<?php echo e(asset('storage/app/public/uploads/staff-images/').'/'.$data['employee']->image); ?>" alt="">

                                                </a>
											</div>
										</div>
										<div class="profile-basic">
											<div class="row">
												<div class="col-md-5">
													<div class="profile-info-left">
														<h3 class="user-name m-t-0 mb-0"><?php echo e(empty($data['employee']->name) ? '' : $data['employee']->name); ?></h3>
														<h6 class="text-muted"><?php echo e(empty($data['employee']->desig_name) ? '' : $data['employee']->desig_name); ?></h6>

														<div class="staff-id">Employee ID : <?php echo e(empty($data['employee']->id) ? '' : $data['employee']->id); ?></div>
														<div class="small doj text-muted">Date of Join : <?php echo e(empty($data['employee']->doj) ? '' : $data['employee']->doj); ?></div>

													</div>
												</div>
												<div class="col-md-7">
													<ul class="personal-info">
														<li>
															<div class="title">Phone:</div>
															<div class="text"><a href=""><?php echo e(empty($data['employee']->phone) ? '' : $data['employee']->phone); ?></a></div>
														</li>
														<li>
															<div class="title">Email:</div>
															<div class="text"><a href=""><?php echo e(empty($data['employee']->email) ? '' : $data['employee']->email); ?></a></div>
														</li>
														<li>
															<div class="title">Birthday:</div>
															<div class="text"><?php echo e(empty($data['employee']->dob) ? '' : $data['employee']->dob); ?></div>
														</li>
														<li>
															<div class="title">Address:</div>
															<div class="text">1861 Bayonne Ave, Manchester Township, NJ, 08759</div>
														</li>
														<li>
															<div class="title">CNIC:</div>
															<div class="text"><?php echo e(empty($data['employee']->cnic) ? '' : $data['employee']->cnic); ?></div>
														</li>

														<li>
															<div class="title">Bank No:</div>
															<div class="text"><?php echo e(empty($data['employee']->bank_ac_no) ? '' : $data['employee']->bank_ac_no); ?></div>
														</li>

														<li>
															<div class="title">Nationality:</div>
															<div class="text"><?php echo e(empty($data['employee']->nationality) ? '' : $data['employee']->nationality); ?></div>
														</li>

														<li>
															<div class="title">Gross Salary:</div>
															<div class="text"><?php echo e(empty($data['employee']->gross_salary) ? '' : $data['employee']->gross_salary); ?></div>
														</li>

													</ul>
												</div>
											</div>
										</div>
                                        <?php if($data['employee']): ?>
										<div class="pro-edit"><a  class="edit-" href="<?php echo e(url('edit-employee').'/'.encrypt($data['employee']->id)); ?>"><i class="fa fa-pencil"></i>edit</a></div>
									<?php endif; ?>
                                    </div>


								</div>
							</div>
						</div>
					</div>
					<div class="tab-content">

						<!-- Profile Info Tab -->
						<div id="emp_profile" class="pro-overview tab-pane fade show active">

							<div class="row">
								<div class="col-md-12 d-flex">
									<div class="card profile-box flex-fill">
										<div class="card-body">
											<h3 class="card-title">Bank information</h3>
											<ul class="personal-info">
												<li>
													<div class="title">Bank name</div>

													<div class="text"><?php echo e(empty($data['employee']->bank_id) ? '' : 'Meezan Bank'); ?></div>
												</li>
												<li>
													<div class="title">Bank account No.</div>
													<div class="text"><?php echo e(empty($data['employee']->bank_ac_no) ? '' : $data['employee']->bank_ac_no); ?></div>
												</li>

											</ul>
										</div>
									</div>
								</div>

							</div>


							<div class="row">

								<div class="col-md-6 d-flex">
									<div class="card profile-box flex-fill">
										<div class="card-body">
											<h3 class="card-title">Education Informations <a href="#" class="edit-icon" data-toggle="modal" data-target="#education_info"><i class="fa fa-pencil"></i></a></h3>
											<div class="experience-box">
												<ul class="experience-list">

                                                    <?php if(isset($data['qualification'])): ?>
                                                        <?php $__currentLoopData = $data['qualification']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

													<li>
														<div class="experience-user">
															<div class="before-circle"></div>
														</div>
														<div class="experience-content">
															<div class="timeline-content">
																<a href="#/" class="name"><?php echo e(empty($edu->institute) ? '' : $edu->institute); ?></a>
																<div><?php echo e(empty($edu->qualification) ? '' : $edu->qualification); ?></div>
																<span class="time"><?php echo e(empty($edu->from) ? '' : date('Y', strtotime($edu->from))); ?> - <?php echo e(empty($edu->to) ? '' : date('Y', strtotime($edu->to))); ?></span>
															</div>
														</div>
													</li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

												</ul>
											</div>
										</div>
									</div>
								</div>


								<div class="col-md-6 d-flex">
									<div class="card profile-box flex-fill">
										<div class="card-body">
											<h3 class="card-title">Experience <a href="#" class="edit-icon" data-toggle="modal" data-target="#experience_info"><i class="fa fa-pencil"></i></a></h3>
											<div class="experience-box">
												<ul class="experience-list">

                                                    <?php if(isset($data['experience'])): ?>
                                                        <?php $__currentLoopData = $data['experience']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

													<li>
														<div class="experience-user">
															<div class="before-circle"></div>
														</div>
														<div class="experience-content">
															<div class="timeline-content">
																<a href="#/" class="name"><?php echo e(empty($exp->position) ? '' : $exp->position); ?></a>
                                                                <?php

                                                                $diff = abs(strtotime($exp->start_date) - strtotime($exp->end_date));

                                                                $years = floor($diff / (365*60*60*24));
                                                                $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                                                $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                                                                ?>
																<span class="time"><?php echo e($years. '-'. $months.'-'.$days); ?> </span>
															</div>
														</div>
													</li>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>



                            <div class="row">
                                <div class="col-md-12 d-flex">
                                    <div class="card profile-box flex-fill">
                                        <div class="card-body">
                                            <h3 class="card-title">Certifications</h3>
                                            <?php if(isset($data['certifications'])): ?>
                                            <ul class="personal-info">
                                                <li>
                                                    <div class="title">Course Titile</div>

                                                    <div class="text"><?php echo e(empty($data['certifications']->course_title) ? '' :$data['certifications']->course_title); ?></div>
                                                </li>
                                                <li>
                                                    <div class="title">Durations</div>
                                                    <div class="text"><?php echo e(empty($data['certifications']->duration_period) ? '' : $data['certifications']->duration_period); ?></div>
                                                </li>

                                            </ul>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
						</div>
						<!-- /Profile Info Tab -->



					</div>
                    <?php endif; ?>
                </div>
				<!-- /Page Content -->

            </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/hrm.alphabuzzco.com/resources/views/profile/index.blade.php ENDPATH**/ ?>