<?php $__env->startSection('content'); ?>


<div class="page-wrapper">

	<!-- Page Content -->
	<div class="content container-fluid">

		<!-- Page Header -->
		<div class="page-header">
			<div class="row align-items-center">
				<div class="col">
					<h3 class="page-title">Employee</h3>
					<ul class="breadcrumb">
						<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
						<li class="breadcrumb-item active">Employee</li>
					</ul>
				</div>
				<div class="col-auto float-right ml-auto">
					<a href="<?php echo e(url('/new-employee')); ?>" class="btn add-btn"><i class="fa fa-plus"></i> Add Employee</a>
					<div class="view-icons">
						<a href="<?php echo e(url('employees')); ?>" class="grid-view btn btn-link active"><i class="fa fa-th"></i></a>
						<a href="<?php echo e(url('employees-list')); ?>" class="list-view btn btn-link"><i class="fa fa-bars"></i></a>
					</div>
				</div>
			</div>
		</div>
		<!-- /Page Header -->

		<!-- Search Filter -->
		<form action="<?php echo e(url('employees')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<div class="row filter-row">

				<div class="col-sm-6 col-md-3">
					<div class="form-group form-focus">
						<input type="hidden" name="search" value="1">
						<input type="text" class="form-control floating" name="emp_id">
						<label class="focus-label">Employee ID</label>
					</div>
				</div>
				<div class="col-sm-6 col-md-3">
					<div class="form-group form-focus">
						<input type="text" class="form-control floating" name="emp_name">
						<label class="focus-label">Employee Name</label>
					</div>
				</div>
				<div class="col-sm-6 col-md-3">
					<div class="form-group form-focus select-focus">
						<select class="select floating" name="desig_id">
							<option value=""> Designation</option>
							<?php if(isset($data['designation'])): ?>
							<?php $__currentLoopData = $data['designation']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($desig->id); ?>"><?php echo e($desig->desig_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>

						</select>
					</div>
				</div>
				<div class="col-sm-6 col-md-3">
					<button type="submit" class="btn btn-success btn-block"> Search </button>
				</div>

			</div>
		</form>
		<!-- Search Filter -->

		<div class="row staff-grid-row">
			<?php if(isset($data['employee'])): ?>
			<?php $__currentLoopData = $data['employee']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
				<div class="profile-widget">
					<div class="profile-img">
						<a href="<?php echo e(url('user-profile/').'/'.encrypt($emp->id)); ?>">
							<img src="<?php echo e(asset('storage/app/public/uploads/staff-images/').'/'.$emp->image); ?>" class="avatar" alt="">
						</a>
					</div>
					<div class="dropdown profile-action">
						<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
						<div class="dropdown-menu dropdown-menu-right">
							<a class="dropdown-item" href="<?php echo e(url('edit-employee/'.encrypt($emp->id))); ?>" data="<?php echo e($emp->id); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
							<a class="dropdown-item btn-delete" href="#" data="<?php echo e($emp->id); ?>"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
						</div>
					</div>
					<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="<?php echo e(url('profile')); ?>"><?php echo e($emp->name); ?></a></h4>
					<div class="small text-muted"><?php echo e($emp->desig_name); ?></div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>

		<div class="float-right">
			<?php echo e($data['employee']->links('pagination::bootstrap-4')); ?>

		</div>

	</div>
	<!-- /Page Content -->




	<!-- Delete Employee Modal -->
	<div class="modal custom-modal fade" id="delete_employee" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
					<div class="form-header">
						<h3>Delete Employee</h3>
						<p>Are you sure want to delete?</p>
					</div>
					<div class="modal-btn delete-action">
						<div class="row">
							<div class="col-6">
								<a href="javascript:void(0);" class="btn btn-primary continue-btn deleteNow">Delete</a>
							</div>
							<div class="col-6">
								<a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /Delete Employee Modal -->

</div>


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
	$(document).ready(function() {


		$('.btn-delete').on('click', function() {


			var emp_id = $(this).attr('data');
			$('#delete_employee').modal('show');




			$('.deleteNow').on('click', function() {


				$.ajax({

					type: 'ajax',
					method: 'get',
					url: '<?php echo e(url("delete-employee")); ?>',
					data: {
						emp_id: emp_id
					},
					async: false,
					dataType: 'json',
					success: function(data) {


						if (data.success) {

							toastr.success(data.success);
							$('#delete_employee').modal('hide');
						}
						window.location.reload();



					},

					error: function() {

						toastr.error('something went wrong');

					}

				});

			});


		});

	})
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zaeem-code\resources\views/employee/index.blade.php ENDPATH**/ ?>