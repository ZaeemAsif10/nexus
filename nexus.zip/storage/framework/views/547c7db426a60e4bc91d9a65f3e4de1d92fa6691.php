
                                    <div class="form-group">

                                        <select name="dead_reason" id="" class="form-control">
                                            <option value="1">Dead Reason</option>
                                            <option value="2">Political Reason</option>
                                            <option value="3">Economic Reason</option>
                                            <option value="4">Out of Budget</option>
                                            <option value="5">Not Interested In Properties</option>

                                        </select>
                                    </div>
<?php /**PATH /home/u443729190/domains/shahraantech.com/public_html/rgms/resources/views/call-center/leads/dead-reasons.blade.php ENDPATH**/ ?>