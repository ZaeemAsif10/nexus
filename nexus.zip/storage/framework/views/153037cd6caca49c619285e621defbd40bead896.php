

<?php $__env->startSection('content'); ?>
    <main id="main">
        <!-- ======= Intro Single ======= -->
        <section class="intro-single">
            <div class="container-fluid ">
                <div class="row about-breadcrump text-center gx-0">
                    <div class="col-md-12">
                        <div class="title-single-box">
                            <h1 class="title-single text-white">
                                AUTHORISE DEALERS</h1>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active text-white-50" aria-current="page">
                                    AUTHORISE DEALERS
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Intro Single-->


        <!-- ======= Authorise Dealers Section ======= -->
        <?php if(count($data['dealers']) > 0): ?>
            <section class="section-property pro-card section-t8">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="title-wrap d-flex justify-content-between">
                                <div class="title-box">
                                    <h2 class="title-a text-black">Our <span class="color-b"> Dealers</span></h2>
                                </div>
                            </div>
                        </div>

                        <?php $__currentLoopData = $data['dealers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-12 col-md-6 col-lg-4 mb-4">
                                <div class="card-box-d">
                                    <div class="card-img-d">
                                        <img src="<?php echo e(asset('storage/app/public/uploads/dealers/' . $dealer->image ?? '')); ?>"
                                            alt="" class="img-d img-fluid dealer-img">
                                    </div>
                                    <div class="card-overlay card-overlay-hover">
                                        <div class="card-header-d">
                                            <div class="card-title-d align-self-center">
                                                <h3 class="title-d">
                                                    <a href="#"
                                                        class="link-two"><?php echo e($dealer->firm_name ?? ''); ?></a>
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="card-body-d">
                                            <div class="info-agents color-a">
                                                <p>
                                                    <strong>Phone: </strong> <?php echo e($dealer->phone ?? ''); ?>

                                                </p>
                                                
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </section>

            
            
            
            
        <?php endif; ?>
        <!-- End Authorise Dealers Section Section -->


    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posch-city\resources\views/web-side/dealers.blade.php ENDPATH**/ ?>