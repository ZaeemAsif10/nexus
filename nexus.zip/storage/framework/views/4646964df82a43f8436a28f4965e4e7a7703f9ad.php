
<?php $__env->startSection('content'); ?>
<!-- Page Wrapper -->
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Edit Employee</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Edit Employee</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="<?php echo e(url('recruitment/new')); ?>" class="btn add-btn"><i class="fa fa-plus"></i>Employees</a>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        <div class="row">
            <div class="col-lg-12">
                <form method="post" action="<?php echo e(url('update-employee')); ?>" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php if(isset($data['employeeData'])): ?>
                    <?php $__currentLoopData = $data['employeeData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeeData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Personal Information</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">

                                <div class="form-group col-sm-4">
                                    <label>Company <span class="text-danger">*</span></label>
                                    <!--  -->

                                    <select name="company_id" class="form-control selectpicker" data-container="body" data-live-search="true" title="Choose Company">

                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data['companies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($company->id); ?>"
                                        <?php if($employeeData->company_id == $company->id): ?> selected <?php endif; ?>
                                        ><?php echo e($company->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="form-group col-sm-4">
                                    <label>Departments <span class="text-danger">*</span></label>
                                    <select class="form-control selectpicker" data-container="body" data-live-search="true" name="dept_id" id="showDept" data-container="body" data-live-search="true">
                                        <option value="">Choose Department</option>
                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data['department']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dept->id); ?>"
                                        <?php if($employeeData->dept_id == $dept->id): ?> selected <?php endif; ?>
                                        ><?php echo e($dept->departments); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </select>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Designation <span class="text-danger">*</span></label>
                                    <select class="form-control selectpicker" data-container="body" data-live-search="true" id="showDesig" name="designation" data-container="body" data-live-search="true">
                                        <option value="">Choose Designation</option>
                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data['desig']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($designation->id); ?>"
                                        <?php if($employeeData->desg_id == $designation->id): ?> selected <?php endif; ?>
                                        ><?php echo e($designation->desig_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                            </div>
                            <div class="row">
                                <input type="hidden" name="hidden_emp_id" value="<?php echo e($employeeData->id); ?>">
                                <div class="form-group col-md-3 col-sm-4">
                                    <label>Employee ID <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="employee_ID" placeholder="employee_ID" value="<?php echo e($employeeData->emp_id); ?>">
                                </div>
                                <div class="form-group col-md-3 col-sm-4">
                                    <label>Name <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="name" placeholder="Name" required value="<?php echo e($employeeData->name); ?>">
                                </div>
                                <div class="form-group col-md-3 col-sm-4">
                                    <label>Email <span class="text-danger">*</span></label>
                                    <input class="form-control" type="email" name="email" placeholder="Email" required value="<?php echo e($employeeData->email); ?>">
                                </div>
                                <div class="form-group col-md-3 col-sm-4">
                                    <label>Father Name <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="father_name" placeholder="Father Name" required value="<?php echo e($employeeData->father_name); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>CNIC <span class="text-danger">*</span></label>
                                    <input class="form-control" type="number" name="cnic" placeholder="CNIC" required value="<?php echo e($employeeData->cnic); ?>">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Phone <span class="text-danger">*</span></label>
                                    <input class="form-control" type="number" name="phone" placeholder="Phone" required value="<?php echo e($employeeData->phone); ?>">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>DOB <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="dob" required value="<?php echo e($employeeData->dob); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Marital Status <span class="text-danger">*</span></label>
                                    <select class="select" name="marital_status" id="marital_status" required>
                                        <option value="">Choose Status</option>
                                        <option value="married" <?php
                                                                if ($employeeData->marital_status == 'married') {
                                                                    echo "selected";
                                                                }
                                                                ?>>Married</option>
                                        <option value="un_married" <?php
                                                                    if ($employeeData->marital_status == 'un_married') {
                                                                        echo "selected";
                                                                    }
                                                                    ?>>UnMarried</option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Probation Period <span class="text-danger">*</span></label>
                                    <input class="form-control" type="number" name="prob" placeholder="Probation Period In Month" required value="<?php echo e($employeeData->prob_period); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Grade <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="grade" placeholder="Grade" required value="<?php echo e($employeeData->grade); ?>">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Nationality <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="nationality" placeholder="Nationality" required value="<?php echo e($employeeData->nationality); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Gross Salary <span class="text-danger">*</span></label>
                                    <input class="form-control" type="number" name="salary" placeholder="Gross Salary" required value="<?php echo e($employeeData->gross_salary); ?>">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Date Of Joining <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="doj" required value="<?php echo e($employeeData->doj); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Bank Name <span class="text-danger"></span></label>
                                    <select class="select" name="bank_id" required>
                                        <option value="1" <?php
                                                            if ($employeeData->bank_id == 1) {
                                                                echo "selected";
                                                            }
                                                            ?>>Choose Bank</option>
                                        <option value="2" <?php
                                                            if ($employeeData->bank_id == 2) {
                                                                echo "selected";
                                                            }
                                                            ?>>HBL</option>
                                        <option value="3" <?php
                                                            if ($employeeData->bank_id == 3) {
                                                                echo "selected";
                                                            }
                                                            ?>>Bank Al Habib</option>
                                        <option value="4" <?php
                                                            if ($employeeData->bank_id == 4) {
                                                                echo "selected";
                                                            }
                                                            ?>>MCB</option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Account# <span class="text-danger"></span></label>
                                    <input class="form-control" type="number" name="bank_ac_no" required placeholder="Bank Ac number" value="<?php echo e($employeeData->bank_ac_no); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Qualification Details</h4>
                        </div>
                        <?php if(isset($data['qualification'])): ?>
                        <?php $__currentLoopData = $data['qualification']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label">Qualification</label>
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" placeholder="Qualification" name="qualification" required value="<?php echo e($qua->qualification); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label">Institute</label>
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" name="institute" placeholder="Institute" required value="<?php echo e($qua->institute); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label">From</label>
                                        <div class="col-lg-9">
                                            <input type="date" class="form-control" name="from" placeholder="From" required value="<?php echo e($qua->from); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label">To</label>
                                        <div class="col-lg-9">
                                            <input type="date" class="form-control" name="to" placeholder="To" required value="<?php echo e($qua->to); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xl-6">
                                    <div class="form-group row">
                                        <label class="col-lg-3 col-form-label">Devision/CGPA</label>
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" placeholder="Devision/CGPA" name="cgpa" required value="<?php echo e($qua->cgpa); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Professional Certifications</h4>
                        </div>
                        <div class="card-body">
                            <?php if(isset($data['certification'])): ?>
                            <?php $__currentLoopData = $data['certification']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-xl-4">
                                    <div class="form-group row">
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" placeholder="Course Title" name="course_title" required value="<?php echo e($cer->course_title); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4">
                                    <div class="form-group row">
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" name="exp_organization" placeholder="organization" required value="<?php echo e($cer->orgnazations); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4">
                                    <div class="form-group row">
                                        <div class="col-lg-9">
                                            <input type="text" class="form-control" name="period" placeholder="Duration Period" required value="<?php echo e($cer->duration_period); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Employment Experience</h4>
                        </div>
                        <?php if(isset($data['experience'])): ?>
                        <?php $__currentLoopData = $data['experience']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label>Position <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="position" placeholder="Position" required value="<?php echo e($exp->position); ?>">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Skills <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="skill" placeholder="Skills" required value="<?php echo e($exp->skills); ?>">
                                </div>
                                <div class="form-group col-sm-4">
                                    <label>Organization <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="relevent_exp_organization" placeholder="Organization" required value="<?php echo e($exp->organization); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Start Date <span class="text-danger">*</span></label>
                                    <input class="form-control" type="date" name="start_date" placeholder="Start Date" required value="<?php echo e($exp->start_date); ?>">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>End Date <span class="text-danger">*</span></label>
                                    <input class="form-control" type="date" name="end_date" placeholder="End Date" required value="<?php echo e($exp->end_date); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Annual Duration <span class="text-danger">*</span></label>
                                    <input class="form-control" type="number" name="annual_duartion" placeholder="Annual Duration In Years" required value="<?php echo e($exp->annual_duration); ?>">
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Relevant Experience <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="relevent_exp" placeholder="End Date" required value="<?php echo e($exp->exp); ?>">
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xl-4">
                                </div>
                                <div class="col-xl-4">
                                    <div class="col-auto float-right ml-auto">
                                        <button class="btn add-btn" type="submit">Update</button>
                                    </div>
                                </div>
                                <div class="col-xl-4">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Page Content -->
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type='text/javascript'>
    $(document).ready(function() {



        // $('#deptId').change(function(){
        //     var dept_id=$('select[name=dept_name]').val();

        //     $.ajax({

        //         type: 'ajax',

        //         method: 'get',

        //         url: '<?php echo e(url("/getDesignations")); ?>',

        //         data: {dept_id: dept_id},

        //         async: false,

        //         dataType: 'json',

        //         success: function(data) {

        //             var html = '';

        //             var i;
        //             if(data.length > 0) {

        //                 for (i = 0; i < data.length; i++) {

        //                     html += '<option value="' + data[i].id + '">' + data[i].desig_name + '</option>';

        //                 }
        //             }else{
        //                 var html = '<option value="">Choose Designation</option>';
        //                 toastr.error('data not found');
        //             }


        //             $('#showDesig').html(html);

        //         },

        //         error: function() {

        //             alert('Could not get Data from Database');

        //         }

        //     });
        // });



        //company_id
        // $('select[name=company_id]').change(function(){
                var company_id=$('select[name=company_id]').val();


                $.ajax({

                    type: 'ajax',

                    method: 'get',

                    url: '<?php echo e(url("/getDeptRespectToCompany")); ?>',

                    data: {company_id: company_id},

                    async: false,

                    dataType: 'json',

                    success: function(data) {


                        var html = '<option value=""> Choose Dept</option>';

                        var i;
                        if(data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].departments + '</option>';

                            }
                        }else{
                            var html = '<option value="">Choose Dept</option>';
                            toastr.error('data not found');
                        }


                        $('#showDept').html(html);

                    },

                    error: function() {

                        toastr.error('db error');


                    }

                });
            });


            //dept
            $('#showDept').change(function(){
                var dept_id=$('select[name=dept_name]').val();

                $.ajax({

                    type: 'ajax',

                    method: 'get',

                    url: '<?php echo e(url("/getDesignations")); ?>',

                    data: {dept_id: dept_id},

                    async: false,

                    dataType: 'json',

                    success: function(data) {

                        var html = '';

                        var i;
                        if(data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].desig_name + '</option>';

                            }
                        }else{
                            var html = '<option value="">Choose Designation</option>';
                            toastr.error('data not found');
                        }


                        $('#showDesig').html(html);

                    },

                    error: function() {

                        alert('Could not get Data from Database');

                    }

                });
            });





    })
</script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
<script>
    <?php if(count($errors) > 0): ?>

    <?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    toastr.error("<?php echo e($error); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <?php if(Session::has('success')): ?>
    toastr.success("Record save updated successfully!");
    window.location.href = "<?php echo e(url('employees')); ?>";

    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/employee/edit-employee-list.blade.php ENDPATH**/ ?>