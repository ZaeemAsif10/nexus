<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">My Tasks</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">My Tasks</li>
                        </ul>
                    </div>

                </div>
            </div>

            <div class="tab-content">

                <!-- Profile Info Tab -->
                <div id="emp_profile" class="pro-overview tab-pane fade show active">

                    <div class="row">
                        <?php if(isset($data['empTasks'])): ?>
                            <?php $__currentLoopData = $data['empTasks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $progress=App\Models\SubTask::getTaskProgress($task->id);
                                $deadLineClass='success';
                                if($task->end_date < date('Y-m-d')){
                                    $deadLineClass='danger';
                                }


                                ?>
                                <div class="col-md-6 d-flex">
                                    <div class="card profile-box flex-fill">
                                        <div class="card-body">

                                            <span class="card-title">
                                                <div class="pro-progress">
                                                    <div class="pro-progress-bar">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-success" role="progressbar"
                                                                 style="width:<?php echo e(round($progress)); ?>%"></div>
                                                        </div>
                                                        <span><?php echo e(round($progress)); ?>%</span>
                                                    </div>
                                                </div>

                                            </span>
                                            <ul class="personal-info">
                                                <li>
                                                    <div class="title">Title.</div>
                                                    <div class="text badge bg-inverse-info"><?php echo e($task->task); ?>

                                                    </div>
                                                </li>
                                                <?php
                                                    $subTask =App\Models\SubTask::getSubTaskAcordingMainTask($task->id);

                                                ?>
                                                <?php if($subTask->count() > 0): ?>
                                                    <li>
                                                        <div class="title">Sub Task: </div>
                                                        <div class="text">
                                                            <?php $__currentLoopData = $subTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subTask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="text badge bg-inverse-primary"> <?php echo e($subTask->sub_task_title); ?>

                                                                   <checkbox class="bg-inverse-success" href="">
                                                                            <input type="checkbox"  <?php if($subTask->status==1): ?> checked    <?php endif; ?> class="mt-1 ml-1 btn-complete" data="<?php echo e($subTask->id); ?>" style="background-color: #0b2e13">
                                                                   </checkbox> </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                                <li>
                                                    <div class="title">Dead Line.</div>
                                                    <div class="text badge bg-inverse-<?php echo e($deadLineClass); ?>"><?php echo e($task->end_date); ?></div>
                                                </li>
                                                <li>
                                                    <div class="title">Description</div>
                                                    <div class="text">
                                                        <?php echo e($task->desc); ?>

                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="title">Created At</div>
                                                    <div class="text">
                                                        <?php echo e($task->created_at); ?>

                                                    </div>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /Profile Info Tab -->
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {

            $('.btn-complete').click(function() {
                var id = $(this).attr('data');
                var status = 0;
                ($(this).prop("checked") == true) ? status = 1 : status = 0;
                $.ajax({
                    url: '<?php echo e(url("mark-sub-task")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',
                    data:{id:id,status:status},
                    success: function(data){
                      if(data.success){
                          toastr.success(data.success);
                      }
                    },
                    error:function()
                    {
                        toastr.error('something went wrong');
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/tasks/my-daily-tasks.blade.php ENDPATH**/ ?>