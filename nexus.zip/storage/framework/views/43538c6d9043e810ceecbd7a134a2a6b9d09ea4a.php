<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

    <style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        table
        {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th
        {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th, table td
        {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Payments Vochar</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Payments Vochar</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="#payments-list" class="btn add-btn" title="Payments List"><i class="fa fa-list" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>


            <div class="card">
                <div class="card-body">
                    <form method="post" id="PaymentsForm" class="needs-validation" novalidate action="<?php echo e(url('payments')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Account Type</label>
                                    <select class="select" name="ac_type" required>
                                        <option value="">Choose Type</option>
                                        <option value="vendors">Vendors</option>
                                        <option value="clients">Customers</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please choose account type.
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label id="ac_label">Account</label>
                                    <select class="select" name="ac_id" required id="showAccounts" class="form-control">
                                        <option value="">Choose Account</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please choose account.
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Date</label>
                                    <input type="date" class="form-control" required name="date" >
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Transaction Mode</label>
                                    <select class="select" name="trans_mode" required>
                                        <option value="">Choose One</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Bank</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Please choose transaction mode.
                                    </div>
                                </div>
                            </div>


                            <div class="col-sm-4 bank_section" style="display:none">
                                <div class="form-group">
                                    <label>Bank</label>
                                    <select name="bank_id" id="" class="form-control">
                                        <option value="">Choose Bank</option>
                                        <?php if(isset($data['banks'])): ?>
                                            <?php $__currentLoopData = $data['banks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->bank_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4 bank_section" style="display:none">
                                <div class="form-group">
                                    <label>Bank Branches</label>
                                    <select  id="showBranch" class="form-control" name="branch_id">
                                        <option value="">Choose Branch</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4 cash_section" style="display:none">
                                <div class="form-group">
                                    <label>Pay Through</label>
                                    <select name="company_account_id" id="" class="form-control">
                                        <option value="">Choose Account</option>
                                        <?php if(isset($data['accounts'])): ?>
                                            <?php $__currentLoopData = $data['accounts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($accounts->id); ?>"><?php echo e($accounts->achead['ac_head']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="row">


                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Payment Amount</label>
                                    <input type="number" name="payment_amount" class="form-control" placeholder="Payment Amount" required>
                                    <div class="balance-error"></div>
                                </div>
                            </div>
                            <div class="col-sm-8">
                                <div class="form-group">
                                    <label>Narration</label>
                                    <input type="text" class="form-control" required name="desc" placeholder="Description">
                                </div>
                            </div>
                        </div>

                        <div class="float-right">
                            <button class="btn btn-success btn-submit" type="submit" id="btnSubmit">Save Now</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="my-header">
                <div class="row">
                    <form method="post" class="needs-validation" novalidate action="" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-sm-3 col-md-3">
                                <div class="form-group">
                                    <label>Account Type</label>
                                    <select class="select" name="ac_type" required>
                                        <option value="">Choose Type</option>
                                        <option value="vendors">Vendors</option>
                                        <option value="clients">Clients</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-md-3">
                                <div class="form-group">
                                    <label>Account</label>
                                    <select class="select" name="ac_id" required id="showAccounts1">
                                        <option value="">Choose Account</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-md-2">
                                <div class="form-group">
                                    <label>To:</label>
                                    <input type="date" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label>From:</label>
                                    <input type="date" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <div class="form-group">
                                    <label for=""></label>
                                    <button class="btn btn-success mt-2">Search</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped" id="payments-list">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Ac Type</th>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Receipt Amount</th>
                            <th>Paid Amount</th>
                            <th>Balance</th>
                        </tr>
                        <tbody>
                        <?php $c=0;
                  $subTotal=0;
                        ?>
                        <?php if(isset($data['transaction'])): ?>
                            <?php $__currentLoopData = $data['transaction']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $c++;
                  $subTotal=$subTotal+$trans['amount'];
                                ?>
                                <tr>
                                    <td><?php echo e($c); ?></td>
                                    <?php
                                        $res='';
                                        if($trans->ac_type=='VENDORS'){
                                        $res=App\Models\Vendor::find($trans->ac_id);
                                        }
                                        if($trans->ac_type=='CLIENTS'){
                                        $res=App\Models\Client::find($trans->ac_id);
                                        }
                                    ?>
                                    <td><?php echo e(($res)?$res->name:''); ?></td>
                                    <td><?php echo e($trans['ac_type']); ?></td>
                                    <td><?php echo e($trans['desc']); ?></td>
                                    <td><?php echo e(date('d-M-Y',strtotime($trans['created_at']))); ?></td>
                                    <td>-</td>
                                    <td><?php echo e(number_format($trans['amount'],2)); ?></td>
                                    <td><?php echo e(number_format($trans['balance'],2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <tr>
                            <td>
                                <div class="float-right"> <strong>Total:</strong></div>
                            </td>
                            <td colspan="6">
                                <div class="float-right"> <strong> <?php echo e(number_format($subTotal,2)); ?> PKR</strong></div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type='text/javascript'>
        $(document).ready(function (){


            $('select[name=ac_type]').change(function(){
                var ac_type=$('select[name=ac_type]').val();



                (ac_type=='vendors')? $('#ac_label').html('Vendors'):$('#ac_label').html('Customers')


                $.ajax({

                    type: 'ajax',
                    method: 'get',

                    url: '<?php echo e(url("/getAccountsName")); ?>',

                    data: {ac_type: ac_type},

                    async: false,

                    dataType: 'json',

                    success: function(response) {

                        var html = '';

                        var i;
                        if(response.length > 0) {

                            for (i = 0; i < response.length; i++) {

                                html += '<option value="' + response[i].id + '">' + response[i].name + '</option>';

                            }
                        }else{
                            var html = '<option value="">Choose One</option>';
                            toastr.error('data not found');
                        }


                        $('#showAccounts').html(html);

                    },

                    error: function() {

                        toastr.error('data not found');

                    }

                });
            });



            $('select[name=trans_mode]').change(function(){
                var trans_mode=$('select[name=trans_mode]').val();

                if(trans_mode=='cheque'){

                    $(".bank_section").css("display", "block");
                }else{

                    $(".bank_section").css("display", "none");
                }

                if(trans_mode=='cash'){

                    $(".cash_section").css("display", "block");
                }else{

                    $(".cash_section").css("display", "none");
                }



            });

            //save Payments
            $('#PaymentsForm1').on('submit',function(e){
                e.preventDefault();

                var formData= $('#PaymentsForm').serialize();


                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("payments")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);
                        if(data.success) {
                            $('#PaymentsForm')[0].reset();
                            toastr.success(data.success);
                            window.location.reload();
                        }


                    },

                    error: function() {
                        toastr.error('something went wrong');

                    }

                });


            });


            //company_id dependent dropdown
            $('select[name=bank_id]').change(function() {

                var bank_id = $('select[name=bank_id]').val();

                $.ajax({

                    type: 'ajax',

                    method: 'get',

                    url: '<?php echo e(url("/getBankBranches")); ?>',

                    data: {
                        bank_id: bank_id
                    },

                    async: false,

                    dataType: 'json',

                    success: function(data) {


                        var html = '';

                        var i;
                        if (data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].branch + '</option>';
                            }
                        } else {
                            var html = '<option value="">Choose Branch</option>';
                            toastr.error('branch not exist');
                        }


                        $('#showBranch').html(html);

                    },

                    error: function() {

                        toastr.error('db error');


                    }

                });
            });




            // chek available Account Balance
            $('input[name=payment_amount]').on('change', function() {
                var amount=$(this).val();
                var trans_mode=$('select[name=trans_mode]').val();
                if(trans_mode=='cash'){
                    var account_id=$('select[name=company_account_id]').val();
                    var bank=0;

                }else{
                    var account_id=$('select[name=branch_id]').val();
                    var bank=1;
                }

                $.ajax({
                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getAccountsAvailBalance")); ?>',
                    data: {account_id: account_id,bank:bank},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        var currBalance=data;


                        if(amount > currBalance){
                            $("#btnSubmit").prop("disabled", true);
                            var p='<span style="color:red">Balance insufficient</span>';
                            $('.balance-error').html(p);


                        }
                        else{
                            $("#btnSubmit").prop("disabled", false);
                            var p='';
                            $('.balance-error').html(p);
                        }

                    },

                    error: function() {

                        toastr.error('something went wrong');

                    }

                });



            });



        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/payments/payments.blade.php ENDPATH**/ ?>