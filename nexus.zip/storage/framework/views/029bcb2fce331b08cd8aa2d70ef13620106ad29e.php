<?php $__env->startSection('content'); ?>

    <div class="page-wrapper">

        <!-- Page Content -->
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <h3 class="page-title">Leads Details</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Leads Details</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            <div class="card mb-0">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">
                                <div class="profile-img-wrap">
                                    <div class="profile-img">
                                        <a href="#">
                                            <img alt="" src="<?php echo e(asset('storage/app/public/uploads/staff-images/user1-128x128.png')); ?>"></a>
                                    </div>
                                </div>
                                <div class="profile-basic">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="profile-info-left">
                                                <h3 class="user-name m-t-0 mb-0"><?php echo e($data['lead']?$data['lead']->name:''); ?></h3>
                                                <h6 class="text-muted"></h6>
                                                <small class="text-muted"></small>
                                                <div class="staff-id">Lead ID :<?php echo e($data['lead']?$data['lead']->id:''); ?></div>
                                                <div class="small doj text-muted">Date : <?php echo e($data['lead']?$data['lead']->created_at:''); ?></div>

                                            </div>
                                        </div>
                                        <div class="col-md-7">
                                            <ul class="personal-info">
                                                <li>
                                                    <div class="title">Phone:</div>
                                                    <div class="text"><a href=""><?php echo e($data['lead']?$data['lead']->contact:''); ?></a></div>
                                                </li>
                                                <li>
                                                    <div class="title">Email:</div>
                                                    <div class="text"><a href=""><?php echo e($data['lead']?$data['lead']->email:''); ?></a></div>
                                                </li>

                                                <li>
                                                    <div class="title">City:</div>
                                                    <div class="text"><?php echo e($data['lead']?$data['lead']->cityname['city_name']:''); ?></div>
                                                </li>
                                                <li>
                                                    <div class="title">Address:</div>
                                                    <div class="text"><?php echo e($data['lead']?$data['lead']->address:''); ?></div>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="tab-content">

                <!-- Profile Info Tab -->
                <div id="emp_profile" class="pro-overview tab-pane fade show active">
                    <h4>Leads Information </h4>
                    <div class="row">

                        <?php if(isset($data['approached_leads'])): ?>
                        <?php $__currentLoopData = $data['approached_leads']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 d-flex">
                            <div class="card profile-box flex-fill">
                                <div class="card-body">
                                    <h3 class="card-title"><small class="text-secondary"><?php echo e($leads->created_at); ?></small></h3>

                                    <ul class="personal-info">
                                        <li>
                                            <div class="title">Approached By.</div>
                                            <div class="text badge bg-inverse-info"><?php echo e($leads->agent['name']); ?></div>
                                        </li>

                                        <li>
                                            <div class="title">Temperature</div>
                                            <div class="text"><div class="text badge bg-inverse-warning"><?php echo e($leads->temp['temp']); ?></div></div>
                                        </li>
                                        <li>
                                            <div class="title">Lead Type.</div>
                                            <?php
                                            if($leads->lead_type=='incoming'){
                                              echo '<div class="text badge bg-inverse-success">'.strtoupper($leads->lead_type).'</div>';
                                            }
                                            else{
                                              echo '<div class="text badge bg-inverse-primary">'.strtoupper($leads->lead_type).'</div>';
                                                }
                                                ?>

                                        </li>
                                        <li>
                                            <div class="title">Followup Date/Time</div>
                                            <div class="text"><?php echo e(date('d-M-Y',strtotime($leads->followup_date))); ?> <?php echo e($leads->follow_time); ?></div>
                                        </li>
                                        <li>
                                            <div class="title">Comments</div>
                                            <div class="text"><?php echo e($leads->comments); ?></div>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>

                </div>
                <!-- /Profile Info Tab -->


            </div>
        </div>




    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/call-center/leads/approach-leads-detail.blade.php ENDPATH**/ ?>