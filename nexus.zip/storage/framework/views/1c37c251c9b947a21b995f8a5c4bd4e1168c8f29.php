
<?php $__env->startSection('content'); ?>


<style type="text/css">
    body {
        font-family: Arial;
        font-size: 10pt;
    }
</style>

<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title bold-heading">Purchase List</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Purchase List</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="<?php echo e(url('/purchase')); ?>" class="btn add-btn" title="Add Product"><i class="fa fa-plus" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        <div class="card">
            <div class="card-body">


                <table class="table table-bordered mt-5 table-hover table-striped" id="datatable">
                    <thead>
                        <tr class="bold-tr">
                            <th># </th>
                            <th>Name </th>
                            <th>Amount </th>
                            <th>Comment </th>
                            <th>Created At </th>
                            <th>Action </th>
                        </tr>
                    </thead>
                    <tbody id="productTable">



                    </tbody>
                </table>
          
            
            </div>
        </div>
        <!-- /Page Content -->
    </div>




    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- CDN for Sweet Alert -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            getProducts();

            function getProducts() {

                $.ajax({

                    url: '<?php echo e(url("/purchase-list")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',

                    success: function(data) {


                        var html = '';
                        var i;
                        var c = 0;

                        for (i = 0; i < data.length; i++) {

                            c++;
                            html += '<tr>' +
                                '<td>' + c + '</td>' +
                                '<td>' + data[i].vendor.name + '</td>' +
                                '<td>' + data[i].amount + '</td>' +
                                '<td>' + data[i].comment + '</td>' +
                                '<td>' + data[i].created_at + '</td>' +
                                '<td class="text-center">' + '<a class="btn btn-primary btn-sm btn_View_Detail" href="view-purchase/' + data[i].id + '"><i class="fa fa-eye"></i></a></td>' +
                                '</td>' +

                                '</tr>';
                        }


                        $('#productTable').html(html);

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });
            }

            //Datatables
        $('#datatable').DataTable();
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/purchase/purchase-list.blade.php ENDPATH**/ ?>