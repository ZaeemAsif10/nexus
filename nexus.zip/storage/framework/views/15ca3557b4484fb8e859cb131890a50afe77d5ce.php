<?php $__env->startSection('content'); ?>

    <style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        table
        {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th
        {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th, table td
        {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title bold-heading">Ledger History</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Ledger History</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h3><?php echo e((($data['acName'])?$data['acName']:'')); ?></h3>
                <?php if($data['ledgerDetail']->count() > 0): ?>
                <table class="table table-striped table-hover" id="datatable">

                    <thead>
                        <tr>
                            <th>SR#</th>
                            <th>Date</th>
                            <th>Particular</th>
                            <th>DR</th>
                            <th>CR</th>
                            <th>Balance</th>
                        </tr>


                    <tbody>
                    <?php
                     $c=0;
                    $totalDr=0;
                    $totalCr=0;
                    $currBalance=0;
                    $crBalanceAmount=0;
                    $drBalanceAmount=0;



                    ?>
                    <?php if(isset($data['ledgerDetail'])): ?>
                        <?php $__currentLoopData = $data['ledgerDetail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $c++;

                if($ledger->ledger_type=='dr'){
                    $drBalanceAmount=$ledger->amount;
                $totalDr=$totalDr+$ledger->amount;
                }
                 if($ledger->ledger_type=='cr'){
                     $crBalanceAmount=$ledger->amount;
                $totalCr=$totalCr+$ledger->amount;
                }
                ?>
                    <tr>
                        <td><?php echo e($c); ?></td>
                        <td><?php echo e($ledger->created_at); ?></td>
                        <?php

                            $particular=App\Models\Transaction::find($ledger->transaction_id);
                            ?>
                        <td><?php echo e(!empty($particular->desc)?$particular->desc:''); ?></td>
                        <td>

                            <?php if($ledger->ledger_type=='dr'): ?>
                            <?php echo e(number_format($ledger->amount)); ?>

                            <?php else: ?>
                               <?php
                                   $drBalanceAmount=0;
                               ?>
                            -
                                <?php endif; ?>
                        </td>
                        <td>
                            <?php if($ledger->ledger_type=='cr'): ?>
                                <?php echo e(number_format($ledger->amount)); ?>

                            <?php else: ?>
                               <?php $crBalanceAmount=0; ?>
                                -
                            <?php endif; ?>
                        </td>
                        <?php
                        $currBalance=$currBalance + $drBalanceAmount - $crBalanceAmount;
                        ?>

                        <td><?php echo e(number_format($currBalance)); ?></td>

                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                    <tr>
                        <td>
                            <div class="float-right"> <strong>Total:</strong></div>
                        </td>
                        <td colspan="3">
                            <div class="float-right"> <strong> <?php echo e(number_format($totalDr)); ?> PKR</strong></div>
                        </td>
                        <td><div class="float-right"> <strong> <?php echo e(number_format($totalCr)); ?> PKR</strong></div></td>
                        <td><div class="float-right"> <strong>Balance: <?php echo e(number_format($totalDr - $totalCr)); ?> PKR</strong></div></td>
                    </tr>
                </table>
                <?php else: ?>
                <div class="alert alert-danger">Record not exist</div>
                    <?php endif; ?>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/ledgers/ledger-history.blade.php ENDPATH**/ ?>