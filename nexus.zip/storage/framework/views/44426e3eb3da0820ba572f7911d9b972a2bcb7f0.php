

<?php $__env->startSection('content'); ?>


    <div class="page-wrapper">

        <!-- Page Content -->
        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Edit Leads</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Edit Leads</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form method="post" action="<?php echo e(url('update-leeds/' . $lead->id)); ?>" class="needs-validation"
                        id="leadsForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Add Project Manager</label>
                                    <select class="select select2" name="manager_id" required>
                                        <option value="">Choose Manager</option>
                                        <?php if(isset($employee)): ?>
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($emp->id); ?>"
                                                    <?php if($lead->leader_id == $emp->id): ?> selected <?php endif; ?>><?php echo e($emp->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Team Leader</label>

                                    <select class="form-control form-control-sm select2" multiple="multiple"
                                        name="team_id[]" required>
                                        <option></option>

                                        <?php if(isset($employee)): ?>
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($emp->id); ?>"
                                                    <?php if(in_array($emp->id, $SelectedMonths)): ?> selected <?php endif; ?>><?php echo e($emp->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </select>

                                </div>
                            </div>
                        </div>


                        <div class="submit-section">
                            <button class="btn btn-primary btn-submit" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>


        </div>
        <!-- /Page Content -->

    </div>






    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {

            $('.select2').select2({
                placeholder: "Please select here",
                width: "100%"
            });

        })
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/tasks/leads/edit-lead.blade.php ENDPATH**/ ?>