<!-- Sidebar -->

<style>
    .menuss-active {
        color: #006dce !important;
    }
</style>

<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                
                <?php if(Auth::user()->role == 'admin'): ?>
                    <li class="submenu">
                        <a href="#" class=""><i class="la la-user"></i> <span>Dashboard</span> <span
                                class="menu-arrow"></span></a>
                    </li>
                    <li class="submenu">
                        <a href="#" class=""><i class="la la-user"></i> <span>Project Managment</span> <span
                                class="menu-arrow"></span></a>
                        <ul
                            <?php if(Route::is('projects') || Route::is('project/details')): ?> style="display: block;"
                            <?php else: ?>
                            style="display: none;" <?php endif; ?>>
                            <li>
                                <a class="<?php echo e(Route::is('projects') ? 'menuss-active' : ''); ?>"
                                    href="<?php echo e(route('projects')); ?>"> <span>Projects</span></a>
                            </li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#" class=""><i class="la la-user"></i> <span>Dealers Management</span>
                            <span class="menu-arrow"></span></a>
                        <ul
                            <?php if(Route::is('dealers')): ?> style="display: block;"
                            <?php else: ?>
                            style="display: none;" <?php endif; ?>>
                            <li>
                                <a class="<?php echo e(Route::is('dealers') ? 'menuss-active' : ''); ?>"
                                    href="<?php echo e(route('dealers')); ?>"> <span>Dealers</span></a>
                            </li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#" class=""><i class="la la-user"></i> <span>Features</span>
                            <span class="menu-arrow"></span></a>
                        <ul
                            <?php if(Route::is('features')): ?> style="display: block;"
                            <?php else: ?>
                            style="display: none;" <?php endif; ?>
                            >
                            <li>
                                <a class="<?php echo e(Route::is('features') ? 'menuss-active' : ''); ?>"
                                    href="<?php echo e(route('features')); ?>"> <span>Feature</span></a>
                            </li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#" class=""><i class="la la-user"></i> <span>Contact List</span> <span
                                class="menu-arrow"></span></a>
                        <ul
                            <?php if(Route::is('contact-list')): ?> style="display: block;"
                            <?php else: ?>
                            style="display: none;" <?php endif; ?>>
                            <li>
                                <a class="<?php echo e(Route::is('contact-list') ? 'menuss-active' : ''); ?>"
                                    href="<?php echo e(route('contact-list')); ?>"> <span>Contact List</span></a>
                            </li>
                        </ul>
                    </li>

                    <li class="submenu">
                        <a href="#" class=""><i class="la la-user"></i> <span>Payment Plans</span> <span
                                class="menu-arrow"></span></a>
                        <ul
                            <?php if(Route::is('payment-plan')): ?> 
                            style="display: block;"
                            <?php else: ?>
                            style="display: none;" <?php endif; ?>>
                            <li>
                                <a class="<?php echo e(Route::is('payment-plan') ? 'menuss-active' : ''); ?>"
                                    href="<?php echo e(route('payment-plan')); ?>"> <span>Payment Plan</span></a>
                            </li>
                        </ul>
                    </li>


                    <li class="submenu">
                        <a href="#" class="">
                            <i class="la la-user"></i> <span>Inventory/Stock </span> <span
                                class="menu-arrow"></span></a>
                        <ul>
                            <li>
                                <a class="" href="<?php echo e(url('products')); ?>"> <span>Products</span></a>
                                <a class="" href="<?php echo e(url('files')); ?>"> <span>Create Files</span></a>
                                <a class="" href="<?php echo e(url('issue-files')); ?>"> <span>Issue Files</span></a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
<?php /**PATH C:\xampp\htdocs\posch-city\resources\views/setup/sidebar.blade.php ENDPATH**/ ?>