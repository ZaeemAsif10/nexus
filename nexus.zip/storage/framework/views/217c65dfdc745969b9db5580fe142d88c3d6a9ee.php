<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Today Summary</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Today Summary</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-md-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Payable</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table  custom-table mb-0">
                                    <thead>
                                    <tr>
                                        <th>Invoice#</th>
                                        <th>Name</th>
                                        <th>Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $paybaleTotal=0; ?>
                                    <?php if(isset($data['payAbale'])): ?>
                                        <?php $__currentLoopData = $data['payAbale']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php $paybaleTotal=$paybaleTotal+ $payable->amount; ?>
                                    <tr>
                                        <td>INV-<?php echo e($payable->id); ?></td>
                                        <td><?php echo e($payable->name); ?></td>
                                        <td><?php echo e(number_format($payable->amount)); ?></td>

                                    </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <tr>
                                        <td>
                                            <div class="float-right"> <strong>Total:</strong></div>
                                        </td>
                                        <td colspan="1">

                                        </td>
                                        <td> <strong><?php echo e(number_format($paybaleTotal,2)); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Paid</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table custom-table table-nowrap mb-0">
                                    <thead>
                                    <tr>
                                        <th>SR#</th>
                                        <th>Name</th>
                                        <th>Receipt Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $paidTotal=0; ?>
                                    <?php if(isset($data['todayPaid'])): ?>
                                        <?php $__currentLoopData = $data['todayPaid']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php $paidTotal=$paidTotal+ $paid->amount; ?>
                                            <tr>
                                                <td>TRNS-<?php echo e($paid->id); ?></td>


                                                <?php
                                                    $res='';
                                                    $exp=[];
                                                    if($paid->ac_type=='VENDORS'){
                                                    $res=App\Models\Vendor::find($paid->ac_id);
                                                    }
                                                    if($paid->ac_type=='CLIENTS'){
                                                    $res=App\Models\Client::find($paid->ac_id);
                                                    }
                                                    if($paid['ac_type']=='COMPANY' && $paid['mode']=='expense'){
                                                    $exp=App\Models\ExpenseHead::find($paid['exp_head_id']);
                                                     }
                                                ?>
                                                <td>
                                                    <?php if($exp): ?>
                                                        <?php echo e($exp->exp_head); ?>

                                                    <?php endif; ?>

                                                    <?php if($res): ?>
                                                        <?php echo e($res->name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(number_format($paid->amount,2)); ?></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <tr>
                                        <td>
                                            <div class="float-right"> <strong>Total:</strong></div>
                                        </td>
                                        <td colspan="1">

                                        </td>
                                        <td> <strong><?php echo e(number_format($paidTotal,2)); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="row">

                <div class="col-md-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Receiveable</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table  custom-table mb-0">
                                    <thead>
                                    <tr>
                                        <th>Invoice#</th>
                                        <th>Name</th>
                                        <th>Amount</th>
                                    </tr>
                                    </thead>

                                    <tbody>

                                    <?php $totalReceiveable=0; ?>
                                    <?php if(isset($data['receiveAble'])): ?>
                                        <?php $__currentLoopData = $data['receiveAble']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recvable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php $totalReceiveable=$totalReceiveable+ $recvable->amount; ?>
                                            <tr>
                                                <td>INV-<?php echo e($recvable->id); ?></td>
                                                <td><?php echo e($recvable->name); ?></td>
                                                <td><?php echo e(number_format($recvable->amount)); ?></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <tr>
                                        <td>
                                            <div class="float-right"> <strong>Total:</strong></div>
                                        </td>
                                        <td colspan="1">

                                        </td>
                                        <td> <strong><?php echo e(number_format($totalReceiveable,2)); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Receipts</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table custom-table table-nowrap mb-0">
                                    <thead>
                                    <tr>
                                        <th>SR#</th>
                                        <th>Name</th>
                                        <th>Receipt Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $totalReceipts=0; ?>
                                    <?php if(isset($data['todayReceipts'])): ?>
                                        <?php $__currentLoopData = $data['todayReceipts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php $totalReceipts=$totalReceipts+ $receipts->amount; ?>
                                            <tr>
                                                <td>TRNS-<?php echo e($receipts->id); ?></td>


                                                <?php
                                                    $res='';
                                                    $exp=[];
                                                    if($receipts->ac_type=='VENDORS'){
                                                    $res=App\Models\Vendor::find($receipts->ac_id);
                                                    }
                                                    if($receipts->ac_type=='CLIENTS'){
                                                    $res=App\Models\Client::find($receipts->ac_id);
                                                    }
                                                    if($receipts['ac_type']=='COMPANY' && $receipts['mode']=='expense'){
                                                    $exp=App\Models\ExpenseHead::find($receipts['exp_head_id']);
                                                     }
                                                ?>
                                                <td>
                                                    <?php if($exp): ?>
                                                        <?php echo e($exp->exp_head); ?>

                                                    <?php endif; ?>

                                                    <?php if($res): ?>
                                                        <?php echo e($res->name); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(number_format($receipts->amount,2)); ?></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <tr>
                                        <td>
                                            <div class="float-right"> <strong>Total:</strong></div>
                                        </td>
                                        <td colspan="1">

                                        </td>
                                        <td> <strong><?php echo e(number_format($totalReceipts,2)); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="row">
                <div class="col-md-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Bank Payments</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-nowrap custom-table mb-0">
                                    <thead>
                                    <tr>
                                        <th>TransId</th>
                                        <th>Bank</th>
                                        <th>Description</th>
                                        <th>Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>


                                    <?php $paymentsTotal=0; ?>
                                    <?php if(isset($data['bankPayments'])): ?>
                                        <?php $__currentLoopData = $data['bankPayments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php $paymentsTotal=$paymentsTotal+ $payments->amount; ?>
                                            <tr>
                                                <td>TRNS-<?php echo e($payments->id); ?></td>
                                                <td><?php echo e($payments->bank_name); ?></td>
                                                <td><?php echo e($payments->desc); ?></td>
                                                <td><?php echo e(number_format($payments->amount,2)); ?></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <tr>
                                        <td>
                                            <div class="float-right"> <strong>Total:</strong></div>
                                        </td>
                                        <td colspan="2">

                                        </td>
                                        <td> <strong><?php echo e(number_format($paymentsTotal,2)); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Bank Receipts</h3>
                        </div>

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-nowrap custom-table mb-0">
                                    <thead>
                                    <tr>
                                        <th>Invoice#</th>
                                        <th>Bank</th>
                                        <th>Description</th>
                                        <th>Amount</th>
                                    </tr>
                                    </thead>
                                    <tbody>


                                    <?php $receiptsTotal=0; ?>
                                    <?php if(isset($data['bankReceipts'])): ?>
                                        <?php $__currentLoopData = $data['bankReceipts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php $receiptsTotal=$receiptsTotal+ $receipts->amount; ?>
                                            <tr>
                                                <td>TRNS-<?php echo e($receipts->id); ?></td>
                                                <td><?php echo e($receipts->bank_name); ?></td>
                                                <td><?php echo e($receipts->desc); ?></td>
                                                <td><?php echo e(number_format($receipts->amount,2)); ?></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <tr>
                                        <td>
                                            <div class="float-right"> <strong>Total:</strong></div>
                                        </td>
                                        <td colspan="2">

                                        </td>
                                        <td> <strong><?php echo e(number_format($receiptsTotal,2)); ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="row">

                <div class="col-md-6 d-flex">

                    <div class="card card-table flex-fill">


                                <div class="card-body">
                                    <div class="card-header">
                                        <h3 class="card-title mb-0">Expense</h3>
                                    </div>
                                    <div class="table-responsive">


                                        <table class="table table-striped table-hover" id="datatable">
                                            <thead>

                                            <tr>
                                                <th>SR#</th>
                                                <th>Exp Head</th>
                                                <th>Account</th>
                                                <th>Amount</th>


                                            </tr>
                                            </thead>
                                            <tbody id="summaryTable">
                                            <?php $total=0; ?>
                                            <?php if(isset($data['exp'])): ?>
                                                <?php $__currentLoopData = $data['exp']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php $total=$total + $exp->amount; ?>
                                                    <tr>
                                                        <td><?php echo e($key + 1); ?></td>
                                                        <td><?php echo e($exp->headname->exp_head); ?></td>
                                                        <td><?php echo e($exp->acname->actype['ac_type']); ?></td>
                                                        <td><?php echo e($exp->amount); ?></td>



                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                            </tbody>

                                            <tr>
                                                <td>
                                                    <div class="float-right"> <strong>Total:</strong></div>
                                                </td>
                                                <td colspan="2">

                                                </td>
                                                <td> <strong>PKR <?php echo e(number_format($total,2)); ?></strong></td>

                                            </tr>
                                        </table>
                                    </div>
                                </div>

                    </div>
                </div>




























            </div>
        </div>
        <!-- /Page Content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/accounts/reports/today-summary.blade.php ENDPATH**/ ?>