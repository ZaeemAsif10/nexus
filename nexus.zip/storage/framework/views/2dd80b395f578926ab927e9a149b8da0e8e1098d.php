

<?php $__env->startSection('content'); ?>


<script src="https://cdn.ckeditor.com/4.12.1/standard/ckeditor.js"></script>
<!-- Page Wrapper -->
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Projects</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Projects</li>
                    </ul>
                </div>

                <div class="col-auto float-right ml-auto">
                    <a href="#" class="btn add-btn" data-toggle="modal" data-target="#create_project"><i class="fa fa-plus"></i> Create Project</a>
                    <div class="view-icons">
                        <a href="#" class="grid-view btn btn-link active"><i class="fa fa-th"></i></a>
                        <a href="#" class="list-view btn btn-link"><i class="fa fa-bars"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Header -->

        <!-- Search Filter -->
        <div class="row filter-row">
            <div class="col-sm-6 col-md-3">
                <div class="form-group form-focus">
                    <input type="text" class="form-control floating">
                    <label class="focus-label">Project Name</label>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="form-group form-focus">
                    <input type="text" class="form-control floating">
                    <label class="focus-label">Employee Name</label>
                </div>
            </div>

            <div class="col-sm-6 col-md-3">
                <a href="#" class="btn btn-success btn-block"> Search </a>
            </div>
        </div>
        <!-- Search Filter -->

        <div class="row">
            <?php if(isset($data)): ?>
            <?php $__currentLoopData = $data['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-sm-6 col-md-4 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="dropdown dropdown-action profile-action">
                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="<?php echo e(url('edit-projects/'.$project->id)); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                <a class="dropdown-item btn_project_delete" href="#" data="<?php echo e($project->id); ?>"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                            </div>
                        </div>
                        <h4 class="project-title"><a href="#"><?php echo e($project->title); ?></a></h4>
                        <small class="block text-ellipsis m-b-15">

                            <?php
                            $open=App\Models\Tasks::where('project_id',$project->id)->where('status','open')->count();
                            $pending=App\Models\Tasks::where('project_id',$project->id)->where('status','pending')->count();
                            $complete=App\Models\Tasks::where('project_id',$project->id)->where('status','complete')->count();
                            ?>

                            <span class="text-xs"><?php echo e($open); ?></span> <span class="text-muted">open </span>
                            <span class="text-xs"><?php echo e($pending); ?></span> <span class="text-muted"> pending</span>
                            <span class="text-xs"><?php echo e($complete); ?></span> <span class="text-muted"> completed</span>

                        </small>
                        <p class="text-muted">
                            <?php echo Str::limit($project->desc, 200); ?>

                        </p>
                        <div class="pro-deadline m-b-15">
                            <div class="sub-title">
                                Deadline:
                            </div>
                            <div class="text-muted">
                                <?php echo e(date('d M Y', strtotime($project->end_date))); ?>

                            </div>
                        </div>
                        <div class="project-members m-b-15">
                            <div>Project Leader :</div>
                            <ul class="team-members">
                                <li>
                                    <a href="#" data-toggle="tooltip" title="<?php echo e($project->name); ?>">

                                        <img alt="" src="<?php echo e(asset('storage/app/public/uploads/staff-images/').'/'.$project->image); ?>">
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <?php
                        $totalTask= APP\Models\Project::join('tasks','tasks.project_id','=','projects.id')->where('tasks.project_id',$project->id)->get();
                        $doneTask= APP\Models\Project::join('tasks','tasks.project_id','=','projects.id')->where('tasks.project_id',$project->id)->where('tasks.status','Complete')->get();
                        if($totalTask->count() >0){
                        $progress=($doneTask->count()*100)/$totalTask->count();
                        }else{
                        $progress=0;
                        }

                        ?>
                        <?php if($project->status=='Complete'): ?>
                        <p class="m-b-5">Progress <span class="text-success float-right">100%</span></p>
                        <div class="progress progress-xs mb-0">
                            <div class="progress-bar bg-success" role="progressbar" data-toggle="tooltip" title="Progress" style="width:100%"></div>
                        </div>
                        <?php else: ?>

                        <p class="m-b-5">Progress <span class="text-success float-right"> <?php echo e(round($progress)); ?>%</span></p>
                        <div class="progress progress-xs mb-0">
                            <div class="progress-bar bg-success" role="progressbar" data-toggle="tooltip" title="Progress" style="width:<?php echo e(round($progress)); ?>%"></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <div class="float-right mt-3">
            <?php echo e($data['projects']->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
    <!-- /Page Content -->

    <!-- Create Project Modal -->
    <div id="create_project" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create Project</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(url('projects')); ?>" class="needs-validation" novalidate enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Project Name</label>
                                    <input class="form-control" type="text" name="project_name" placeholder="Project Name" required>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <div class="cal-iconssss">
                                        <input class="form-control " type="date" name="start_date" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>End Date</label>
                                    <div class="cal-iconss">
                                        <input class="form-control " type="date" name="end_date" required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Budget</label>
                                    <input placeholder="Price/Budget" class="form-control" type="number" name="price" required>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Priority</label>
                                    <select class="select form-control" name="priority" required>
                                        <option value="High">High</option>
                                        <option value="Medium">Medium</option>
                                        <option value="Low">Low</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Add Project Manager</label>
                                    <select class="select" name="manager_id" required>
                                        <option value="">Choose Manager</option>
                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data['manager']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($manage->id); ?>"><?php echo e($manage->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Team Leader</label>
                                    <div class="project-members" id="memberImage">

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Description</label>
                            <textarea rows="4" class="form-control summernote" placeholder="Enter your message here" name="des" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Upload Files</label>
                            <input class="form-control" type="file" name="file" required>
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Create Project Modal -->


</div>
<!-- /Page Wrapper -->


<script type="text/javascript">
    CKEDITOR.replace('des', {
        filebrowserUploadUrl: "<?php echo e(url('ckeditor.upload', ['_token' => csrf_token() ])); ?>",
        filebrowserUploadMethod: 'form'
    });
</script>



<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- CDN for Sweet Alert -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(document).ready(function() {

        // save designation
        $('select[name=manager_id]').on('change', function() {

            var manager_id = $('select[name=manager_id]').val();


            $.ajax({

                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("get-manager-data")); ?>',
                data: {
                    manager_id: manager_id
                },
                async: false,
                dataType: 'json',
                success: function(data) {

                    console.log(data.image);

                    $('#memberImage').append('<a href="#" data-toggle="tooltip" title="Jeffery Lalor" class="avatar"><img src="<?php echo e(asset("public/assets/img/profiles/avatar-16. jpg")); ?>" alt="" style="height:40px;width:50px"> </a>');

                },

                error: function() {
                    toastr.error('something went wrong');

                }

            });


        });


        // script for delete data
        $('.card').on('click', '.btn_project_delete', function(e) {
            e.preventDefault();

            var id = $(this).attr('data');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to Delete this Data!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(url('/delete-projects/')); ?>/" + id,
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        dataType: "json",
                        success: function(response) {
                            Swal.fire({
                                title: 'Deleted!',
                                text: response.message,
                                icon: 'success',
                                timer: 2000
                            })

                            window.location.reload();
                        }
                    });
                }
            })

        });

    });
</script>

<script>
    <?php if(count($errors) > 0): ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    toastr.error("<?php echo e($error); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <?php if(Session::has('success')): ?>
    toastr.success("Record save successfully!");

    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/tasks/projects.blade.php ENDPATH**/ ?>