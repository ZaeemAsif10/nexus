<?php $__env->startSection('content'); ?>



<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title"> Users</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">All Users</li>
                    </ul>
                </div>

            </div>
        </div>

        <!-- Search Filter -->
        <div class="card">
            <div class="card-body">
                <h5>Search Users</h5>
                <form action="<?php echo e(url('users')); ?>" method="post" id="searchForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="getdata" value="1">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <select name="company_id" class="select">
                                    <option value="" selected disabled>Choose Company</option>
                                    <?php if(isset($data['company'])): ?>
                                    <?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($comp->id); ?>"><?php echo e($comp->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <select name="desg_id" class="select">
                                    <option value="" selected disabled>Choose Department</option>
                                    <?php if(isset($data['department'])): ?>
                                    <?php $__currentLoopData = $data['department']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->departments); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="Search User Name">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Search Filter -->


        <!-- /Page Header -->
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">

                            <table class="table table-striped table-hover table-responsive" id="datatable">
                                <thead>
                                    <tr>
                                        <th style="width: 30px;">#</th>
                                        <th>Name </th>
                                        <th>Contact#</th>
                                        <th>Email </th>
                                        <th>Status </th>
                                        <th>Role </th>
                                        <th>Action </th>

                                    </tr>
                                </thead>
                                <tbody id="usersTable">


                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- /Page Content -->
    <!-- Delete Expense Modal -->
    <div class="modal custom-modal fade" id="change_status" role="dialog">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-header">
                        <h3>Change Status</h3>
                        <p>Are you sure want to change?</p>
                    </div>
                    <div class="modal-btn delete-action">
                        <div class="row">
                            <div class="col-6">
                                <a href="javascript:void(0);" class="btn btn-primary continue-btn btn-yes">Yes</a>
                            </div>
                            <div class="col-6">
                                <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">No</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Expense Modal -->

</div>




<script>
    <?php if(count($errors) > 0): ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    toastr.error("<?php echo e($error); ?>");
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <?php if(Session::has('success')): ?>
    toastr.success("Record updated successfully!");

    <?php endif; ?>
</script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


<script type='text/javascript'>
    $(document).ready(function() {




        usersList();


        function usersList() {


            $.ajax({

                url: '<?php echo e(url("/users")); ?>',
                type: 'get',
                async: false,
                dataType: 'json',

                success: function(data) {
                    var html = '';
                    var i;
                    var c = 0;
                    var status = '';
                    var class_name = '';

                    for (i = 0; i < data.length; i++) {

                        (data[i].status == 1) ? status = 'active': status = 'inactive';
                        (data[i].status == 1) ? class_name = 'bg-inverse-success': class_name = 'bg-inverse-danger';
                        c++;

                        html += '<tr>' +
                            '<td>' + c + '</td>' +
                            ' <td>' +
                            ' <h2 class="table-avatar">' +
                            '  <a href="#"><img alt="" class="target-img" src="storage/app/public/uploads/staff-images/' + data[i].image + '"></a>' +
                            '   <a href="#">' + data[i].name + ' <span>' + data[i].desig_name + '</span></a>' +
                            ' </h2>' +
                            ' </td>' +
                            ' <td>' + data[i].phone + '</td>' +
                            ' <td>' + data[i].email + '</td>' +

                            '<td><span class="badge ' + class_name + '">' + status + '</span></td>' +


                            ' <td class="text-center">' +
                            '<div class="dropdown action-label">' +
                            ' <a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">' +
                            ' <i class="fa fa-dot-circle-o text-success"></i> ' + data[i].role + ' </a>' +

                            '<div class="dropdown-menu dropdown-menu-right">' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="admin"><i class="fa fa-dot-circle-o text-danger"></i> ADMIN</a>' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="employee"><i class="fa fa-dot-circle-o text-success"></i> EMPLOYEE</a>' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="hr"><i class="fa fa-dot-circle-o text-success"></i> HR</a>' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="trainer"><i class="fa fa-dot-circle-o text-success"></i> TRAINER</a>' +
                            ' </div>' +
                            ' </div>' +
                            ' </td>' +

                            '<td class="text-right">' +
                            '<div class="dropdown dropdown-action">' +
                            '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>' +
                            '<div class="dropdown-menu dropdown-menu-right">' +
                            '<a class="dropdown-item btn-status" href="change-user-status/' + data[i].id + '/1" data="' + data[i].id + '" status="1"><i class="fa fa-clock-o m-r-5 text-success" ></i>Active</a>' +
                            '<a class="dropdown-item btn-status" href="change-user-status/' + data[i].id + '/0"" data="' + data[i].id + '" status="0"><i class="fa fa-clock-o m-r-5 text-danger" ></i>Deactive</a>' +

                            '</div>' +
                            ' </div>' +
                            '</td>' +


                            '</tr>';
                    }


                    $('#usersTable').html(html);

                },
                error: function() {
                    toastr.error('something went wrong');
                }

            });
        }


        //ajax call for serach record
        $('#searchForm').on('submit', function(e) {
            e.preventDefault();

            var formData = $('#searchForm').serialize();

            $.ajax({

                type: 'ajax',
                method: 'post',
                url: '<?php echo e(url("users")); ?>',
                data: formData,
                async: false,
                dataType: 'json',
                success: function(data) {
                    var html = '';
                    var i;
                    var c = 0;
                    var status = '';
                    var class_name = '';

                    for (i = 0; i < data.length; i++) {

                        (data[i].status == 1) ? status = 'Active': status = 'Deactive';
                        (data[i].status == 1) ? class_name = 'bg-inverse-success': class_name = 'bg-inverse-danger';
                        c++;

                        html += '<tr>' +
                            '<td>' + c + '</td>' +
                            ' <td>' +
                            ' <h2 class="table-avatar">' +
                            '  <a href="#"><img alt="" class="target-img" src="storage/app/public/uploads/staff-images/' + data[i].image + '"></a>' +
                            '   <a href="#">' + data[i].name + ' <span>' + data[i].desig_name + '</span></a>' +
                            ' </h2>' +
                            ' </td>' +
                            ' <td>' + data[i].phone + '</td>' +
                            ' <td>' + data[i].email + '</td>' +

                            '<td><span class="badge ' + class_name + '">' + status + '</span></td>' +


                            ' <td class="text-center">' +
                            '<div class="dropdown action-label">' +
                            ' <a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">' +
                            ' <i class="fa fa-dot-circle-o text-success"></i> ' + data[i].role + ' </a>' +

                            '<div class="dropdown-menu dropdown-menu-right">' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="admin"><i class="fa fa-dot-circle-o text-danger"></i> ADMIN</a>' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="employee"><i class="fa fa-dot-circle-o text-success"></i> EMPLOYEE</a>' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="hr"><i class="fa fa-dot-circle-o text-success"></i> HR</a>' +
                            '<a class="dropdown-item user_role" href="#" data="' + data[i].id + '" value="trainer"><i class="fa fa-dot-circle-o text-success"></i> TRAINER</a>' +
                            ' </div>' +
                            ' </div>' +
                            ' </td>' +

                            '<td class="text-right">' +
                            '<div class="dropdown dropdown-action">' +
                            '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>' +
                            '<div class="dropdown-menu dropdown-menu-right">' +
                            '<a class="dropdown-item btn-status" href="change-user-status/' + data[i].id + '/1" data="' + data[i].id + '" status="1"><i class="fa fa-clock-o m-r-5 text-success" ></i>Active</a>' +
                            '<a class="dropdown-item btn-status" href="change-user-status/' + data[i].id + '/0"" data="' + data[i].id + '" status="0"><i class="fa fa-clock-o m-r-5 text-danger" ></i>Deactive</a>' +

                            '</div>' +
                            ' </div>' +
                            '</td>' +


                            '</tr>';
                    }


                    $('#usersTable').html(html);

                },
                error: function() {
                    toastr.error('something went wrong');

                },
            });
        });

        // update user status
        $('#usersTable').on('click', '.btn-status', function() {
            var id = $(this).attr('data');
            var status = $(this).attr('status');


            $.ajax({

                url: '<?php echo e(url("/update-ticket-status")); ?>',
                type: 'get',
                async: false,
                dataType: 'json',
                data: {
                    id: id,
                    status: status
                },
                success: function(data) {

                    if (data.success) {
                        usersList();
                        toastr.success(data.success);
                    }

                },
                error: function() {
                    toastr.error('something went wrong');
                }

            });


        });


        // update user role
        $('#usersTable').on('click', '.user_role', function() {

            var id = $(this).attr('data');
            var value = $(this).attr('value');

            $.ajax({

                url: '<?php echo e(url("/users-role-change")); ?>',
                type: 'get',
                async: false,
                dataType: 'json',
                data: {
                    id: id,
                    value: value
                },
                success: function(data) {

                    if (data.success) {
                        usersList();
                        toastr.success(data.success);
                    }

                },
                error: function() {
                    toastr.error('something went wrong');
                }

            });


        });

        //Datatables
        $('#datatable').DataTable();
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/users/index.blade.php ENDPATH**/ ?>