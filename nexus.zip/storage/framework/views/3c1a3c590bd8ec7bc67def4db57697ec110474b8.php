

<?php $__env->startSection('content'); ?>
    <main id="main">
        <!-- ======= breadcrump section ======= -->
        <section class="intro-single">
            <div class="container-fluid ">
                <div class="row about-breadcrump text-center gx-0">
                    <div class="col-md-12">
                        <div class="title-single-box">
                            <h1 class="title-single text-white">
                                POSH CITY</h1>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a class="text-white" href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active text-white-50" aria-current="page">
                                    Posh City
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!-- End breadcrump section-->
        <section class="project-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h1><?php echo e($data['web_project']->title ?? ''); ?></h1>
                        <div class="ass mb-2"></div>
                        <p class="mt-4">
                            <?php echo e($data['web_project']->description ?? ''); ?>

                        </p>
                        <?php if(count($data['pro_features']) > 0): ?>
                            <div class="row size-row">
                                <?php $__currentLoopData = $data['pro_features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro_feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-4 mb-3">
                                        <div class="row">
                                            <div class="col-3 m-auto">
                                                <img src="<?php echo e(asset('storage/app/public/uploads/features/' . $pro_feature->feture->icon ?? '')); ?>"
                                                    style="vertical-align: middle;
                                                width: 30px;
                                                height: 30px;
                                                border-radius: 50%;"
                                                    alt="">
                                            </div>
                                            <div class="col-9">
                                                
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <p style="font-size: 18px;" class="color-b pt-3 text-center">"NEEDS AND LUXURIES, BOTH ARE CATERED
                            UNDER ONE ROOF"</p>
                    </div>

                    <div class="col-md-6">

                        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">

                                <?php $__currentLoopData = $data['pro_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($key == 0 ? ' active' : ''); ?>">
                                        <img class="d-block w-100 img-fluid p_c_img"
                                            src="<?php echo e(asset('storage/app/public/uploads/project/images/' . $project_img->p_images)); ?>"
                                            alt="First slide">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                                data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                                data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>

                        

                    </div>
                </div>
            </div>
        </section>


    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posh-city\resources\views/web-side/projects.blade.php ENDPATH**/ ?>