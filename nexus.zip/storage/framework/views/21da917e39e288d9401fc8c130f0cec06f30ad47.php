
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Builders</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Buildings Cost List</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="<?php echo e(url('/buildings')); ?>" class="btn add-btn" title="Add Buildings"><i class="fa fa-plus" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">


                <table class="table table-bordered mt-5">
                    <thead>
                        <tr>
                            <th># </th>
                            <th>Item  </th>
                            <th>Qty </th>
                            <th>Price </th>
                            <th>Sub Total </th>

                            <th>Created At </th>

                        </tr>
                    </thead>
                    <tbody id="buildingTable">
                    <?php $c=0; ?>
                    <?php $grandTotal=0; ?>
                    <?php if(isset($data)): ?>
                    <?php $__currentLoopData = $data['buildingCost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $c++;
                        $grandTotal= ($grandTotal) +($row->price * $row->qty);

                        ?>
<tr>
    <td><?php echo e($c); ?></td>
    <td><?php echo e($row->item); ?></td>
    <td><?php echo e($row->qty); ?></td>
    <td><?php echo e($row->price); ?></td>
     <td><?php echo e($row->price * $row->qty); ?></td>
     <td><?php echo e($row->created_at); ?></td>


</tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                    <tr>
                        <td  colspan="4">
                            <div class="float-right"><strong> Grand Total: </strong></div>
                        </td>
                        <td> <strong><?php echo e($grandTotal); ?> </strong></td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>


</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/hrm.alphabuzzco.com/resources/views/accounts/builders/building-cost-detail.blade.php ENDPATH**/ ?>