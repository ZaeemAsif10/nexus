
    <script type="text/javascript">
        $(document).ready(function() {
            $('body').bind('cut copy', function(event) {
                event.preventDefault();
            });
        });
    </script>





<?php /**PATH C:\xampp\htdocs\rgms\resources\views/call-center/general/dont-copy.blade.php ENDPATH**/ ?>