

<?php $__env->startSection('content'); ?>
    <!-- ======= Intro Section ======= -->
    <div class="intro intro-carousel swiper position-relative">

        <div class="swiper-wrapper">

            <div class="swiper-slide carousel-item-a intro-item bg-image"
                style="background-image: url('<?php echo e(asset('public/web-assets/img/carousel-img/7.7.jpg')); ?>')">
                <div class="overlay overlay-a"></div>
            </div>
            <div class="swiper-slide carousel-item-a intro-item bg-image"
                style="background-image: url('<?php echo e(asset('public/web-assets/img/carousel-img/6.jpg')); ?>')">
                <div class="overlay overlay-a"></div>
            </div>
            <div class="swiper-slide carousel-item-a intro-item bg-image"
                style="background-image: url('<?php echo e(asset('public/web-assets/img/carousel-img/12.jpg')); ?>')">
                <div class="overlay overlay-a"></div>
            </div>
            <div class="swiper-slide carousel-item-a intro-item bg-image"
                style="background-image: url('<?php echo e(asset('public/web-assets/img/carousel-img/8.jpg')); ?>')">
                <div class="overlay overlay-a"></div>
            </div>
            <div class="swiper-slide carousel-item-a intro-item bg-image"
                style="background-image: url('<?php echo e(asset('public/web-assets/img/carousel-img/4.4.jpg')); ?>')">
                <div class="overlay overlay-a"></div>
            </div>
            <div class="swiper-slide carousel-item-a intro-item bg-image"
                style="background-image: url('<?php echo e(asset('public/web-assets/img/carousel-img/1.1.jpg')); ?>')">
                <div class="overlay overlay-a"></div>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div><!-- End Intro Section -->

    <main id="main">

        <!-- ======= Our Projects Section ======= -->
        <?php if(count($data['projects']) > 0): ?>
            <section class="section-property pro-card section-t8">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="title-wrap d-flex justify-content-between">
                                <div class="title-box">
                                    <h2 class="title-a text-black">Our <span class="color-b"> Projects</span></h2>
                                </div>
                                <div class="title-link">
                                    <a href="#">All Projects
                                        <span class="bi bi-chevron-right"></span>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <?php $__currentLoopData = $data['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-12 col-md-6 col-lg-4 mb-4">
                                <div class="card border-0" style="width: 100%;">
                                    <a href="<?php echo e(url('projects') . '/' . $project->id); ?>"><img
                                            src="<?php echo e(asset('storage/app/public/uploads/projects/' . $project->image ?? '')); ?>"
                                            class="card-img-top" alt="..."></a>
                                    <div class="card-body">
                                        <h3 class="card-title"><?php echo e($project->title ?? ''); ?></h3>
                                        <p class="card-text text-danger mb-2">PKR
                                            <?php echo e(number_format($project->starting_price, 2) ?? ''); ?></p>
                                        <p><i class="bi bi-geo-alt-fill"></i> <?php echo e($project->location ?? ''); ?></p>
                                        <a href="<?php echo e(url('projects') . '/' . $project->id); ?>"
                                            class="btn btn-d float-end">DETAILS
                                            <i class="bi bi-arrow-right"></i> </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </section>
        <?php endif; ?>
        <!-- End Our Projects Section -->

        <!-- ======= Authorise Dealers Section ======= -->
        <?php if(count($data['dealers']) > 0): ?>
            <section class="section-agents section-t8">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="title-wrap d-flex justify-content-between">
                                <div class="title-box">
                                    <h2 class="title-a text-black">Authorise <span class="color-b"> Dealers</span></h2>
                                </div>
                                <div class="title-link">
                                    <a href="#">All Dealers
                                        <span class="bi bi-chevron-right"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="Authorise-Dealers" class="swiper">

                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $data['dealers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 carousel-item-b swiper-slide">
                                    <div class="card-box-d">
                                        <div class="card-img-d">
                                            <img src="<?php echo e(asset('storage/app/public/uploads/dealers/' . $dealer->image ?? '')); ?>"
                                                alt="" class="img-d img-fluid dealer-img">
                                        </div>
                                        <div class="card-overlay card-overlay-hover">
                                            <div class="card-header-d">
                                                <div class="card-title-d align-self-center">
                                                    <h3 class="title-d">
                                                        <a href="#"
                                                            class="link-two"><?php echo e($dealer->firm_name ?? ''); ?></a>
                                                    </h3>
                                                </div>
                                            </div>
                                            <div class="card-body-d">
                                                <div class="info-agents color-a">
                                                    <p>
                                                        <strong>Phone: </strong> <?php echo e($dealer->phone ?? ''); ?>

                                                    </p>
                                                    
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="Authorise-Dealers-pagination carousel-pagination"></div>
                </div>
            </section>
        <?php endif; ?>
        <!-- End Authorise Dealers Section Section -->

        <!-- start btn section -->
        <section class="btn-section">
            <div class="container-fluid">
                <div class="row justify-content-center mt-4 pt-4">
                    <div class="col-12 text-center">
                        <button class="btn btn-catalgue"><a
                                href="<?php echo e(asset('public/web-assets/plan/CataloguePoshCity.pdf')); ?>" target="_blank">Download
                                Catalgue</a></button>
                        <button class="btn btn-payment"><a href="<?php echo e(asset('public/web-assets/plan/paymentPlanNew.pdf')); ?>"
                                target="_blank">Download Payment plans</a> </button>
                    </div>
                </div>
            </div>
            <div class="button m-auto">
            </div>
        </section>
        <!-- end btn section -->

        <!-- ======= Contact Single ======= -->
        <section class="contact mt-5">
            <div class="container">
                <div class="row">
                    <h1 class="text-center">WE ARE ALWAYS HERE FOR YOU</h1>
                    <div class="ass2 m-auto"></div>
                </div>
                <div class="row mt-4">
                    <div class="col-sm-12">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <?php if(session()->has('message')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session()->get('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(url('contact-mail')); ?>" method="POST" class="validation-form">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <div class="form-group">
                                                <input type="text" name="name"
                                                    class="form-control form-control-lg form-control-a"
                                                    placeholder="Your Name" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <div class="form-group">
                                                <input name="email" type="email"
                                                    class="form-control form-control-lg form-control-a"
                                                    placeholder="Your Email" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <div class="form-group">
                                                <input type="text" name="subject"
                                                    class="form-control form-control-lg form-control-a"
                                                    placeholder="Subject" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <textarea name="message" class="form-control" name="message" cols="45" rows="8" placeholder="Message"
                                                    required></textarea>
                                            </div>
                                        </div>

                                        <div class="col-md-12 text-center mt-3">
                                            <button type="submit" class="btn btn-a">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ======= Testimonials Section ======= -->
        <section class="section-testimonials mt-5 nav-arrow-a">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-wrap d-flex justify-content-between">
                            <div class="title-box">
                                <h2 class="title-a">Testimonials</h2>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="testimonial-carousel" class="swiper">
                    <div class="swiper-wrapper">

                        <div class="carousel-item-a swiper-slide">
                            <div class="testimonials-box">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="testimonial-img">
                                            <img src="<?php echo e(asset('public/web-assets/img/test.jpg')); ?>" alt=""
                                                class="img-fluid">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <div class="testimonial-ico">
                                            <i class="bi bi-chat-quote-fill"></i>
                                        </div>
                                        <div class="testimonials-content">
                                            <p class="testimonial-text">
                                                After working with David to sell my home in 2013, I was convinced that he’s
                                                the only realtor I’ll ever need. Since then, I’ve bought two properties and
                                                sold one, and with each process, David’s knowledge, professionalism and
                                                terrific instincts have consistently guided us through to excellent
                                                outcomes.
                                            </p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div><!-- End carousel item -->

                        <div class="carousel-item-a swiper-slide">
                            <div class="testimonials-box">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="testimonial-img">
                                            <img src="<?php echo e(asset('public/web-assets/img/testi1.jpg')); ?>" alt=""
                                                class="img-fluid">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <div class="testimonial-ico">
                                            <i class="bi bi-chat-quote-fill"></i>
                                        </div>
                                        <div class="testimonials-content">
                                            <p class="testimonial-text">
                                                I recently sold a house with Dave and while this can be a very stressful
                                                process, I felt 110% confident by partnering with Dave. He was candid,
                                                provided great feedback, helped explain clearly all details and managed the
                                                actual sale negotiation brilliantly. In addition, he was extremely
                                                responsive to every one of my questions, no matter how small.
                                            </p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End carousel item -->

                    </div>
                </div>
                <div class="testimonial-carousel-pagination carousel-pagination"></div>

            </div>
        </section>
        <!-- End Testimonials Section -->

        <!-- End Contact Single-->
        <section class="section-partner mt-5">
            <div class="container">
                <div class="row">
                    <h2 class="text-center text-black"> OUR <span class="color-b"> PARTNERS</span></h2>
                    <div class="ass m-auto"></div>
                </div>
                <div class="row mt-4">
                    <div id="our-partners" class="swiper text-center">
                        <div class="swiper-wrapper">
                            <div class="carousel-item-b swiper-slide">
                                <img src="<?php echo e(asset('public/web-assets/img/compnay-img/logo_exact_fashion_store.png')); ?>"
                                    alt="" srcset="">
                            </div><!-- End carousel item -->

                            <div class="carousel-item-b swiper-slide">
                                <img src="<?php echo e(asset('public/web-assets/img/compnay-img/logo_fashion_bazar.png')); ?>"
                                    alt="" srcset="">
                            </div><!-- End carousel item -->

                            <div class="carousel-item-b swiper-slide">
                                <img src="<?php echo e(asset('public/web-assets/img/compnay-img/logo_sub_rang.png')); ?>"
                                    alt="" srcset="">
                            </div><!-- End carousel item -->

                            <div class="carousel-item-b swiper-slide">
                                <img src="<?php echo e(asset('public/web-assets/img/compnay-img/logo_sha_posh_textile.png')); ?>"
                                    alt="" srcset="">
                            </div><!-- End carousel item -->
                            <div class="carousel-item-b swiper-slide">
                                <img src="<?php echo e(asset('public/web-assets/img/compnay-img/logo_royal_sha_posh (1).png')); ?>"
                                    alt="" srcset="">
                            </div><!-- End carousel item -->
                            <div class="carousel-item-b swiper-slide">
                                <img src="<?php echo e(asset('public/web-assets/img/compnay-img/logo_rang_e_zan.png')); ?>"
                                    alt="" srcset="">
                            </div><!-- End carousel item -->
                            <div class="carousel-item-b swiper-slide">
                                <img src="<?php echo e(asset('public/web-assets/img/compnay-img/logo_al-haseeb_international_&_builders.png')); ?>"
                                    alt="" srcset="">
                            </div><!-- End carousel item -->
                        </div>
                    </div>
                    <div class="our-partners-pagination carousel-pagination"></div>
                </div>
            </div>
        </section>
    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posh-city\resources\views/web-side/index.blade.php ENDPATH**/ ?>