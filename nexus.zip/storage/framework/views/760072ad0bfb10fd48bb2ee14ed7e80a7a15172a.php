
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Edit Payment Plan</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active">Edit Payment Plan</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Edit Payment Plan</h4>
                        </div>
                        <div class="card-body">
                            <form action="" method="POST" id="editPaymentPlanForm" class="validation-form"
                                enctype="multipart/form-data">
                                <input type="hidden" name="plan_id" value="<?php echo e($data['plan']->id); ?>">
                                
                                <div class="row">

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Choose Project</label>
                                            <select name="project_id" class="form-control" required>
                                                <option value="" selected disabled>Choose</option>
                                                <?php $__currentLoopData = $data['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($project->id); ?>"
                                                        <?php echo e($data['plan']->project_id == $project->id ? 'selected' : ''); ?>>
                                                        <?php echo e($project->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Plot Size</label>
                                            <select name="plot_size" class="form-control" required>
                                                <option value="" selected disabled>Choose</option>
                                                <option value="3 Marla" <?php echo e('3 Marla' == '3 Marla' ? 'selected' : ''); ?>>3
                                                    Marla</option>
                                                <option value="5 Marla" <?php echo e('5 Marla' == '5 Marla' ? 'selected' : ''); ?>>5
                                                    Marla</option>
                                                <option value="7 Marla" <?php echo e('7 Marla' == '7 Marla' ? 'selected' : ''); ?>>7
                                                    Marla</option>
                                                <option value="10 Marla" <?php echo e('10 Marla' == '10 Marla' ? 'selected' : ''); ?>>10
                                                    Marla</option>
                                                <option value="1 Kanal" <?php echo e('1 Kanal' == '1 Kanal' ? 'selected' : ''); ?>>1
                                                    Kanal</option>
                                                <option value="2 Kanal" <?php echo e('2 Kanal' == '2 Kanal' ? 'selected' : ''); ?>>2
                                                    Kanal</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Down Dayment</label>
                                            <input type="text" name="down_payment"
                                                value="<?php echo e($data['plan']->down_payment); ?>" placeholder="Enter Down Payment"
                                                class="form-control" required>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Allocation Charges</label>
                                            <input type="text" name="allocation_charges"
                                                value="<?php echo e($data['plan']->allocation_charges); ?>"
                                                placeholder="Allocation Charges" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Confirmation Charges</label>
                                            <input type="text" name="confirmation_charges"
                                                value="<?php echo e($data['plan']->confirmation_charges); ?>"
                                                placeholder="Confirmation Charges" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Monthly Installments</label>
                                            <input type="text" name="monthly_installments"
                                                value="<?php echo e($data['plan']->monthly_installments); ?>"
                                                placeholder="Monthly Installments" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Every Six Month</label>
                                            <input type="text" name="every_six_month"
                                                value="<?php echo e($data['plan']->every_six_month); ?>" placeholder="Every Six Month"
                                                class="form-control" required>
                                        </div>
                                    </div>

                                </div>
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary update_plan">Save Changes</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            // save projects
            $('.update_plan').on('click', function(e) {
                e.preventDefault();


                let EditFormData = new FormData($('#editPaymentPlanForm')[0]);

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('update-payment-plan')); ?>",
                    data: EditFormData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    contentType: false,
                    processData: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('.update_plan').text('Saving...');
                        $(".update_plan").prop("disabled", true);
                    },
                    success: function(response) {

                        if (response.status == 200) {
                            $('#edit_events_modal').modal('hide');
                            $('.update_plan').text('Save Changes');
                            $(".update_plan").prop("disabled", false);
                            toastr.success(response.success);
                        }
                    },
                    error: function() {
                        toastr.error('something went wrong');
                        $('.update_plan').text('Save Changes');
                        $(".update_plan").prop("disabled", false);
                    }
                });

            });



        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posch-city\resources\views/admin/payment_plan/edit_plan.blade.php ENDPATH**/ ?>