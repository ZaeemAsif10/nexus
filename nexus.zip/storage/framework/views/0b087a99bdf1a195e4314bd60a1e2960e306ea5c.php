<?php $__env->startSection('content'); ?>
    <div class="main-wrapper">
        <!-- Page Wrapper -->
        <div class="page-wrapper">
            <!-- Chat Main Row -->
            <div class="chat-main-row">
                <!-- Chat Main Wrapper -->
                <div class="chat-main-wrapper">
                    <div class="col-lg-9 message-view task-view">

                    </div>
                    <!-- Chat Right Sidebar -->
                    <div class="col-lg-3 message-view chat-profile-view chat-sidebar" id="task_window">
                        <div class="chat-window video-window">
                            <div class="fixed-header">
                                <ul class="nav nav-tabs nav-tabs-bottom">
                                    <li class="nav-item"><a class="nav-link" href="#calls_tab" data-toggle="tab">People</a></li>
                                </ul>
                            </div>
                            <div class="tab-content chat-contents">
                                <div class="sidebar-menu">
                                    <ul>
                                        <?php if(isset($data['users'])): ?>
                                        <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(url('public/messenger/').'/'.$user['id']); ?>" target="_blank">
                              <span class="chat-avatar-sm user-img">
                              <img class="avatar av-l upload-avatar-preview" alt="" src="<?php echo e(asset('public/storage/users-avatar/').'/'.$user['avatar']); ?>">
                              <span class="status away"></span>
                              </span>
                                                <span class="chat-user"><?php echo e($user['name']); ?>

                                                    <?php if($user['countMessage'] > 0): ?>
                                                    <small class="badge badge-danger "><?php echo e($user['countMessage']); ?></small>
                                                        <?php endif; ?>
                                                </span>
                                            </a>
                                        </li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /Chat Right Sidebar -->
                </div>
                <!-- /Chat Main Wrapper -->
            </div>
            <!-- /Chat Main Row -->
        </div>
        <!-- /Page Wrapper -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u443729190/domains/shahraantech.com/public_html/rgms/resources/views/call-center/chat/index.blade.php ENDPATH**/ ?>