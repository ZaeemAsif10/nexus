<?php $__env->startSection('content'); ?>

<div class="main-wrapper">

    <!-- Page Wrapper -->
    <div class="page-wrapper">

        <!-- Page Content -->
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <h3 class="page-title">INTERVIEWS SCHEDULED</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Interviews Scheduled</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->


            <!-- Search Filter... -->
            <div class="card">
                <div class="card-body">
                    <div class="container py-4">
                        <form action="<?php echo e(url('interviews')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-3">
                                    <select name="job_id" class="select">
                                        <option value="" selected disabled>Choose Job Title</option>
                                        <?php if(isset($data['designation'])): ?>
                                        <?php $__currentLoopData = $data['designation']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($desig->id); ?>"><?php echo e($desig->desig_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" name="name" placeholder="Search Name">
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Search Filter... -->



            <div class="card">
                <div class="card-body">
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table table-striped" id="datatable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Job Title</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Apply Date</th>
                                            <th>Time</th>
                                            <th>Date</th>

                                            <th class="text-right">Action</th>

                                        </tr>
                                    </thead>
                                    <tbody id="showApplicantsList">
                                        <?php $c=0; ?>
                                        <?php if(isset($data['interviews'])): ?>
                                        <?php $__currentLoopData = $data['interviews']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interviews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $c++ ?>
                                        <tr>

                                            <td><?php echo e($c); ?></td>
                                            <td><?php echo e($interviews->desig_name); ?></td>
                                            <td><?php echo e($interviews->name); ?></td>
                                            <td><?php echo e($interviews->email); ?></td>
                                            <td><?php echo e($interviews->phone); ?></td>
                                            <td><?php echo e($interviews->created_at); ?></td>
                                            <td><?php echo e($interviews->interview_time); ?></td>
                                            <td><?php echo e($interviews->interview_date); ?></td>

                                            <td class="">
                                                <div class="dropdown dropdown-action">
                                                    <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item btnInterview" href="javascript:" data="<?php echo e($interviews->interviewId); ?>"><i class="fa fa-clock-o m-r-5 text-success"></i> Re Schedulee</a>

                                                    </div>
                                                </div>
                                            </td>

                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!-- /Page Content -->

    </div>
    <!-- /Page Wrapper -->

</div>



<div id="scheduleInterview" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Schedule Interview</h5>
                <button type="button" class="close modalDismiss" data-dismiss="modal" aria-label="Close" id="btnDissmissEdit">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="interviewForm" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label>Time <span class="text-danger">*</span></label>
                        <input class="form-control" type="hidden" name="hidden_interview_id">
                        <input class="form-control" type="time" name="interview_time">
                    </div>
                    <div class="form-group">
                        <label>Date <span class="text-danger">*</span></label>

                        <input class="form-control" type="date" name="interview_date">
                    </div>
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn" id="btnSave" type="button">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script>
    $(document).ready(function() {




        $('#showApplicantsList').on('click', '.btnInterview', function() {


            var id = $(this).attr('data');

            $('#scheduleInterview').modal('show');


            $.ajax({

                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("reshedule-interview")); ?>',
                data: {
                    id: id
                },
                async: false,
                dataType: 'json',
                success: function(data) {

                    $('input[name=interview_time]').val(data.interview_time);
                    $('input[name=interview_date]').val(data.interview_date);
                    $('input[name=hidden_interview_id]').val(id);

                },

                error: function() {

                    toastr.error('something went wrong');

                }

            });


        });


        $('#btnSave').on('click', function() {
            var formData = $('#interviewForm').serialize();

            $.ajax({

                type: 'ajax',
                method: 'post',
                url: '<?php echo e(url("update-interview")); ?>',
                data: formData,
                async: false,
                dataType: 'json',
                success: function(data) {

                    if (data.errors) {

                        toastr.error(data.errors);

                    }

                    if (data.success) {

                        toastr.success('Record save updated successfully');
                        window.location.reload();
                    }


                },

                error: function() {

                    toastr.error('something went wrong');

                }

            });

        });

        //Datatables
        $('#datatable').DataTable();

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/jobs/interviews.blade.php ENDPATH**/ ?>