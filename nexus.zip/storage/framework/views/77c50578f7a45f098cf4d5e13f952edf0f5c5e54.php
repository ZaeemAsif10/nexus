<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Trainy Feedbacks</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Feedbacks</li>
                    </ul>
                </div>

            </div>
        </div>
        <!-- /Page Header -->
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table mb-0">
                        <thead>
                            <tr>
                                <th style="width: 30px;">#</th>
                                <th>Training Type</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Trainer Name</th>
                                <th>Rated By</th>
                                <th>Rating</th>
                                <th>Comment</th>
                                <th>Created At</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $c=0; ?>
                            <?php if(isset($data['rating'])): ?>
                            <?php $__currentLoopData = $data['rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php $c++ ?>
                            <tr>
                                <td><?php echo e($c); ?></td>
                                <td><?php echo e($rate->training_type); ?></td>
                                <td><?php echo e($rate->from); ?></td>
                                <td><?php echo e($rate->to); ?></td>
                                <td><?php echo e($rate->f_name); ?> <?php echo e($rate->l_name); ?></td>
                                <td><?php echo e($rate->name); ?></td>

                                <td>

                                    <nav class=" navbar-expand-lg">

                                        <?php

                                        $overAllRatings = $rate->rating;
                                        $count_rows = 1;

                                        //                                            $r=App\Models\Rating:: all();
                                        //                                            if($r){
                                        //                                                $count_rows = $r->count();
                                        //                                                $count_row=$count_rows;
                                        //                                                $sum=0;
                                        //                                                foreach($r as $r){
                                        //                                                    $rate= $r->rating;
                                        //                                                    $sum=$sum+$rate;
                                        //
                                        //                                                }
                                        //                                                $overAllRatings=($sum/$count_row);
                                        //
                                        //                                            }

                                        ?>

                                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                            <ul class="navbar-nav mr-auto">
                                                <li class="nav-item active">


                                                    <div class="placeholder" style="color: orange;">
                                                        <i class="far fa-star" style="color:"></i>
                                                        <i class="far fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <i class="far fa-star"></i>
                                                        <span class="small">(<?php echo e($count_rows); ?>)</span>
                                                    </div>

                                                    <div class="overlay" style="position: relative;top: -23px; color:orange">

                                                        <?php while($overAllRatings>0): ?>
                                                        <?php if($overAllRatings >0.5): ?>
                                                        <i class="fas fa-star"></i>
                                                        <?php else: ?>
                                                        <i class="fas fa-star-half"></i>
                                                        <?php endif; ?>
                                                        <?php $overAllRatings--; ?>
                                                        <?php endwhile; ?>

                                                    </div>
                                                </li>
                                            </ul>




                                        </div>
                                    </nav>
                                </td>
                                <td><?php echo e($rate->comment); ?></td>
                                <td><?php echo e($rate->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="float-right mt-3">
                    <?php echo e($data['rating']->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/ratings/trainerReviews.blade.php ENDPATH**/ ?>