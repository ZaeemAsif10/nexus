
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <style>
        body {
            font-family: Arial;
            font-size: 10pt;
        }
    </style>
    <!-- Page Content -->
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="card">
            <div class="card-body">
                <div class="page-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title">Edit Feedbacks</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Edit Feedbacks</li>
                            </ul>
                        </div>
                        <div class="col-auto float-right ml-auto">
                            <a href="<?php echo e(url('trainee-feedback')); ?>" class="btn add-btn" title="Give Feedback">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- /Page Header -->
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <form method="post" id="ratingForm" action="<?php echo e(url('update-trainee-feedback/'.$data['rate']->id)); ?>" class="needs-validation" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Training Type <span class=""></span></label>
                                    <select class="select form-control" name="trainingId" id="trainingId" required>
                                        <option value="">Choose Trainer</option>
                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data['training']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($train->id); ?>"
                                        <?php if($data['rate']->training_id == $train->id): ?> selected <?php endif; ?>
                                        ><?php echo e($train->training_type); ?> <?php echo e(date('d-M-Y', strtotime($train->from_date))); ?> <?php echo e(date('d-M-Y', strtotime($train->to_date))); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label>Traine <span class=""></span></label>
                                    <select class="select form-control" name="trainy_id" id="showTrainy" required>
                                        <option value="">Choose Trainy</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label>Rating <span class=""></span></label>
                                    <input type="text" class="ratingEvent rating5" value="<?php echo e($data['rate']->rating); ?>" name="rating" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-sm-12">
                                    <label>Comment <span class="text-danger">*</span></label>
                                    <textarea name="comment" cols="10" rows="3" class="form-control" required><?php echo e($data['rate']->comment); ?></textarea>
                                </div>
                            </div>
                            <div class="submit-section">
                                <button class="btn btn-primary submit-btn" type="submit" id="btnSubmit">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Content -->






    </div>
    <script type="text/javascript">
        $(function() {
            $('.rating').rating();

            $('.ratingEvent').rating({
                rateEnd: function(v) {
                    $('#result').text(v);
                }
            });
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type='text/javascript'>
        $(document).ready(function() {




            $('#trainingId').change(function() {
                var trainingId = $('select[name=trainingId]').val();

                $.ajax({

                    type: 'ajax',

                    method: 'get',

                    url: '<?php echo e(url("/getTrainyName")); ?>',

                    data: {
                        trainingId: trainingId
                    },

                    async: false,

                    dataType: 'json',

                    success: function(data) {


                        var html = '';

                        var i;
                        if (data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].name + '</option>';

                            }
                        } else {
                            var html = '<option value="">Choose Trainy</option>';
                            toastr.error('data not found');
                        }


                        $('#showTrainy').html(html);

                    },

                    error: function() {

                        alert('Could not get Data from Database');

                    }

                });
            });

        });
    </script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/ratings/editTraineeFeedBack.blade.php ENDPATH**/ ?>