<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Accounts</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Add New Accounts</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="<?php echo e(url('/accounts-list')); ?>" class="btn add-btn" title="Banks List"><i class="fa fa-list" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(url('accounts')); ?>" method="POST" id="accountsForm" class="needs-validation" novalidate >
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-sm-6">
                                <label>Account Type <span class="text-danger">*</span></label>
                                <select name="ac_type_id" id="" class="form-control" required>
                                    <option value="">Choose Ac Type</option>
                                    <?php if(isset($data['accountTypes'])): ?>
                                        <?php $__currentLoopData = $data['accountTypes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($account->id); ?>"><?php echo e($account->ac_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <div class="invalid-feedback">
                                    Please enter Ac Type.
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for=""> Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Enter Account Holder Name" required>
                                    <div class="invalid-feedback">
                                        Please Enter Account Holder Name.
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for=""> Email</label>
                                    <input type="text" name="email" class="form-control" placeholder="Enter Account Holder Email" required>
                                    <div class="invalid-feedback">
                                        Please Enter Account Holder Email.
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for=""> Contact</label>
                                    <input type="number" name="contact" autocomplete="off" id="contact" class="form-control" placeholder="Enter Account Holder Contact" required>
                                    <div id="show_error"></div>
                                    <div class="invalid-feedback">
                                        Please Enter Contact.
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for=""> CNIC</label>
                                    <input type="number" name="cnic" class="form-control" placeholder="Enter Account Holder Cnic" required>
                                    <div class="invalid-feedback">
                                        Please Enter CNIC.
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Initial Balance</label>
                                    <input type="number" name="open_bal" class="form-control" placeholder="Initial Balance" required>
                                    <div class="invalid-feedback">
                                        Please Enter Open Balance.
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 ">
                                <div class="submit-section">
                                    <button type="submit" class="btn btn-primary submit-btn add_vendor" id="btnSubmit">Submit Now</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- /Page Content -->
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script>
            $(document).ready(function() {



                $('#accountsForm').unbind().on('submit',function(e){
                    e.preventDefault();

                    var formData= $('#accountsForm').serialize();

                    $.ajax({

                        type: 'ajax',
                        method: 'post',
                        url: '<?php echo e(url("accounts")); ?>',
                        data: formData,
                        async: false,
                        dataType: 'json',
                        beforeSend: function() {
                            $('#btnSubmit').prop('disabled',true);
                            $('#btnSubmit').text('loading...');
                        },
                        success: function(data) {

                            if(data.success) {
                                $('#accountsForm')[0].reset();
                                toastr.success(data.success);
                            }
                            if(data.error){
                                toastr.error(data.error);
                            }
                        },
                        complete: function() {
                            $('#btnSubmit').prop('disabled',false);
                            $('#btnSubmit').text('Submit');

                        },

                        error: function() {
                            toastr.error('something went wrong');

                        }

                    });


                });

                //validation for contact
                var minLength = 14;
                var maxLength = 14;
                $('#ac_number').on('keydown keyup change', function() {
                    var char = $(this).val();
                    var charLength = $(this).val().length;
                    if (charLength < minLength) {
                        $('#show_error').html('Length is short minimum ' + minLength);
                        $('#show_error').css('color', 'red');
                    } else if (charLength > maxLength) {
                        $('#show_error').html('Length is not valid maximum ' + maxLength + ' allowed.');
                        $('#show_error').css('color', 'red');
                        $(this).val(char.substring(0, maxLength));
                    } else {
                        $('#show_error').html('');
                    }
                });



            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/hrm.alphabuzzco.com/resources/views/accounts/accounts/index.blade.php ENDPATH**/ ?>