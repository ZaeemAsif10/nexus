


<?php $__env->startSection('content'); ?>



    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="chat-main-row">
            <div class="chat-main-wrapper">
                <div class="col-lg-7 message-view task-view task-left-sidebar">
                    <div class="chat-window">
                        <div class="fixed-header">
                            <div class="navbar">
                                <div class="float-left mr-auto">
                                    <div class="add-task-btn-wrapper">
												<span class=" btn btn-white btn-sm" data-toggle="modal" data-target="#create_task">
													Add Productivity
												</span>
                                    </div>
                                </div>
                                <a class="task-chat profile-rightbar float-right" id="task_chat" href="#task_window"><i class="fa fa fa-comment"></i></a>
                                <ul class="nav float-right custom-menu">
                                    <li class="nav-item dropdown dropdown-action">
                                        <a href="" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-cog"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="javascript:void(0)">Pending Tasks</a>
                                            <a class="dropdown-item" href="javascript:void(0)">Completed Tasks</a>
                                            <a class="dropdown-item" href="javascript:void(0)">All Tasks</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>


                        <div class="chat-contents">
                            <div class="chat-content-wrap">
                                <div class="chat-wrap-inner">
                                    <div class="chat-box">
                                        <div class="task-wrapper">
                                            <div class="task-list-container">
                                                <div class="task-list-body">
                                                    <ul id="task-list" class="task-lis taskListSection">

                                                    </ul>


                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                    </div>
                </div>
                <div class="col-lg-5 message-view task-chat-view task-right-sidebar" id="task_window">
                    <div class="chat-window">
                        <div class="fixed-header">
                            <div class="navbar">
                                <div class="task-assign" id="status">





                                </div>
                                <ul class="nav float-right custom-menu">
                                    <li class="dropdown dropdown-action">
                                        <a href="" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="javascript:void(0)">Delete Task</a>
                                            <a class="dropdown-item" href="javascript:void(0)">Settings</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>


                        <div class="chat-contents task-chat-contents">
                            <div class="chat-content-wrap">
                                <div class="chat-wrap-inner">
                                    <div class="chat-box" id="chatBoxSection">

                                        <img id="loader" class="center"  src=public/assets/img/loader/loader.gif  style="padding-left: 50px;display: none" />


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

    <!-- Create Project Modal -->
    <div id="create_task" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create Task</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" class="needs-validation" novalidate action="<?php echo e(url('save-task-progress')); ?>" id="taskProgressForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Task</label>
                                    <select class="select"  name="task_id"  required>
                                        <option value="">Choose Task</option>
                         <?php if(isset($data['tasks'])): ?>
                         <?php $__currentLoopData = $data['tasks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($task->id); ?>"><?php echo e($task->task); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </select>
                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Progress (%)</label>

                                        <input class="form-control " type="number" name="progress" required placeholder="Enter progress in %" maxlength="100">
                                    <div id="progressError"></div>

                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Status</label>
                                    <select class="select"  name="status" required id="progressStatus">
                                        <option value="">Choose Status</option>
                                        <option value="Inprogress">Inprogress</option>
                                        <option value="Complete">Complete</option>

                                    </select>
                                </div>
                            </div>

                        </div>






                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn" id="btnSubmit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Create Project Modal -->



    </div>
    <!-- /Page Wrapper -->


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>

    $(document).ready(function (){
        taskList();


        function taskList(){

            $.ajax({

                url: '<?php echo e(url("/my-tasks")); ?>',
                type: 'get',
                async: false,
                dataType: 'json',
                success: function(data)
                {

                    var html = '';
                    var i;
                    var c=0;

                    for(i=0; i<data.length; i++){

                        c++;

                        html +=
                            '<li class="task task-hover" data="'+data[i].id+'">'+
                            '<div class="task-container" >'+
                            ' <span class="task-action-btn task-check">'+
                            '<span class="action-circle large complete-btn" title="Mark Complete">'+
                            '<i class="material-icons" >check</i>'+
                            '</span>'+
                            '</span>'+
                            '<span class="task-label" ="true">'+data[i].task+'</span>'+
                            '<span class="task-action-btn task-btn-right">'+
                            '<span class="action-circle large" title="Assign">'+
                            '<i class="material-icons">person_add</i>'+
                            '</span>'+


                            '</span>'+
                            '</div>'+
                            '</li>';

                    }

                    $('.taskListSection').html(html);

                },
                error:function()
                {
                    toastr.error('something went wrong');
                }

            });
        }

        $('#taskProgressForm').unbind().on('submit',function(e){
            e.preventDefault();

            var formData= $('#taskProgressForm').serialize();


            $.ajax({

                type: 'ajax',
                method: 'post',
                url: '<?php echo e(url("save-task-progress")); ?>',
                data: formData,
                async: false,
                dataType: 'json',
                success: function(data) {

                    if(data.success) {

                        $('#taskProgressForm')[0].reset();
                        $('.close').click();
                        toastr.success(data.success);
                    }

                    if(data.error) {
                        toastr.success(data.error);
                    }


                },

                error: function() {
                    toastr.error('something went wrong');

                }

            });


        })



        $(".task-hover").mouseover(function(){
            var task_id = $(this).attr("data");


            $.ajax({

                url: '<?php echo e(url("/getMySingleTask")); ?>',
                type: 'get',
                async: false,
                dataType: 'json',
                data:{task_id:task_id},
                beforeSend: function() {
                  $('#loader').show();
                },

                success: function(data)
                {

                    var html = '';
                    var i;
                    var c=0;
                    var status='';
                    for(i=0; i<data.length; i++){
                        c++;

                        (data[i].status=='Complete')? status="text-success": status="text-danger";


                        html +=' <div class="chats">'+
                            '<h4>'+data[i].task+'</h4>'+
                            '<div class="task-header">'+
                            ' <div class="assignee-info">'+
                            ' <a href="#" data-toggle="modal" data-target="#assignee">'+
<<<<<<< HEAD
<<<<<<< HEAD
                            ' <div>'+
=======
                            ' <div class="">'+
>>>>>>> 717bd4611da7f36ebf837b4314da635a1d3c3a23
=======

                            ' <div class="">'+

>>>>>>> b0f98cc5ff1e01c8d73ba53c7221333988b5ffd0
                            '  <img alt="" class="target-img" src="<?php echo e(asset("storage/app/public/uploads/staff-images/")); ?>/'+data[i].image+'">'+
                            ' </div>'+
                            ' <div class="assigned-info">'+
                            '   <div class="task-head-title">Assigned To</div>'+
                            '<div class="task-assignee">'+data[i].name+'</div>'+
                            '</div>'+
                            ' </a>'+
                            ' <span class="remove-icon">'+
                            '<i class="fa fa-close"></i>'+
                            '</span>'+
                            '</div>'+
                        '<div class="task-due-date">'+
                        ' <a href="#" data-toggle="modal" data-target="#assignee">'+
                        '<div class="due-icon">'+
                        '<span>'+
                        '<i class="material-icons">date_range</i>'+
                        '</span>'+
                        ' </div>'+
                        '<div class="due-info">'+
                            '<div class="task-head-title">Due Date</div>'+
                            '<div class="due-date">'+data[i].end_date+'</div>'+
                            '</div>'+
                            '</a>'+
                            ' <span class="remove-icon">'+
                            '<i class="fa fa-close"></i>'+
                            '</span>'+
                            '</div>'+
                            ' </div>'+
                            ' <hr class="task-line">'+
                            '<div class="task-desc">'+
                            ' <div class="task-desc-icon">'+
                            '<i class="material-icons">subject</i>'+
                            '</div>'+
                            ' <div class="task-textarea">'+

                            '<p class="text-muted">'+data[i].desc+' </p>'+

                            '</div>'+
                            ' </div>';

            var status='<a class="task-complete-btn btnMark text-success" id="task_complete" href="javascript:void(0);" taskId="'+data[i].id+'" >'+
                '<i class="material-icons">check</i> Mark Complete    </a>' +
                '<a class="task-complete-btn btnMark '+status+'" id="task_complete" href="javascript:void(0);" style="margin-left:30px" data="'+data[i].id+'">'+
                '<i class="material-icons">check</i> '+data[i].status.toUpperCase()+' </a>';

                    }

                    $('#status').html(status);
                    $('#chatBoxSection').html(html);

                },
                error:function()
                {
                    toastr.error('something went wrong');
                },

                complete: function() {
                    $('#loader').hide();

                },

            });

        });



//task status change
        $('#status').click('.task-complete-btn',function(event){

            var task_id=event.target.attributes.taskId.value;



            $.ajax({

                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("update-task-status")); ?>',
                data: {task_id:task_id},
                async: false,
                dataType: 'json',
                success: function(data) {

                    if(data.success) {
                        toastr.success(data.success);


                    }

                    if(data.error) {
                        toastr.success(data.error);


                    }

                },

                error: function() {

                    toastr.error('something went wrong');

                }

            });
        })

        //progress
        $('input[name=progress]').change(function (){
            var progress=$('input[name=progress]').val();
            if(progress>100){
                var p='<span style="color:red">Value must be less hen or eqqual to 100</span>';
                $('#progressError').html(p);
                $('#btnSubmit').prop('disabled', true);
            }


            if(progress<=100){

                $('#progressError').html('');
                $('#btnSubmit').prop('disabled', false);
            }

            if(progress==100){
                $('#progressStatus').html('<option id="sta" value="Complete">Complete</option>')

            }else{

                    var html='';
                html +='<option value="">Choose Status</option>'+
                       '<option value="Inprogress">Inprogress</option>'+
                       '<option value="Complete">Complete</option>';
                $('#progressStatus').html(html);
            }
        })

        $('select[name=status]').change(function (){

            var status=$("#progressStatus option:selected").val()
          if(status=='Complete'){
            $('input[name=progress]').val(100);
              $('input[name=progress]').prop('readonly', true);
          }else{
              $('input[name=progress]').val();
              $('input[name=progress]').prop('readonly', false);
          }
        })


    })
</script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/tasks/my-tasks.blade.php ENDPATH**/ ?>