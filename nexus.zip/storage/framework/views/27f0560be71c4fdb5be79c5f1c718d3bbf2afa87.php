<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        table
        {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th
        {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th, table td
        {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Receipts</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Add Receipts</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="#payments-list" class="btn add-btn" title="Payments List"><i class="fa fa-list" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <form method="post" id="ReceiptForm" class="needs-validation" novalidate action="<?php echo e(url('receipt')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Account Type</label>
                                    <select class="select" name="ac_type" required>
                                        <option value="">Choose Type</option>
                                        <option value="vendors">Vendors</option>
                                        <option value="clients">Clients</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label id="ac_label">Account</label>
                                    <select class="select" name="ac_id" required id="showAccounts" class="form-control">
                                        <option value="">Choose Account</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4 file_section" style="display:none">
                                <div class="form-group">
                                    <label>Files</label>
                                    <select class="select" name="file_id"  id="showFileSection">

                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Transaction Mode</label>
                                    <select class="select" name="trans_mode" required>
                                        <option value="">Choose One</option>
                                        <option value="cash">Cash</option>
                                        <option value="cheque">Cheque</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Receipt Amount</label>
                                    <input type="number" name="payment_amount" class="form-control" placeholder="Receipt Amount" required>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Narration</label>
                                    <input type="text" class="form-control" required name="desc" placeholder="Narration">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 bank_section" style="display:none">
                                <div class="form-group">
                                    <label>Bank</label>
                                    <select name="bank_id" id="" class="form-control">
                                        <option value="">Choose Bank</option>
                                        <?php if(isset($data['banks'])): ?>
                                            <?php $__currentLoopData = $data['banks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->bank_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4 bank_section" style="display:none">
                                <div class="form-group">
                                    <label>Bank Branches</label>
                                    <select  id="showBranch" class="form-control" name="branch_id">
                                        <option value="">Choose Branch</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4 cash_section" style="display:none">
                                <div class="form-group">
                                    <label>Receive From</label>
                                    <select name="company_account_id" id="" class="form-control">
                                        <option value="">Choose Account</option>
                                        <?php if(isset($data['accounts'])): ?>
                                            <?php $__currentLoopData = $data['accounts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($accounts->id); ?>"><?php echo e($accounts->actype['ac_type']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="float-right">
                            <button class="btn btn-success btn-submit" type="submit" id="btnSave">Save</button>
                            <button class="btn btn-success btn-submit" type="button" id="btnSaveANDPrint">Save & Print</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="my-header">
                <div class="row">
                    <form method="post" class="needs-validation" novalidate action="" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-sm-3 col-md-3">
                                <div class="form-group">
                                    <label>Account Type</label>
                                    <select class="select" name="ac_type" required>
                                        <option value="">Choose Type</option>
                                        <option value="vendors">Vendors</option>
                                        <option value="clients">Clients</option>
                                        <option value="expense">Expense</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-md-3">
                                <div class="form-group">
                                    <label>Account</label>
                                    <select class="select" name="ac_id" required id="showAccounts1">
                                        <option value="">Choose Account</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-md-2">
                                <div class="form-group">
                                    <label>To:</label>
                                    <input type="date" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label>From:</label>
                                    <input type="date" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-1">
                                <div class="form-group">
                                    <label for=""></label>
                                    <button class="btn btn-success mt-2">Search</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped" id="payments-list">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Ac Type</th>
                            <th>Description</th>
                            <th>Date</th>
                            <th>Receipt Amount</th>
                            <th>Paid Amount</th>
                            <th>Balance</th>
                        </tr>
                        <tbody>
                        <?php $c=0;
                  $subTotal=0;
                        ?>
                        <?php if(isset($data['transaction'])): ?>
                            <?php $__currentLoopData = $data['transaction']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $c++;
                  $subTotal=$subTotal+$trans['amount'];
                                ?>
                                <tr>
                                    <td><?php echo e($c); ?></td>
                                    <?php
                                        $res='';
                                        if($trans->ac_type=='VENDORS'){
                                        $res=App\Models\Vendor::find($trans->ac_id);
                                        }
                                        if($trans->ac_type=='CLIENTS'){
                                        $res=App\Models\Client::find($trans->ac_id);
                                        }
                                    ?>
                                    <td><?php echo e(($res)?$res->name:''); ?></td>
                                    <td><?php echo e($trans['ac_type']); ?></td>
                                    <td><?php echo e($trans['desc']); ?></td>
                                    <td><?php echo e(date('d-M-Y',strtotime($trans['created_at']))); ?></td>
                                    <td><?php echo e($trans['amount']); ?></td>
                                    <td>-</td>
                                    <td><?php echo e($trans['balance']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <tr>
                            <td>
                                <div class="float-right"> <strong>Total:</strong></div>
                            </td>
                            <td colspan="5">
                                <div class="float-right"> <strong><?php echo e($subTotal); ?></strong></div>
                            </td>
                            <td>-</td>
                            <td></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type='text/javascript'>
        $(document).ready(function (){

            $('select[name=ac_type]').change(function(){
                var ac_type=$('select[name=ac_type]').val();
                if(ac_type=='clients') {

                    $(".file_section").css("display", "block");
                }else{
                    $(".file_section").css("display", "none");
                }

                (ac_type=='vendors')? $('#ac_label').html('Vendors'):$('#ac_label').html('Clients')


                $.ajax({

                    type: 'ajax',
                    method: 'get',

                    url: '<?php echo e(url("/getAccountsName")); ?>',

                    data: {ac_type: ac_type},

                    async: false,

                    dataType: 'json',

                    success: function(response) {

                        var html = '<option value="">Choose File</option>';

                        var i;
                        if(response.length > 0) {

                            for (i = 0; i < response.length; i++) {

                                html += '<option value="' + response[i].id + '">' + response[i].name + '</option>';

                            }
                        }else{
                            var html = '<option value="">Choose One</option>';
                            toastr.error('data not found');
                        }


                        $('#showAccounts').html(html);

                    },

                    error: function() {

                        toastr.error('data not found');

                    }

                });
            });


            // get clients files
            $('select[name=ac_id]').change(function(){
                var ac_type=$('select[name=ac_type]').val();
                var ac_id=$('select[name=ac_id]').val();
                if(ac_type=='clients') {

                    $.ajax({

                        type: 'ajax',
                        method: 'get',

                        url: '<?php echo e(url("/getClientsFiles")); ?>',

                        data: {ac_id: ac_id},

                        async: false,

                        dataType: 'json',

                        success: function (response) {

                            var html = '<option value="">Choose File</option>';

                            var i;
                            if (response.length > 0) {

                                for (i = 0; i < response.length; i++) {

                                    html += '<option value="' + response[i].id + '">' + response[i].item + '</option>';

                                }
                            } else {
                                var html = '<option value="">Choose File</option>';
                                toastr.error('data not found');
                            }


                            $('#showFileSection').html(html);

                        },

                        error: function () {

                            toastr.error('data not found');

                        }

                    });
                }
            });



            //company_id dependent dropdown
            $('select[name=bank_id]').change(function() {

                var bank_id = $('select[name=bank_id]').val();

                $.ajax({

                    type: 'ajax',

                    method: 'get',

                    url: '<?php echo e(url("/getBankBranches")); ?>',

                    data: {
                        bank_id: bank_id
                    },

                    async: false,

                    dataType: 'json',

                    success: function(data) {


                        var html = '';

                        var i;
                        if (data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].branch + '</option>';
                            }
                        } else {
                            var html = '<option value="">Choose Branch</option>';
                            toastr.error('branch not exist');
                        }


                        $('#showBranch').html(html);

                    },

                    error: function() {

                        toastr.error('db error');


                    }

                });
            });



            $('select[name=trans_mode]').change(function(){
                var trans_mode=$('select[name=trans_mode]').val();

                if(trans_mode=='cheque'){

                    $(".bank_section").css("display", "block");
                }else{

                    $(".bank_section").css("display", "none");
                }

                if(trans_mode=='cash'){

                    $(".cash_section").css("display", "block");
                }else{

                    $(".cash_section").css("display", "none");
                }



            });


            $("#btnSaveANDPrint").click(function(e){
                e.preventDefault();
                var formData= $('#ReceiptForm').serialize();


                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("receipt")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    success: function(data) {

                        if(data) {
                            $('#ReceiptForm')[0].reset();
                            toastr.success('Amount received successfully!');
                            url = "<?php echo e(url("print-receipt")); ?>"+"/"+data;
                            window.location = url;
                        }
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    }

                });

            });

            //save Payments
            $('#ReceiptForm').on('submit',function(e){
                e.preventDefault();

                var formData= $('#ReceiptForm').serialize();


                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("receipt")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    success: function(data) {

                        if(data) {
                            $('#ReceiptForm')[0].reset();
                            toastr.success('Amount received successfully!');
                            window.location.reload();
                        }
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    }

                });


            });



        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/accounts/payments/receipts.blade.php ENDPATH**/ ?>