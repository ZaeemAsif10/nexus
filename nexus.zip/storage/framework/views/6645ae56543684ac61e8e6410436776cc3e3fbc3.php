<?php $__env->startSection('content'); ?>
    <style type="text/css">
        body {
            font-family: Arial;
            font-size: 10pt;
        }
        table {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th,
        table td {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Manage Expense</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Manage Expense </li>
                        </ul>
                    </div>

                    <div class="col-auto float-right ml-auto">
                        <a href="<?php echo e(url('/expense-summary')); ?>" class="btn add-btn" title="Expense Summary"><i class="fa fa-list" aria-hidden="true"></i></a>
                    </div>

                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <form method="post" id="expenseForm" action="<?php echo e(url('manage-expense')); ?>" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="form-group col-sm-6">
                                <label>Expense Head <span class="text-danger">*</span></label>
                                <select name="head_id" class="form-control selectpicker" data-container="body" data-live-search="true" title="Choose Head" required>

                                    <?php if(isset($data['head'])): ?>
                                        <?php $__currentLoopData = $data['head']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($head->id); ?>"><?php echo e($head->exp_head); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <div id="dateError"></div>
                            </div>


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for=""> Account</label>
                                    <select name="ac_id" id="" class="form-control" required>
                                        <option value="">Choose Account</option>
                                        <?php if(isset($data['accounts'])): ?>
                                            <?php $__currentLoopData = $data['accounts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($account->id); ?>"><?php echo e($account->actype['ac_type']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        please choose account.
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="row">


                            <div class="form-group col-sm-6">
                                <label>Amount <span class="text-danger">*</span></label>
                                <input class="form-control" type="number" name="amount" placeholder="Amount" required>
                                <span class="balance-error"></span>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Narration <span class="text-danger">*</span></label>
                                <textarea name="narration" class="form-control" name="" id="" cols="10" rows="3" required style="height: 47px"></textarea>
                            </div>
                        </div>


                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn" type="submit" id="btnSubmit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>



        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script>
            $(document).ready(function() {

                $('#expenseForm').unbind().on('submit',function(e){
                    e.preventDefault();

                    var formData= $('#expenseForm').serialize();


                    $.ajax({

                        type: 'ajax',
                        method: 'post',
                        url: '<?php echo e(url("manage-expense")); ?>',
                        data: formData,
                        async: false,
                        dataType: 'json',
                        beforeSend: function() {
                            $('#btnSubmit').prop('disabled',true);
                            $('#btnSubmit').text('loading...');
                        },
                        success: function(data) {

                            if(data.success) {
                                $('#expenseForm')[0].reset();
                                toastr.success('Success messages');
                            }

                            if(data.errors) {
                                toastr.error('missing some fields');
                            }
                        },
                        complete: function() {
                            $('#btnSubmit').prop('disabled',false);
                            $('#btnSubmit').text('Submit');

                        },

                        error: function() {
                            toastr.error('something went wrong');

                        }

                    });


                });



                // chek available Account Balance
                $('input[name=amount]').on('keyup', function() {
                    var amount=$(this).val();
                    var account_id=$('select[name=ac_id]').val();

                    $.ajax({
                        type: 'ajax',
                        method: 'get',
                        url: '<?php echo e(url("/getAccountsAvailBalance")); ?>',
                        data: {account_id: account_id,bank:0},
                        async: false,
                        dataType: 'json',
                        success: function(data) {
                            var currBalance=data;


                            if(amount > currBalance){
                                $("#btnSubmit").prop("disabled", true);
                                var p='<span style="color:red">Balance insufficient</span>';
                                $('.balance-error').html(p);


                            }
                            else{
                                $("#btnSubmit").prop("disabled", false);
                                var p='';
                                $('.balance-error').html(p);
                            }

                        },

                        error: function() {

                            toastr.error('something went wrong');

                        }

                    });



                });

            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/accounts/expense/manage-expense.blade.php ENDPATH**/ ?>