<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Employee Task Details</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Employee Task Details</li>
                        </ul>
                    </div>

                </div>
            </div>

            <!-- /Page Header -->
            <div class="card mb-0">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">
                                <div class="profile-img-wrap">
                                    <div class="profile-img">
                                        <a href="#">
                                            <img alt=""
                                                 src="<?php echo e(asset('storage/app/public/uploads/staff-images/user1-128x128.png')); ?>"></a>
                                    </div>
                                </div>
                                <div class="profile-basic">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="profile-info-left">
                                                <h3 class="user-name m-t-0 mb-0">
                                                    <?php echo e($data['emp'] ? $data['emp']->name: ''); ?>

                                                </h3>
                                                <h6 class="text-muted"></h6>
                                                <small class="text-muted"></small>
                                                <div class="staff-id">
                                                    <?php echo e($data['emp']->getDesignation->desig_name); ?>

                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-md-7">
                                            <ul class="personal-info">
                                                <li>
                                                    <div class="title">Contact:</div>
                                                    <div class="text"><a
                                                            href=""><?php echo e($data['emp'] ?$data['emp']->phone  : ''); ?></a>
                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="title">Email:</div>
                                                    <div class="text"><a
                                                            href=""><?php echo e($data['emp'] ?$data['emp']->email : ''); ?></a>
                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="title">Created At:</div>
                                                    <div class="text"><a
                                                            href=""><?php echo e($data['emp'] ?$data['emp']->created_at : ''); ?></a>
                                                    </div>
                                                </li>


                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-content">

                <!-- Profile Info Tab -->
                <div id="emp_profile" class="pro-overview tab-pane fade show active">

                    <div class="row">
                        <?php if(isset($data['empTasks'])): ?>
                            <?php $__currentLoopData = $data['empTasks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $progress=0; ?>
                                <div class="col-md-6 d-flex">
                                    <div class="card profile-box flex-fill">
                                        <div class="card-body">
                                            <span class="card-title">
                                                <div class="pro-progress">
                                                    <div class="pro-progress-bar">
                                                        <div class="progress">
                                                            <div class="progress-bar bg-success" role="progressbar"
                                                                 style="width:<?php echo e(round($progress)); ?>%"></div>
                                                        </div>
                                                        <span><?php echo e(round($progress)); ?>%</span>
                                                    </div>
                                                </div>

                                            </span>
                                            <ul class="personal-info">
                                                <li>
                                                    <div class="title">Title.</div>
                                                    <div class="text badge bg-inverse-info"><?php echo e($task->task); ?>



                                                    </div>
                                                </li>
                                                <?php
                                                    $subTask =App\Models\SubTask::getSubTaskAcordingMainTask($task->id);

                                                ?>
                                                <?php if($subTask->count() > 0): ?>
                                                <li>
                                                    <div class="title">Sub Task: </div>
                                                    <div class="text">

                                                            <?php $__currentLoopData = $subTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subTask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="text badge bg-inverse-primary"> <?php echo e($subTask->sub_task_title); ?> <span class="bg-inverse-success">
                                                                <?php if($subTask->status==1): ?>
                                                            <i class="fa fa-check text-success"></i>
                                                                    <?php else: ?>
                                                                    <i class="fa fa-close text-danger"></i>
                                                                <?php endif; ?>
                                                            </span></div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </div>
                                                </li>
                                                <?php endif; ?>

                                                <li>
                                                    <div class="title">Dead Line.</div>

                                                        <div class="text badge bg-inverse-danger"><?php echo e($task->end_date); ?></div>
                                                </li>

                                                <li>
                                                    <div class="title">Description</div>
                                                    <div class="text">
                                                        <?php echo e($task->desc); ?>

                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="title">Created At</div>
                                                    <div class="text">
                                                        <?php echo e($task->created_at); ?>

                                                    </div>
                                                </li>

                                                <li>
                                                    <div class="title">Comments</div>
                                                    <div class="text">

                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /Profile Info Tab -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/tasks/emp-tasks.blade.php ENDPATH**/ ?>