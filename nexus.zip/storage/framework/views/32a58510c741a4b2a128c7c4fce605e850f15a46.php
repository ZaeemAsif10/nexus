<?php $__env->startSection('content'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <!-- Page Header -->
            <?php echo $__env->make('setup.welcome-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /Page Header -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card-group m-b-30">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-3">
                                    <div>
                                        <span class="d-block">Leads</span>
                                    </div>

                                </div>
                                <h3 class="mb-3"><?php echo e($data['totalLeads']); ?></h3>
                                <div class="progress mb-2" style="height: 5px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 70%;"
                                        aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="mb-0">This Month <span
                                        class="text-muted"><?php echo e($data['thisMonthLeads']); ?></span></p>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-3">
                                    <div>
                                        <span class="d-block">Response Queries</span>
                                    </div>

                                </div>
                                <h3 class="mb-3"><?php echo e($data['responceQueries']); ?></h3>
                                <div class="progress mb-2" style="height: 5px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 70%;"
                                        aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="mb-0">This Month <span
                                        class="text-muted"><?php echo e($data['thisMonthResponceQueirs']); ?></span></p>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-3">
                                    <div>
                                        <span class="d-block">Done Meetings</span>
                                    </div>

                                </div>
                                <h3 class="mb-3"><?php echo e($data['doneMeetings']); ?></h3>
                                <div class="progress mb-2" style="height: 5px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 70%;"
                                        aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="mb-0">This Month <span
                                        class="text-muted"><?php echo e($data['doneMeetingsThisMonth']); ?></span></p>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-3">
                                    <div>
                                        <span class="d-block">Sales</span>
                                    </div>

                                </div>
                                <h3 class="mb-3"><?php echo e($data['sales']); ?></h3>
                                <div class="progress mb-2" style="height: 5px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 70%;"
                                        aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="mb-0">This Month <span
                                        class="text-muted"><?php echo e($data['salesThisMonth']); ?></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Statistics Widget -->
            <div class="row">
                <div class="col-md-12 col-lg-6 col-xl-4 d-flex">
                    <div class="card flex-fill">
                        <div class="card-body">

                            <div class="row mb-3">
                                <div class="col-md-4"><h4 class="card-title mt-2">Leads</h4></div>

                            </div>


                            <div class="statistics">
                                <div class="row">
                                    <div class="col-md-6 col-6 text-center">
                                        <div class="stats-box mb-4">
                                            <p>Today Leads</p>
                                            <h3><?php echo e($data['todayCreatedLeads']); ?></h3>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6 text-center">
                                        <div class="stats-box mb-4">
                                            <p>Total Leads</p>
                                            <h4><?php echo e($data['totalLeads']); ?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="progress mb-4">
                                <div class="progress-bar bg-purple" role="progressbar" style="width: 0%" aria-valuenow="30"
                                    aria-valuemin="0" aria-valuemax="100">30%</div>
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 0%" aria-valuenow="18"
                                    aria-valuemin="0" aria-valuemax="100">22%</div>
                                <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="12"
                                    aria-valuemin="0" aria-valuemax="100">24%</div>
                            </div>
                            <div>
                                <p><a href="<?php echo e(url('leads-params') . '/' . encrypt(6) . '/' . encrypt('admin')); ?>"><i
                                            class="fa fa-dot-circle-o text-warning mr-2"></i>Today Created Leads <span
                                            class="float-right"><?php echo e($data['todayCreatedLeads']); ?></span></a></p>
                                <p>
                                    <a href="<?php echo e(url('leads-params') . '/' . encrypt(1) . '/' . encrypt('admin')); ?>"><i
                                            class="fa fa-dot-circle-o text-success mr-2"></i>Today Follow Up <span
                                            class="float-right"><?php echo e($data['todayFollowUpsLeads']); ?></span></a>
                                </p>

                                <p><a href="<?php echo e(url('leads-params') . '/' . encrypt(2) . '/' . encrypt('admin')); ?>"><i
                                            class="fa fa-dot-circle-o text-purple  mr-2"></i>Tomorrow Follow Up <span
                                            class="float-right"><?php echo e($data['tomorrowLeads']); ?></span></a></p>

                                <p><a href="<?php echo e(url('leads-params') . '/' . encrypt(3) . '/' . encrypt('admin')); ?>"><i
                                            class="fa fa-dot-circle-o text-danger mr-2"></i>Not Approached Leads <span
                                            class="float-right"><?php echo e($data['notApproachedLeads']); ?></span></a>
                                </p>
                                <p><a href="<?php echo e(url('leads-params') . '/' . encrypt(4) . '/' . encrypt('admin')); ?>"><i
                                            class="fa fa-dot-circle-o text-info mr-2"></i>Over Due Leads <span
                                            class="float-right"><?php echo e($data['overDueLeads']); ?></span></a></p>




                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 col-lg-12 col-xl-4 d-flex">

                    <div class="card flex-fill dash-statistics">
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6"><h6 class="card-title mt-2">Temperatures <small>last 3 days</small></h6></div>

                            </div>

                            <div>
                                <p>
                                    <?php
                                        $temp = App\Models\Temprature::all();
                                    ?>
                                    <?php $__currentLoopData = $temp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $appLeads = App\Models\ApprochedLeads::getTempratureWiseLeads($temp->id,'counting','admin',NULL);
                                        ?>
                                        <a
                                            href="<?php echo e(url('leads-temp-wise/admin') . '/' . ($temp->id . '/' . $temp->temp)); ?>">
                                            <i class="fa fa-dot-circle-o text-success mr-2"></i><?php echo e($temp->temp); ?>


                                            <span class="float-right"><?php echo e($appLeads); ?></span></a>
                                </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 col-lg-6 col-xl-4 d-flex">
                    <div class="card flex-fill">
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-4"><h4 class="card-title mt-2">Calls</h4></div>

                            </div>

                            <div class="statistics">
                                <div class="row">
                                    <div class="col-md-6 col-6 text-center">
                                        <div class="stats-box mb-4">
                                            <p>Total Calls</p>
                                            <h3><?php echo e($data['totalCalls']); ?></h3>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-6 text-center">
                                        <div class="stats-box mb-4">
                                            <p>Calls<small>This Month</small></p>
                                            <h3><?php echo e($data['thisMonthCalls']); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <p><i class="fa fa-dot-circle-o text-purple mr-2"></i>Connected <span
                                        class="float-right"><?php echo e($data['connected']); ?></span></p>
                                <p><i class="fa fa-dot-circle-o text-warning mr-2"></i>Connected <small>This month</small>
                                    <span class="float-right"><?php echo e($data['thisMonthConnected']); ?></span>
                                </p>
                                <p><i class="fa fa-dot-circle-o text-success mr-2"></i>Not Connected <span
                                        class="float-right"><?php echo e($data['notConnected']); ?></span></p>
                                <p><i class="fa fa-dot-circle-o text-danger mr-2"></i>Not Connected <small>This
                                        month</small> <span
                                        class="float-right"><?php echo e($data['thisMonthnotConnected']); ?></span></p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--Sale Targets-->
            <div class="row">

                <div class="col-md-6 col-lg-6 col-xl-6 d-flex">
                    <div class="card flex-fill dash-statistics">
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6"><h5 class="card-title mt-2">Sale Targets <small>(Team)</small></h5></div>

                            </div>
                            <div class="stats-list">
                                <?php if(isset($data['saleManager'])): ?>
                                    <?php $__currentLoopData = $data['saleManager']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $totalAcheive = 0;
                                            $target = $manager->target_in_numbers;
                                            $totalAcheive = getManagerTeamAcheivements($manager->id, 'sale');

                                            $pers = ($totalAcheive * 100) / $target;
                                            $bg = 'warning';
                                            $pers < 50 ? ($bg = 'danger') : '';
                                            $pers > 50 && $pers < 70 ? ($bg = 'info') : '';
                                            $pers > 70 && $pers < 80 ? ($bg = 'primary') : '';
                                            $pers > 80 ? ($bg = 'success') : '';
                                        ?>

                                        <div class="stats-info">
                                            <p><?php echo e($manager->name); ?> (<?php echo e(round($pers, 0)); ?>%)
                                                <strong><?php echo e($totalAcheive); ?>

                                                    <small>/<?php echo e($target); ?> </small></strong>
                                            </p>
                                            <div class="progress">
                                                <div class="progress-bar bg-<?php echo e($bg); ?>" role="progressbar"
                                                    style="width:<?php echo e($pers); ?>%" aria-valuenow="22" aria-valuemin="0"
                                                    aria-valuemax="100" title="10%"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-6 d-flex">
                    <div class="card flex-fill dash-statistics">
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6"><h5 class="card-title mt-2">Sale Targets <small>(individual)</small></h5></div>

                            </div>
                            <div class="stats-list">

                                <?php if(isset($data['getIndividualSaleTeam'])): ?>
                                    <?php $__currentLoopData = $data['getIndividualSaleTeam']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teamTarget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php

                                            $totalAcheive=0;
                                                $target=$teamTarget->target_in_numbers;

                                                       $memberAcheive=getSalesManTargetAcheive($teamTarget->id,'sale');
                                                       $totalAcheive=$totalAcheive+$memberAcheive;

                                                    $pers=($totalAcheive *100)/$target;
                                                    $bg='warning';
                                                    ($pers<50)?$bg='danger':'';
                                                    ($pers>50 && $pers<70)?$bg='info':'';
                                                    ($pers>70 && $pers<80)?$bg='primary':'';
                                                    ($pers>80)?$bg='success':'';


                                        ?>
                                        <div class="stats-info">
                                            <p><?php echo e($teamTarget->name); ?> (<?php echo e($pers); ?>)%
                                                <strong><?php echo e($totalAcheive); ?><small>/<?php echo e($target); ?></small></strong>
                                            </p>
                                            <div class="progress">
                                                <div class="progress-bar bg-info" role="progressbar"
                                                    style="width: <?php echo e($pers); ?>%" aria-valuenow="22" aria-valuemin="0"
                                                    aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Meetings Targets -->
            <div class="row">

                <div class="col-md-6 col-lg-6 col-xl-6 d-flex">
                    <div class="card flex-fill dash-statistics">
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6"><h5 class="card-title mt-2">Meeting Targets <small>(Team)</small></h5></div>

                            </div>

                            <div class="stats-list">
                                <?php if(isset($data['meetingManager'])): ?>
                                    <?php $__currentLoopData = $data['meetingManager']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $totalAcheive = 0;
                                            $target = $manager->target_in_numbers;
                                            $totalAcheive = getManagerTeamAcheivements($manager->id, 'meeting');
                                            $pers = ($totalAcheive * 100) / $target;
                                            $bg = 'warning';
                                            $pers < 50 ? ($bg = 'danger') : '';
                                            $pers > 50 && $pers < 70 ? ($bg = 'info') : '';
                                            $pers > 70 && $pers < 80 ? ($bg = 'primary') : '';
                                            $pers > 80 ? ($bg = 'success') : '';
                                        ?>

                                        <div class="stats-info">
                                            <p><?php echo e($manager->name); ?> (<?php echo e(round($pers, 1)); ?>%)
                                                <strong><?php echo e($totalAcheive); ?>

                                                    <small>/<?php echo e($target); ?> </small></strong>
                                            </p>
                                            <div class="progress">
                                                <div class="progress-bar bg-<?php echo e($bg); ?>" role="progressbar"
                                                    style="width:<?php echo e($pers); ?>%" aria-valuenow="22" aria-valuemin="0"
                                                    aria-valuemax="100" title="10%"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-xl-6 d-flex">
                    <div class="card flex-fill dash-statistics">
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6"><h5 class="card-title mt-2">Meeting Targets <small>(individual)</small></h5></div>

                            </div>

                            <div class="stats-list">

                                <?php if(isset($data['getIndividualMeetingTeam'])): ?>
                                    <?php $__currentLoopData = $data['getIndividualMeetingTeam']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meetingTeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php

                                            $totalAcheive=0;
                                                $target=$meetingTeam->target_in_numbers;
                                                   $totalAcheive= getSalesManTargetAcheive($meetingTeam->id,'meeting');

                                                    $pers=($totalAcheive *100)/$target;
                                                    $bg='warning';
                                                    ($pers<50)?$bg='danger':'';
                                                    ($pers>50 && $pers<70)?$bg='info':'';
                                                    ($pers>70 && $pers<80)?$bg='primary':'';
                                                    ($pers>80)?$bg='success':'';


                                        ?>
                                        <div class="stats-info">
                                            <p><?php echo e($meetingTeam->name); ?> (<?php echo e(round($pers, 1)); ?>)%
                                                <strong><?php echo e($totalAcheive); ?><small>/<?php echo e($target); ?></small></strong>
                                            </p>
                                            <div class="progress">
                                                <div class="progress-bar bg-info" role="progressbar"
                                                    style="width: <?php echo e($pers); ?>%" aria-valuenow="22" aria-valuemin="0"
                                                    aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Leads Responce-->


            <!-- Graps -->
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6 text-center">
                            <div class="card">
                                <div class="card-body">
                                    <a href="<?php echo e(url('inOutBoundleadsList') . '/' . encrypt(1)); ?>">
                                        <h3 class="card-title">Inbound</h3>
                                    </a>
                                    <canvas id="myChart" style="width:100%;max-width:600px"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 text-center">
                            <div class="card">
                                <div class="card-body">
                                    <a href="<?php echo e(url('inOutBoundleadsList') . '/' . encrypt(2)); ?>">
                                        <h3 class="card-title">Outbound</h3>
                                    </a>
                                    <canvas id="outBoundChart" style="width:100%;max-width:600px"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Content -->
    </div>

    <script>

        $(document).ready(function() {

            $('.date_range').daterangepicker({
                opens: 'left'
            }, function(start, end, label) {
                console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end
                    .format('YYYY-MM-DD'));
            });
            getInBoundValues();
            getOutBoundValues();


            function getOpenLeads() {

                $.ajax({
                    url: '<?php echo e(url("getOpenLeads")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {
                        $(".btn-submit").html("please wait...");

                    },
                    success: function(data) {
                        $('#open-lead-section').html(data);
                    },
                    complete : function(data){

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });
            }


            function getInBoundValues() {

                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    data: {
                        lead_type: 'inbound'
                    },
                    url: '<?php echo e(url('getLeadsAcordingSocilaPlatforms')); ?>',
                    success: function(data) {

                        var platforms = [];
                        var noOfVal = [];
                        for (i = 0; i < data.length; i++) {
                            platforms.push(data[i].platform);
                            noOfVal.push(data[i].total);
                        }

                        var xValues = platforms;
                        var yValues = noOfVal
                        var barColors = ["#3b5998", "#E1306C", "#25D366", "#800000"];

                        new Chart("myChart", {
                            type: "bar",
                            data: {
                                labels: xValues,
                                datasets: [{
                                    backgroundColor: barColors,
                                    data: yValues
                                }]
                            },
                            options: {
                                legend: {
                                    display: false
                                },
                                title: {
                                    display: true,
                                    text: "The A Team Call Center Leads"
                                }
                            }
                        });
                    },


                });

            }

            function getOutBoundValues() {

                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    data: {
                        lead_type: 'outbound'
                    },
                    url: '<?php echo e(url('getLeadsAcordingSocilaPlatforms')); ?>',
                    success: function(data) {

                        var platforms = [];
                        var noOfVal = [];
                        for (i = 0; i < data.length; i++) {
                            platforms.push(data[i].platform);
                            noOfVal.push(data[i].total);
                        }

                        var xValues = platforms;
                        var yValues = noOfVal
                        var barColors = ["#3b5998", "#E1306C", "#25D366", "#800000"];

                        new Chart("outBoundChart", {
                            type: "bar",
                            data: {
                                labels: xValues,
                                datasets: [{
                                    backgroundColor: barColors,
                                    data: yValues
                                }]
                            },
                            options: {
                                legend: {
                                    display: false
                                },
                                title: {
                                    display: true,
                                    text: "The A Team Call Center Leads"
                                }
                            }
                        });
                    },


                });

            }


            $('input[name=leads_date_range]').change(function(){
                var leads_date_range=$('input[name=leads_date_range]').val();



                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("get_responsed_leads")); ?>',
                    data: {leads_date_range:leads_date_range},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        $('#responseLeads').html(data);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },
                });

            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u443729190/domains/shahraantech.com/public_html/rgms/resources/views/call-center/dashboard.blade.php ENDPATH**/ ?>