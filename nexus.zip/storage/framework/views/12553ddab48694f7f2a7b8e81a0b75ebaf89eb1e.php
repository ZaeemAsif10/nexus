

<?php $__env->startSection('content'); ?>
    <main id="main">
        <section class="plan-tbl intro-single">
            <div class="container mt-5">
                <div class="row">

                    <?php if(count($data['projects']) > 0): ?>
                        <?php $__currentLoopData = $data['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 bg-a card p-4 mt-5">
                                <div class="text-center bg-transparent">
                                    <h3 class="text-black">A PROJECT BY<br><?php echo e($project->title); ?> (PVT) LTD</h3>
                                    <p class="text-start" style="font-weight: bolder;">LOCATION: MAIN GT ROAD,RAWAT</p>
                                    <div class="card bg-transparent p-3" style="border: 1px solid black;">
                                        <h2 class="text-black">PRE-LAUNCH PAYMENT PLAN</h2>
                                        <h3 class="text-black">4 YEAR INSTALLMENTS</h3>

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2" scope="col">Plot Size</th>
                                                    <th scope="col">Down payment</th>
                                                    <th scope="col">Allocation Charges</th>
                                                    <th scope="col">Confirmation Charges</th>
                                                    <th scope="col">Monthly Installments</th>
                                                    <th scope="col">Every 6 Month</th>
                                                    <th rowspan="2" scope="col">Total Price</th>
                                                </tr>
                                                <tr>
                                                    <th scope="col">15%</th>
                                                    <th scope="col">10%</th>
                                                    <th scope="col">10%</th>
                                                    <th scope="col">48</th>
                                                    <th scope="col">8</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $data['payment_plans'] = App\Models\Payment_plan::where('project_id', $project->id)
                                                        ->where('status', '!=', 1)
                                                        ->get();
                                                ?>
                                                <?php if(count($data['payment_plans']) > 0): ?>
                                                    <?php $__currentLoopData = $data['payment_plans']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <?php
                                                                $total = $payment_plan->down_payment 
                                                                + $payment_plan->allocation_charges 
                                                                + $payment_plan->confirmation_charges 
                                                                + ($payment_plan->monthly_installments * $payment_plan->total_month) 
                                                                + ($payment_plan->every_six_month * $payment_plan->six_month_install);
                                                            ?>
                                                            
                                                            <td><?php echo e($payment_plan->plot_size); ?></td>
                                                            <td><?php echo e($payment_plan->down_payment); ?></td>
                                                            <td><?php echo e($payment_plan->allocation_charges); ?></td>
                                                            <td><?php echo e($payment_plan->confirmation_charges); ?></td>
                                                            <td><?php echo e($payment_plan->monthly_installments); ?></td>
                                                            <td><?php echo e($payment_plan->every_six_month); ?></td>
                                                            <td><?php echo e($total); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>


                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </section>
    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web-side.setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\posch-city\resources\views/web-side/payment_plan.blade.php ENDPATH**/ ?>