<?php $__env->startSection('content'); ?>
    <div class="main-wrapper">
        <!-- /Sidebar -->
        <!-- Page Wrapper -->
        <div class="page-wrapper">
            <!-- Page Content -->
            <div class="content container-fluid">
                <div class="page-header my-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title bold-heading">Role Permissions</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active">Role Permissions</li>
                            </ul>
                        </div>
                        <div class="col-auto float-right ml-auto">
                            <a href="#" class="btn add-btn"  data-toggle="modal" data-target="#add_department" title="Add New Leads Temperature"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped table-hover data-table" >

                            <tr>
                                <th colspan="5" style="background: #252d50; color: white">Project & Targets</th>
                            </tr>
                            <tr>

                                <td>Targets Management</td>
                                <td> <input class="is_allow" type="checkbox" checked > Create Targets</td>
                                <td> </td>
                            </tr>
                            <tr>
                                <td>Project Management</td>
                                <td> <input class="is_allow" type="checkbox" checked > Project Management</td>
                                <td> <input class="is_allow" type="checkbox" checked > Tasks Management</td>
                                <td> <input class="is_allow" type="checkbox" checked > Team Management</td>

                            </tr>




                            <tr>
                                <th colspan="5" style="background: #252d50; color: white">Leads Management</th>
                            </tr>

                            <tr>
                                <td>Leads</td>
                                <td> <input class="is_allow" type="checkbox" checked > Create Leads</td>
                                <td> <input class="is_allow" type="checkbox" checked > Leads List</td>
                                <td> <input class="is_allow" type="checkbox" checked > My Leads</td>

                            </tr>


                            <tr>
                                <th colspan="5" style="background: #252d50; color: white">Sales Management</th>
                            </tr>

                            <tr>
                                <td>Leads</td>

                                <td> <input class="is_allow" type="checkbox" checked > Deals List</td>
                                <td> <input class="is_allow" type="checkbox" checked > My Deals</td>

                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /Page Content -->
        </div>
        <!-- Add Department Modal -->
        <div id="add_department" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Role Permissions</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="modalDismiss">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo e(url('role-permissions')); ?>" id="LeadForm" class="needs-validation" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label> Permission <span class="text-danger">*</span></label>
                                        <select name="permission_id" id="" class="form-control">
                                            <option value="">Choose Permission</option>
                                            <?php if(isset($data['permission'])): ?>
                                                <?php $__currentLoopData = $data['permission']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($per->id); ?>"><?php echo e($per->module); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            Please choose  permission.
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label> Role <span class="text-danger">*</span></label>
                                        <select class="form-control form-control-sm select2" multiple="multiple" name="role_id[]" required>
                                            <option value="">Choose Permission</option>
                                            <?php if(isset($data['roles'])): ?>
                                                <?php $__currentLoopData = $data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            Please choose  mode.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="submit-section">
                                <button class="btn btn-primary" type="submit" id="btnSubmit">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Add Department Modal -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/call-center/roles/permission-test.blade.php ENDPATH**/ ?>