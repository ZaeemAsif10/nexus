<?php $__env->startSection('content'); ?>
<style type="text/css">
    body {
        font-family: Arial;
        font-size: 10pt;
    }

    table {
        border: 1px solid #ccc;
        border-collapse: collapse;
    }

    table th {
        background-color: #F7F7F7;
        color: #333;
        font-weight: bold;
    }

    table th,
    table td {
        padding: 5px;
        border: 1px solid #ccc;
    }
</style>
<div class="page-wrapper">
    <!-- Page Content -->
    <div class="content container-fluid">
        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title bold-heading">Expense Summary</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Expense Summary</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="<?php echo e(url('/manage-expense')); ?>" class="btn add-btn" title="Manage Expense"><i class="fa fa-plus" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">


                <table class="table table-striped table-hover" id="datatable">
                    <thead>

                        <tr>
                            <th>SR#</th>
                            <th>Exp Head</th>
                            <th>Account</th>
                            <th>Amount</th>
                            <th>Narration</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="summaryTable">
                    <?php $total=0; ?>
                        <?php if(isset($data['exp'])): ?>
                        <?php $__currentLoopData = $data['exp']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php $total=$total + $exp->amount; ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($exp->headname->exp_head); ?></td>
                            <td><?php echo e($exp->acname->actype['ac_type']); ?></td>
                            <td><?php echo e($exp->amount); ?></td>
                            <td><?php echo e($exp->desc); ?></td>
                            <td><?php echo e($exp->created_at); ?></td>
                            <td class="text-right">
                                <div class="dropdown dropdown-action">
                                    <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item btn_edit_summary" href="#" data-toggle="modal" data="<?php echo e($exp->id); ?>"><i class="fa fa-pencil m-r-5n "></i> Edit</a>
                                        <a class="dropdown-item btn_delete_summary" href="#" data="<?php echo e($exp->id); ?>"><i class="fa fa-trash-o m-r-5 "></i> Delete</a>
                                    </div>
                                </div>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>

                    <tr>
                        <td>
                            <div class="float-right"> <strong>Total:</strong></div>
                        </td>
                        <td colspan="2">

                        </td>
                        <td> <strong>PKR <?php echo e(number_format($total,2)); ?></strong></td>
                        <td></td>
                        <td></td>
                        <td></td>

                    </tr>
                </table>

            </div>
        </div>
        <!-- /Page Content -->
    </div>


    <!-- Edit Expense summary -->
    <div id="edit_expense_summary_modal" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Category</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="" id="EditSummaryForm" class="needs-validation" novalidate>
                        <input type="hidden" name="expense_summary_id">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Expense Head <span class="text-danger">*</span></label>
                                    <select name="exp_head_id" class="form-control select" title="Choose Head" required>

                                    </select>
                                    <div id="dateError"></div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Amount <span class="text-danger">*</span></label>
                                    <input class="form-control" type="number" name="amount" placeholder="Amount" required>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Narration <span class="text-danger">*</span></label>
                                    <textarea name="narration" class="form-control" cols="10" rows="3" required></textarea>
                                </div>
                            </div>

                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn expense_summary_update" type="button">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Expense summary -->


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- CDN for Sweet Alert -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {

            //Edit expense summary
            $('#summaryTable').on('click', '.btn_edit_summary', function(e) {
                e.preventDefault();

                var id = $(this).attr('data');

                $('#edit_expense_summary_modal').modal('show');

                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("expense-summary-edit")); ?>',
                    data: {
                        id: id
                    },
                    async: false,
                    dataType: 'json',
                    success: function(data) {

                        $('input[name=expense_summary_id]').val(data.new_exp.id);

                        //edit dropdown in ajax
                        $.each(data.exp_head, function(key, exp) {

                            $('select[name="exp_head_id"]')
                                .append(`<option value="${exp.id}" ${exp.id == data.new_exp.exp_head_id ? 'selected' : ''}>${exp.exp_head}</option>`)
                        });

                        $('input[name=amount]').val(data.new_exp.expense_amount);
                        $('textarea[name=narration]').val(data.new_exp.expense_desc);
                    },

                    error: function() {

                        toastr.error('something went wrong');

                    }

                });

            });

            // script for delete data
            $('#summaryTable').on('click', '.btn_delete_summary', function(e) {
                e.preventDefault();

                var id = $(this).attr('data');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to Delete this Data!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "GET",
                            url: "<?php echo e(url('/expense-summary-delete')); ?>",
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            data: {
                                id: id
                            },
                            dataType: "json",
                            success: function(response) {
                                if (response.success) {
                                    toastr.success(response.success);
                                    setTimeout(function() {
                                        window.location.reload();
                                    }, 1000);
                                }
                            }
                        });
                    }
                });

            });

            //update expense summary
            $('.expense_summary_update').on('click', function() {

                var formData = $('#EditSummaryForm').serialize();

                $.ajax({
                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("expense-summary-update")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    success: function(data) {

                        if (data.success) {
                            $('#edit_expense_summary_modal').modal('hide');
                            toastr.success(data.success);
                            setTimeout(function() {
                                window.location.reload();
                            }, 2000);
                        }
                    },

                    error: function() {
                        toastr.error('something went wrong');

                    }

                });

            });

            //Datatables
            $('#datatable').DataTable();
        });
    </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/hrm.alphabuzzco.com/resources/views/accounts/expense/expense-summary.blade.php ENDPATH**/ ?>