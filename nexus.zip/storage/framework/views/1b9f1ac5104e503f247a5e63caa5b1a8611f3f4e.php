<?php $__env->startSection('content'); ?>

    <style type="text/css">
        body {
            font-family: Arial;
            font-size: 10pt;
        }

        table {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }

        table th {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }

        table th,
        table td {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>


    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">


            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Chart Of Accounts</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Chart Of Accounts</li>
                        </ul>
                    </div>

                </div>
            </div>

            <div class="page-menu">
                <div class="row">
                    <div class="col-sm-12">
                        <ul class="nav nav-tabs nav-tabs-bottom">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#main_type">Main Type</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#sub_type">Sub Type</a>

                            </li>

                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#detail_type">Detail Type</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#account_head">Account Head</a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>


            <div class="tab-content">
                <!--Main Account Type-->
                <div class="tab-pane show active" id="main_type">
                    <!-- Add Addition Button -->
                    <div class="text-right mb-4 clearfix">
                        <button class="btn btn-primary add-btn" type="button" data-toggle="modal" data-target="#main_type_modal" title="Add Main Type">
                            <i class="fa fa-plus"></i> </button>
                    </div>
                    <!-- /Add Addition Button -->
                    <!-- Payroll Additions Table -->
                    <div class="card">
                        <div class="card-body">
                            <div class="payroll-table">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>SR#</th>
                                            <th>Category</th>
                                            <th>Main A/C Name</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="mainAccountTable">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /Payroll Additions Table -->
                </div>
                <!--Main Account Type End Here-->

                <!--Sub Account Type Start Here-->

                <div class="tab-pane" id="sub_type">

                    <div class="text-right mb-4 clearfix">
                        <button class="btn btn-primary add-btn" type="button" data-toggle="modal" data-target="#sub_type_modal" title="Create Sub Account"><i class="fa fa-plus"></i></button>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="payroll-table">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>SR#</th>
                                            <th>Category</th>
                                            <th>Main A/C Name</th>
                                            <th>Sub A/C  Name</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="subAccountTable"></tbody>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Sub Account Type End Here-->


                <!-- Detail Type -->
                <div class="tab-pane" id="detail_type">

                    <div class="text-right mb-4 clearfix">
                        <button class="btn btn-primary add-btn" type="button" data-toggle="modal" data-target="#detail_type_modal" title="assign allowance"><i class="fa fa-plus"></i></button>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="payroll-table">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>SR#</th>
                                            <th>Category</th>
                                            <th>Main Account Type</th>
                                            <th>Sub Account Type</th>
                                            <th>Detail Account Type</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                <tbody id="detailAccountTable"></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- Account Head -->

                <div class="tab-pane" id="account_head">

                    <div class="text-right mb-4 clearfix">
                        <button class="btn btn-primary add-btn" type="button" data-toggle="modal" data-target="#account_head_modal" title="assign allowance"><i class="fa fa-plus"></i></button>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="payroll-table">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>SR#</th>
                                            <th>Category</th>
                                            <th>Main Account Type</th>
                                            <th>Sub Account Type</th>
                                            <th>Detail Account Type</th>
                                            <th>Account Head</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="headAccountTable"></tbody>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>



    <div id="main_type_modal" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Chart Of Account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(url('coa')); ?>" id="mainTypeForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="hidden" value="1" name="main_ac">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">Account Category <span
                                            class="text-danger">*</span></label>
                                    <select name="ac_cat_id" id="" class="form-control ac_cat_id">
                                        <option value="">Choose One</option>
                                        <option value="1">Balance Sheet Account</option>
                                        <option value="2">Income Statement Account</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">Main Account Type<span
                                            class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="main_ac_type"
                                           placeholder="Main Account Type" required>
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Sub Type Modal -->
    <div id="sub_type_modal" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Chart Of Account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(url('coa')); ?>" id="subTypeForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="hidden" value="1" name="sub_ac">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">Account Category <span
                                            class="text-danger">*</span></label>
                                    <select name="ac_cat_id" id="" class="form-control ac_cat_id">
                                        <option value="">Choose One</option>
                                        <option value="1">Balance Sheet Account</option>
                                        <option value="2">Income Statement Account</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">Main A/C<span
                                            class="text-danger">*</span></label>
                                    <select name="main_ac_id"  class="form-control main_ac main_ac_type" id="showMainAc">

                                    </select>
                                </div>
                            </div>


                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">Sub A/C Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="sub_ac_name" placeholder="Sub A/C Name" required class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Detail Type Modal -->

    <div id="detail_type_modal" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Chart Of Account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(url('coa')); ?>" id="detailTypeForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="hidden" value="1" name="detail_ac">

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="col-form-label">Account Category <span
                                            class="text-danger">*</span></label>
                                    <select name="ac_cat_id" id="" class="form-control ac_cat_id">
                                        <option value="">Choose One</option>
                                        <option value="1">Balance Sheet Account</option>
                                        <option value="2">Income Statement Account</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="col-form-label">Main A/C Type <span
                                            class="text-danger">*</span></label>
                                    <select name="main_ac_type_id"  class="form-control main_ac main_ac_type">

                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">Sub A/C<span
                                            class="text-danger">*</span></label>
                                    <select name="sub_ac_id" id="" class="form-control sub_ac">

                                    </select>
                                </div>
                            </div>


                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">Detail A/C Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="detail_ac_name" placeholder="Sub A/C Name" required class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Account Head Modal -->
    <div id="account_head_modal" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Chart Of Account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(url('coa')); ?>" id="headTypeForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="hidden" value="1" name="head_ac">

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="col-form-label">Account Category <span
                                            class="text-danger">*</span></label>
                                    <select name="ac_cat_id" id="" class="form-control ac_cat_id">
                                        <option value="">Choose One</option>
                                        <option value="1">Balance Sheet Account</option>
                                        <option value="2">Income Statement Account</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="col-form-label">Main A/C Type <span
                                            class="text-danger">*</span></label>
                                    <select name="main_ac_type"  class="form-control main_ac main_ac_type">

                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="col-form-label">Sub A/C<span
                                            class="text-danger">*</span></label>
                                    <select name="sub_ac_id"  class="form-control sub_ac sub_ac_type_id">

                                    </select>
                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="col-form-label">Detail A/C<span
                                            class="text-danger">*</span></label>
                                    <select name="detail_ac_id" id="detail_ac" class="form-control detail_ac">

                                    </select>
                                </div>
                            </div>


                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="col-form-label">A/C Head<span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="head_ac_name" placeholder="Sub A/C Name" required class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <script>
        $(document).ready(function() {
            getMainAc();
            getSubAc();
            getDetailAc();
            getHeadAcList();

            $('#mainTypeForm').unbind().on('submit', function(e) {
                e.preventDefault();
                var formData = $('#mainTypeForm').serialize();
                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("coa")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {

                        $(".submit-btn").prop("disabled", true);
                        $(".submit-btn").html("saving...");

                    },
                    success: function(data) {

                        if (data.success) {
                            getMainAc();
                            $('.close').click();
                            $('#mainTypeForm')[0].reset();
                            toastr.success(data.success);

                        }
                        if (data.errors) {
                            toastr.error(data.errors);
                        }
                    },

                    complete : function(data){
                        $(".submit-btn").html("Save");
                        $(".submit-btn").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },

                });


            });

//save sub account
            $('#subTypeForm').unbind().on('submit', function(e) {
                e.preventDefault();
                var formData = $('#subTypeForm').serialize();
                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("coa")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {

                        $(".submit-btn").prop("disabled", true);
                        $(".submit-btn").html("saving...");

                    },
                    success: function(data) {

                        if (data.success) {
                            getSubAc();
                            $('.close').click();
                            $('#subTypeForm')[0].reset();
                            toastr.success(data.success);

                        }
                        if (data.errors) {
                            toastr.error(data.errors);
                        }
                    },

                    complete : function(data){
                        $(".submit-btn").html("Save");
                        $(".submit-btn").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },

                });


            });


            //detail  ac
            $('#detailTypeForm').unbind().on('submit', function(e) {
                e.preventDefault();
                var formData = $('#detailTypeForm').serialize();
                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("coa")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {

                        $(".submit-btn").prop("disabled", true);
                        $(".submit-btn").html("saving...");

                    },
                    success: function(data) {

                        if (data.success) {
                            getDetailAc();
                            $('.close').click();
                            $('#subTypeForm')[0].reset();
                            toastr.success(data.success);

                        }
                        if (data.errors) {
                            toastr.error(data.errors);
                        }
                    },

                    complete : function(data){
                        $(".submit-btn").html("Save");
                        $(".submit-btn").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },

                });


            });


            //head ac type
            $('#headTypeForm').unbind().on('submit', function(e) {
                e.preventDefault();
                var formData = $('#headTypeForm').serialize();
                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("coa")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {

                        $(".submit-btn").prop("disabled", true);
                        $(".submit-btn").html("saving...");

                    },
                    success: function(data) {

                        if (data.success) {
                            getHeadAcList();
                            $('.close').click();
                            $('#subTypeForm')[0].reset();
                            toastr.success(data.success);

                        }
                        if (data.errors) {
                            toastr.error(data.errors);
                        }
                    },

                    complete : function(data){
                        $(".submit-btn").html("Save");
                        $(".submit-btn").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },

                });


            });


            function getMainAc() {

                $.ajax({

                    url: '<?php echo e(url("/getMainAcList")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',

                    success: function(data) {

                        var html = '';
                        var i;
                        var c = 0;
                        var catName='';

                        for (i = 0; i < data.length; i++) {
                    (data[i].cat_id==1)?catName='Balance Sheet Account':catName='Income Statment Account';

                            c++;

                            html += '<tr>'+
                                '<td>'+c+'</td>' +
                                '<td>'+catName+'</td>' +
                                '<td>'+data[i].main_ac_type+'</td>' +
                                '<td>'+data[i].created_at+'</td>' +
                                '<td class="text-right">'+
                                '<div class="dropdown dropdown-action">'+
                                '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>'+
                                '<div class="dropdown-menu dropdown-menu-right">'+
                                '<a href="#" class="dropdown-item lead-status" >Edit</a>'+
                                '<a href="#" class="dropdown-item lead-status" >Delete</a>'+
                                '</div>'+
                                '</div>'+
                                '</td>'

                                '</tr>';
                        }


                        $('#mainAccountTable').html(html);

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });
            }


            function getSubAc() {

                $.ajax({

                    url: '<?php echo e(url("/getSubAcList")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',

                    success: function(data) {

                        var html = '';
                        var i;
                        var c = 0;
                        var catName='';

                        for (i = 0; i < data.length; i++) {
                            c++;
                            (data[i].mainacname.cat_id==1)?catName='Balance Sheet Account':catName='Income Statment Account';

                            html += '<tr>'+
                                '<td>'+c+'</td>' +
                                '<td>'+catName+'</td>' +
                                '<td>'+data[i].mainacname.main_ac_type+'</td>' +
                                '<td>'+data[i].sub_ac_type+'</td>' +
                                '<td>'+data[i].created_at+'</td>' +
                                '<td class="text-right">'+
                                '<div class="dropdown dropdown-action">'+
                                '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>'+
                                '<div class="dropdown-menu dropdown-menu-right">'+
                                '<a href="#" class="dropdown-item lead-status" >Edit</a>'+
                                '<a href="#" class="dropdown-item lead-status" >Delete</a>'+
                                '</div>'+
                                '</div>'+
                                '</td>'

                            '</tr>';
                        }


                        $('#subAccountTable').html(html);

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });
            }

            //getDetailAc

            function getDetailAc() {

                $.ajax({

                    url: '<?php echo e(url("/getDetailAcList")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',

                    success: function(data) {

                        var html = '';
                        var i;
                        var c = 0;
                        var catName='';

                        for (i = 0; i < data.length; i++) {
                            (data[i].subacname.mainacname.cat_id==1)?catName='Balance Sheet Account':catName='Income Statment Account';

                            c++;

                            html += '<tr>'+
                                '<td>'+c+'</td>' +
                                '<td>'+catName+'</td>' +
                                '<td>'+data[i].subacname.mainacname.main_ac_type+'</td>' +
                                '<td>'+data[i].subacname.sub_ac_type+'</td>' +
                                '<td>'+data[i].detail_ac_name+'</td>' +
                                '<td>'+data[i].created_at+'</td>' +
                                '<td class="text-right">'+
                                '<div class="dropdown dropdown-action">'+
                                '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>'+
                                '<div class="dropdown-menu dropdown-menu-right">'+
                                '<a href="#" class="dropdown-item lead-status" >Edit</a>'+
                                '<a href="#" class="dropdown-item lead-status" >Delete</a>'+
                                '</div>'+
                                '</div>'+
                                '</td>'

                            '</tr>';
                        }


                        $('#detailAccountTable').html(html);

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });
            }

            //get head Ac List
            function getHeadAcList() {

                $.ajax({

                    url: '<?php echo e(url("/getHeadAcList")); ?>',
                    type: 'get',
                    async: false,
                    dataType: 'json',

                    success: function(data) {

                        var html = '';
                        var i;
                        var c = 0;
                        var catName=1;

                        for (i = 0; i < data.length; i++) {
                            (data[i].mainacname.cat_id==1)?catName='Balance Sheet Account':catName='Income Statment Account';

                            c++;

                            html += '<tr>'+
                                '<td>'+c+'</td>' +
                                '<td>'+catName+'</td>' +
                                '<td>'+data[i].mainacname.main_ac_type+'</td>' +
                                '<td>'+data[i].subacname.sub_ac_type+'</td>' +
                                '<td>'+data[i].detailacname.detail_ac_name+'</td>' +
                                '<td>'+data[i].ac_head+'</td>' +
                                '<td>'+data[i].created_at+'</td>' +
                                '<td class="text-right">'+
                                '<div class="dropdown dropdown-action">'+
                                '<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>'+
                                '<div class="dropdown-menu dropdown-menu-right">'+
                                '<a href="#" class="dropdown-item lead-status" >Edit</a>'+
                                '<a href="#" class="dropdown-item lead-status" >Delete</a>'+
                                '</div>'+
                                '</div>'+
                                '</td>'

                            '</tr>';
                        }


                        $('#headAccountTable').html(html);

                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }

                });
            }



            //account category for get main account type
            $('.ac_cat_id').change(function() {

                var cat_id=$(this).val();

                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getMainAccountBaseOfCat")); ?>',
                    data: {cat_id: cat_id},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);

                        var html = '<option value="">Choose One</option>';

                        var i;
                        if (data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].main_ac_type + '</option>';
                            }
                        } else {
                            var html = '<option value="">Choose One</option>';
                            toastr.error('data not found');
                        }


                        $('.main_ac').html(html);

                    },

                    error: function() {

                        toastr.error('db error');


                    }

                });
            });
            //main account type for get main sub ac type
            $('.main_ac_type').change(function() {

                var main_ac_type_id = $(this).val();

                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getSubAccountBaseOfMain")); ?>',
                    data: {main_ac_type_id: main_ac_type_id},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);

                        var html = '<option value="">Choose One</option>';

                        var i;
                        if (data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].sub_ac_type + '</option>';
                            }
                        } else {
                            var html = '<option value="">Choose One</option>';
                            toastr.error('data not found');
                        }


                        $('.sub_ac').html(html);

                    },

                    error: function() {

                        toastr.error('db error');


                    }

                });
            });


            //sub account type for get main sub ac type

            $('.sub_ac_type_id').change(function() {

                var sub_ac_type_id = $(this).val();

                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getDetailAccountBaseOfSubAcc")); ?>',
                    data: {sub_ac_type_id: sub_ac_type_id},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        console.log(data);

                        var html = '<option value="">Choose One</option>';

                        var i;
                        if (data.length > 0) {

                            for (i = 0; i < data.length; i++) {

                                html += '<option value="' + data[i].id + '">' + data[i].detail_ac_name + '</option>';
                            }
                        } else {
                            var html = '<option value="">Choose One</option>';
                            toastr.error('data not found');
                        }


                        $('#detail_ac').html(html);

                    },

                    error: function() {

                        toastr.error('db error');


                    }

                });
            });


        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/coa/index.blade.php ENDPATH**/ ?>