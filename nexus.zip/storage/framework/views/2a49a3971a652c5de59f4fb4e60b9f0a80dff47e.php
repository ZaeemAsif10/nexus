



<?php $__env->startSection('content'); ?>


    <div class="page-wrapper">

        <!-- Page Content -->
        <div class="content container-fluid">

            <!-- Page Header -->


            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">My Targets</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">My Targets</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_leave" title="Add Achievements"><i class="fa fa-plus"></i> </a>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->




            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">


                        <table class="table table-striped " id="datatable">
                            <thead>
                            <tr>
                                <th style="width: 30px;">#</th>

                                <th>Target</th>
                                <th>Target Amount</th>

                                <th>From</th>
                                <th>To</th>

                                <th>Status </th>
                                <th>Progress </th>
                            </tr>
                            </thead>
                            <tbody id="targetTable">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <!-- /Page Content -->





        <div id="add_leave" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add  Target Achievements</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form method="post" id="targetForm" action="<?php echo e(url("emp-targets")); ?>" class="needs-validation" novalidate>
                            <?php echo csrf_field(); ?>


                            <div class="row">



                                <div class="form-group col-sm-6">

                                    <label>Task List </label>
                                    <select class="select"   required name="target_id">
                                        <option value="">Choose Task</option>
                                        <?php if(isset($data)): ?>
                                            <?php $__currentLoopData = $data['targets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($target->id); ?>"><?php echo e($target->task); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </select>
                                </div>


                                <div class="form-group col-sm-6">
                                    <label>Amount <span class="">(optional)</span></label>
                                    <input class="form-control" type="number" name="target_amount" placeholder="Target Amount">
                                </div>
                            </div>



                            <div class="row">
                                <div class="form-group col-sm-6">

                                    <select class="select" name="status"  required>
                                        <option value="">Status</option>
                                        <option value="progress">Inprogress</option>
                                        <option value="complete">Complete</option>

                                    </select>
                                </div>



                            </div>

                            <div class="submit-section">
                                <button class="btn btn-primary submit-btn" type="submit" id="btnSubmit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>





    </div>


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script type='text/javascript'>

    $(document).ready(function (){

        getMyTargetList();


        $('#targetForm').unbind().on('submit',function(e){
            e.preventDefault();

            var formData= $('#targetForm').serialize();


            $.ajax({

                type: 'ajax',
                method: 'post',
                url: '<?php echo e(url("emp-targets")); ?>',
                data: formData,
                async: false,
                dataType: 'json',
                success: function(data) {


                    if(data.success) {
                        getMyTargetList();
                        $('#targetForm')[0].reset();
                        $('.close').click();
                        toastr.success('Record save successfully');
                    }


                },

                error: function() {
                    toastr.error('something went wrong');

                }

            });


        })


        function getMyTargetList(){


            $.ajax({

                url: '<?php echo e(url("/empTargetList")); ?>',
                type: 'get',
                async: false,
                dataType: 'json',

                success: function(data)
                {

                    var html = '';
                    var i;
                    var c=0;
                    var amount='-';
                    var progress=0;

                    for(i=0; i<data.length; i++){

                        if(data[i].target_amount > 0){
                            amount=data[i].target_amount;
                            if(data[i].achievementsAmount) {
                                progress=(data[i].achievementsAmount *100)/data[i].target_amount;

                            }

                        };

                        if(data[i].status=='COMPLETE') {
                            progress=100;

                        }

                        c++;
                        html +='<tr>'+
                            '<td>'+c+'</td>'+

                            ' <td>'+data[i].task+'</td>'+
                            ' <td>'+amount+'</td>'+
                            ' <td>'+data[i].from+' </td>'+


                            ' <td>'+data[i].to+'</td>'+

                            ' <td>'+
                            ' <div class="dropdown action-label">'+
                            '<a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">'+
                            '  <i class="fa fa-dot-circle-o text-success"></i> '+data[i].status+'  </a>'+


                            ' </div>'+
                            ' </td>'+
                            '<td><p class="mb-1"> '+progress+'%</p><div class="progress" style="height:5px">' +
                            '<div class="progress-bar bg-success progress-sm" style="width: '+progress+'%;height:10px;"></div></div></td>'+


                            '</tr>';
                    }


                    $('#targetTable').html(html);

                },
                error:function()
                {
                    toastr.error('something went wrong');
                }

            });
        }

        //Datatables
        $('#datatable').DataTable();

    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\resources\views/targets/emp-targets.blade.php ENDPATH**/ ?>