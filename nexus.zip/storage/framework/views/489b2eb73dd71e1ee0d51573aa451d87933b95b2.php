<?php $__env->startSection('content'); ?>

    <style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        table
        {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th
        {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th, table td
        {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title bold-heading">Ledgers</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Ledgers  List</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <table class="table table-striped table-hover" id="datatable">
                    <thead>
                        <tr>
                            <th>SR#</th>
                            <th>COA Head</th>
                            <th>Activity</th>
                            <th>Narration</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $c=0; ?>
                    <?php if(isset($data['ledger'])): ?>
                        <?php $__currentLoopData = $data['ledger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $c++; ?>
                    <tr>
                        <td><?php echo e($c); ?></td>
                        <td>
<?php
    $levelHeadName=App\Models\Ledger::getLevelHeadName($ledger->coa_level,$ledger->coa_head_id)

    ?>
                            <?php echo e($levelHeadName); ?>

                        </td>
                        <td><?php echo e(strtoupper($ledger->trans_type)); ?></td>

                        <td><?php echo e($ledger->desc); ?></td>
                        <td><?php echo e($ledger->amount); ?></td>

                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/crm.alphabuzzco.com/resources/views/accounts/ledgers/index.blade.php ENDPATH**/ ?>