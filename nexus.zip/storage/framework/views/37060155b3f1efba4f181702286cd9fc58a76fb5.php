

<?php $__env->startSection('content'); ?>

<div class="page-wrapper">

    <style>
        /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->

        <div class="page-header my-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Products</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Products</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="<?php echo e(url('/products-list')); ?>" class="btn add-btn" title="Products List"><i class="fa fa-list" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
        <!-- /Page Header -->

        <div class="card">
            <div class="card-body">


                <form method="post" id="productForm" action="<?php echo e(url('products')); ?>" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-sm-4">
                            <label>Category <span class="text-danger">*</span></label>
                            <select name="cat_id" id="" class="form-control">

                                <?php if(isset($data['categories'])): ?>
                                <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>

                        </div>
                        <div class="form-group col-sm-8">
                            <label>Items <span class="text-danger">*</span></label>
                            <input class="form-control" type="text" name="item_name" placeholder="Item Name" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-sm-4">
                            <label>Unit <span class="text-danger">*</span></label>
                            <input class="form-control" type="text" name="unit" required placeholder="Item Unit">

                        </div>
                        <div class="form-group col-sm-4">
                            <label>Qty-Unit <span class="text-danger">*</span></label>
                            <input class="form-control" type="number" name="qty_unit" placeholder="Qty in Unit" required>
                        </div>
                        <div class="form-group col-sm-4">
                            <label>Unit Price <span class="text-danger">*</span></label>
                            <input class="form-control" type="number" name="unit_price" placeholder="Unit Price" required>
                        </div>
                    </div>


                    <div class="row">

                        <div class="form-group col-sm-4">
                            <label> Unit Size <span class="text-danger">*</span></label>
                            <input class="form-control" type="text" name="size" placeholder="Unit Size" required>
                        </div>
                        <div class="form-group col-sm-4">
                            <label>Tax %<span class="text-danger">*</span></label>
                            <input class="form-control" type="number" name="tax" required placeholder="Tax%">

                        </div>
                        <div class="form-group col-sm-4">
                            <label>Tax Amount <span class="text-danger">*</span></label>
                            <input class="form-control" type="number" name="tax_amount" placeholder="Tax Amount" required>
                        </div>

                    </div>

                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn" type="submit" id="btnSubmit">Submit</button>
                    </div>

                </form>
            </div>
        </div>

        <!-- /Page Content -->



    </div>



    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {

            // save product
            $('#productForm').on('submit', function(e) {
                e.preventDefault();

                var formData = $('#productForm').serialize();

                $.ajax({

                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("products")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    success: function(data) {

                        if (data.success) {
                            toastr.success(data.success);
                            var url = '<?php echo e(url("products-list")); ?>';
                            window.location.href = url;
                        }


                    },

                    error: function() {
                        toastr.error('something went wrong');

                    }

                });
            });

        });
    </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alphmnju/hrm.alphabuzzco.com/resources/views/accounts/products/index.blade.php ENDPATH**/ ?>