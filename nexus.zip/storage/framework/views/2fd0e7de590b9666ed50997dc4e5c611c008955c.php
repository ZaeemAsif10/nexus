<?php $__env->startSection('content'); ?>

    <style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        table
        {
            border: 1px solid #ccc;
            border-collapse: collapse;
        }
        table th
        {
            background-color: #F7F7F7;
            color: #333;
            font-weight: bold;
        }
        table th, table td
        {
            padding: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Regular Sale</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Regular Sale</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="<?php echo e(url('/sale-report')); ?>" class="btn add-btn" title="Sale List"><i class="fa fa-list" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="card">
                <form action="<?php echo e(url('regular-sale')); ?>" method="post" id="purchaseForm" class="needs-validation" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                        <div class="row">

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="">Date</label>
                               <input type="date" name="sale_date" class="form-control">
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                              <label for="">Customer Source</label>
                                <select name="customer_source" id="" class="form-control">
                                    <option value=""> Choose One</option>
                                    <option value="1">Call Center</option>
                                    <option value="2">Walk In</option>
                                </select>
                                </div>
                            </div>

                            <div class="col-md-3 leads-section" style="display: none">
                                <div class="form-group">
                                    <label for="">CC Leads</label>
                                    <select name="lead_id" class="form-control selectpicker"
                                            data-container="body" data-live-search="true">
                                        <option value="" selected>Choose One</option>
                                        <?php if(isset($data)): ?>
                                            <?php $__currentLoopData = $data['leadsMarketings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($lead->id); ?>"><?php echo e($lead->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                            <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                <label for="">Name</label>
                                <input type="text" class="form-control" placeholder="Customer Name" name="customer_name">
                                <div class="invalid-feedback">
                                    Please choose client.
                                </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                <label for="">Contact</label>
                                <input type="text" class="form-control" placeholder="Customer Contact" name="customer_contact">
                                <div class="invalid-feedback">
                                    Please choose client.
                                </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                <label for="">City</label>
                                <select name="customer_city" id="" class="form-control">
                                    <option value=""> Choose City</option>
                                    <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data['city']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->city_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>

                                </div>
                            </div>
                        </div>
                            <div class="row">

                                <div class="col-md-3">
                                    <label for="">Sale Through</label>
                                    <select name="sale_through" class="form-control">
                                        <option value="" selected>Choose City</option>
                                        <option value="1" >Sales Person</option>
                                        <option value="2" >Freelancer</option>

                                    </select>
                                </div>

                                <div class="col-md-3 sp-section" style="display: none">
                                    <label for="">Sales Person</label>
                                            <select name="sp_id" class="form-control selectpicker"
                                                    data-container="body" data-live-search="true">
                                                <option value="" selected>Choose City</option>
                                                <?php if(isset($data)): ?>
                                                    <?php $__currentLoopData = $data['salesPerson']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $csr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($csr->id); ?>"><?php echo e($csr->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                </div>

                                <div class="col-md-3 sp-section" style="display: none">
                                    <label for="">SP Commission % </label>
                                     <input type="radio" name="comm" value="0" class="comm-radio-btn"> &nbsp;
                                    Amount <input type="radio" name="comm" value="1" class="comm-radio-btn">
                                    <input type="hidden" placeholder="Sales Person Commission %" class="form-control" name="sp_commission" value="0">
                                    <input type="hidden" placeholder="Sales Person Commission Amount" class="form-control" name="sp_commission_amount" value="0">
                                </div>

                                <div class="col-md-3 sp-section" style="display: none">
                                    <label for="">Dealers</label>
                                        <select name="dealer_id" class="form-control selectpicker"
                                                data-container="body" data-live-search="true">
                                        <option value=""> Choose One</option>
                                        <?php if(isset($data)): ?>
                                            <?php $__currentLoopData = $data['dealers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dealer->id); ?>"><?php echo e($dealer->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="col-md-3 fl-section" style="display: none">
                                    <div class="form-group">
                                    <label for="">Free Lancer</label>
                                        <select name="freelancer_id" class="form-control selectpicker"
                                                data-container="body" data-live-search="true">
                                            <option value="" selected>Choose City</option>
                                            <?php if(isset($data)): ?>
                                                <?php $__currentLoopData = $data['freeLancers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $freeLancer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($freeLancer->id); ?>"><?php echo e($freeLancer->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                    </select>
                                    </div>
</div>

                                <div class="col-md-4">
                                    <label for="">Sale Inventory</label>
                                    <select name="inventory_type" class="form-control selectpicker" data-container="body" data-live-search="true" title="Choose Client" required>
                                        <option value="">Choose Ones</option>
                                        <option value="3" selected>All</option>
                                        <option value="1">Fresh</option>
                                        <option value="2">Buying Sale</option>
                                    </select>

                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                    <label for="">Remarks</label>
                                    <input type="text" class="form-control" placeholder="Remarks" name="remarks">
                                    <div class="invalid-feedback">
                                        Please choose client.
                                    </div>
                                    </div>
                                </div>

                            </div>

                        <div class="row">
                            <!-- tabel start -->
                            <table class="table table-bordered mt-5 table-style">
                                <thead>
                                <tr>
                                    <th>Items <span class="text-danger">*</span></th>
                                    <th>Unit <span class="text-danger">*</span></th>
                                    <th>Price <span class="text-danger">*</span></th>
                                    <th>Qty <span class="text-danger">*</span></th>
                                    <th>Gross <span class="text-danger"></span></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody id="tblPurchase">
                                <tr>
                                    <td>
                                        <select name="item_id[]" class="form-control  item-id inventory"  title="Choose Client" required>
                                            <option value="">Choose Item</option>





                                        </select>
                                    </td>
                                    <td><input type="text" class="form-control item-unit" placeholder="unit" name="item_unit[]" required readonly></td>
                                    <td><input type="number" class="form-control price" placeholder="0.00" name="price[]" required readonly></td>
                                    <td>
                                        <input type="number" class="form-control qty" placeholder="0.00" name="qty[]" required>
                                        <div class="qty-error"></div>
                                    </td>

                                    <td><input type="number" class="form-control total" placeholder="0.00" name="total[]" required readonly></td>
                                    <td><button type="button" class="btn-primary" id="addNewRow"><i class="fa fa-plus"></i></button> </td>
                                </tr>
                                </tbody>

                                <tbody id="footerSection">
                                <tr>
                                    <td  colspan="4">
                                        <div class="float-right">Discount :  &nbsp;
                                            % <input type="radio" name="discount" value="perc"> &nbsp;
                                            Amount <input type="radio" name="discount" value="amount">
                                        </div>
                                    </td>
                                    <td>
                                        <input type="hidden" class="form-control disc_amount" name="disc_amount" placeholder="Enter Discount Amount">
                                        <input type="hidden" class="form-control disc_perc" name="disc_perc" placeholder="Enter Discount %">
                                    </td>
                                    <td></td>
                                </tr>

                                <tr>
                                    <td  colspan="4">
                                        <div class="float-right">Net Total :</div>
                                    </td>
                                    <td><input type="number" class="form-control" placeholder="0.00" name="grand_total" ></td>

                                </tr>
                                </tbody>
                            </table>
                            <div class="col-md-10"></div>
                            <div class="col-md-2">
                            <button class="btn btn-primary pull-right btn-submit" id="btnSubmit" >Save</button>
                            </div>
                        </div>
                        </div>
                    </form>
            </div>
        </div>
        <!-- /Page Content -->
    </div>

    <script type="text/javascript">
        $(function () {
            $('#addNewRow').on('click', function () {
                var tr = $("#dvOrders").find("Table").find("TR:has(td)").clone();
                console.log(tr);
                $("#tblPurchase").append(tr);
            });
        });
    </script>
    <div id="dvOrders" style="display:none">
        <table class="table table-bordered mt-5 table-style secondtable " >
            <tr>
                <td>
                    <select name="item_id[]" id="" class="form-control item-id inventory" required>
                        <option value="">Choose Item</option>





                    </select>
                </td>
                <td><input type="text" class="form-control item-unit" placeholder="unit" name="item_unit[]" required readonly></td>
                <td><input type="number" class="form-control price" placeholder="0.00" name="price[]" required readonly></td>
                <td>
                    <input type="number" class="form-control qty" placeholder="0.00" name="qty[]" required>
                    <div class="qty-error"></div>
                </td>
                
                <td><input type="number" class="form-control total" placeholder="0.00" name="total[]" required></td>
                <td style="color:red;cursor: pointer" class="delete-row" title="Remove"><i class="fa fa-trash"></i></td>
            </tr>
        </table>
    </div>
    <script>
        $(document).ready(function(){

            //getting inventroy stock
            var inventory_type=$('select[name=inventory_type]').val();
            $.ajax({
                type: 'ajax',
                method: 'get',
                url: '<?php echo e(url("/getInventoryOntheBaseOfDealerGroup")); ?>',
                data: {inventory_type: inventory_type,sale_type:'dealer-sale'},
                async: false,
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    var html = '<option value="">Choose Item</option>';
                    var i;
                    if (data.length > 0) {
                        for (i = 0; i < data.length; i++) {
                            html += '<option value="' + data[i].id + '">' + data[i].products['item'] +'-'+ data[i].reg_no+ '</option>';
                        }
                    } else {
                        var html = '<option value="">Choose Item</option>';
                        toastr.error('data not found');
                    }
                    $('.inventory').html(html);

                },
                error: function() {
                }

            });
            //chek radio
            $("input[type='radio']").click(function(){
                var radioValue = $("input[name='discount']:checked").val();
                if(radioValue=='perc'){
                    $("input[name=disc_perc]").prop("type", "number");
                    $("input[name=disc_amount]").prop("type", "hidden");

                }else {
                    $("input[name=disc_perc]").prop("type", "hidden");
                    $("input[name=disc_amount]").prop("type", "number");
                }
            });
            $(".comm-radio-btn").click(function(){
                var radioValue = $("input[name='comm']:checked").val();
                if(radioValue==0){

                    $("input[name=sp_commission]").prop("type", "number");
                    $("input[name=sp_commission_amount]").prop("type", "hidden");

                }else {

                    $("input[name=sp_commission]").prop("type", "hidden");
                    $("input[name=sp_commission_amount]").prop("type", "number");
                }
            });
            $('select[name=customer_source]').change(function(){
                var customer_source=$('select[name=customer_source]').val();
                if(customer_source==1){
                    $(".leads-section").css("display", "block");
                }

                if(customer_source==2){
                    $(".leads-section").css("display", "none");
                }

            });
            $('select[name=lead_id]').change(function(){
                var lead_id =$('select[name=lead_id]').val();
                $.ajax({

                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url('getLeadsInfo')); ?>',
                    data: {lead_id: lead_id},
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {

                        $(".btnSubmit").prop("disabled", true);
                        $(".btnSubmit").html("loading...");

                    },
                    success: function(data) {
                        console.log(data);
                        if (data) {
                            $('input[name=customer_name]').val(data.leads.name);
                            $('input[name=customer_contact]').val(data.leads.contact);

                            $.each(data.city, function(key, city) {

                                $('select[name="customer_city"]')
                                    .append(
                                        `<option value="${city.id}" ${city.id == data.leads.city_id ? 'selected' : ''}>${city.city_name}</option>`
                                    )
                            });

                        }
                        if (data.errors) {
                            toastr.error(data.errors);
                        }
                    },

                    complete: function(data) {
                        $("#btnSubmit").html("Save");
                        $("#btnSubmit").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');

                    },

                });
            });
            $('select[name=sale_through]').change(function(){
                var sale_through=$('select[name=sale_through]').val();
                if(sale_through==1){
                    $(".sp-section").css("display", "block");
                    $(".fl-section").css("display", "none");
                }

                if(sale_through==2){
                    $(".fl-section").css("display", "block");
                    $(".sp-section").css("display", "none");
                }

            });

        });
    </script>

    <script>
        $(document).ready(function () {
            // Denotes total number of rows
            var rowIdx = 0;
            // jQuery button click event to remove a row.
            $('#tblPurchase').on('click', '.delete-row', function () {
                // Getting all the rows next to the row
                // containing the clicked button
                var child = $(this).closest('tr').nextAll();

                // Iterating across all the rows
                // obtained to change the index
                child.each(function () {

                    // Getting <tr> id.
                    var id = $(this).attr('id');

                    // Getting the <p> inside the .row-index class.
                    var idx = $(this).children('.row-index').children('p');

                    // Gets the row number from <tr> id.
                    var dig = parseInt(id.substring(1));

                    // Modifying row index.
                    idx.html(`Row ${dig - 1}`);

                    // Modifying row id.
                    $(this).attr('id', `R${dig - 1}`);
                });

                // Removing the current row.
                $(this).closest('tr').remove();

                // Decreasing total number of rows by 1.
                rowIdx--;
            });

        });
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type='text/javascript'>
        $(document).ready(function (){
            $('select[name=client_id]').change(function(){
                var client_id=$('select[name=client_id]').val();
                $("#client-info-section").css("display", "block");

                $.ajax({
                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getClientInfo")); ?>',
                    data: {client_id: client_id},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        $('#cnic').html(data.cnic);
                        $('#contact').html(data.contact);
                        $('#address').html(data.address);
                    },

                    error: function() {
                        //
                        // alert('Could not get Data from Database');

                    }

                });
            });
            //sale_through
            getClientData();
            function getClientData(){
                var client_id=$('select[name=client_id]').val();
                $("#client-info-section").css("display", "block");

                $.ajax({
                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getClientInfo")); ?>',
                    data: {client_id: client_id},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        $('#cnic').html(data.cnic);
                        $('#contact').html(data.contact);
                        $('#address').html(data.address);
                    },

                    error: function() {

                    }

                });
            }
            // calculation of current table
            $('#tblPurchase').on('change','.item-id', function() {

                var purchase_id=$(this).val();
                var $currentRow = $(this).closest('tr');
                $.ajax({
                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getProductPriceAndInfo")); ?>',
                    data: {purchase_id: purchase_id},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        $currentRow.find('.item-unit').val(data.products['unit']);
                        $currentRow.find('.price').val(data.sale_price);
                    },
                    error: function() {
                        toastr.error('Could not get Data from Database');
                    }
                });
            });
            // chek available qty
            $('#tblPurchase').on('keyup','.qty', function() {
                var qty=$(this).val();
                var $currentRow = $(this).closest('tr');
                var purchase_id = $currentRow.find('.item-id').val();


                $.ajax({
                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("/getAvailStock")); ?>',
                    data: {purchase_id: purchase_id},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        if(qty > data.avl_qty){
                            $("#btnSubmit").prop("disabled", true);
                            var p='<span style="color:red">stock not exist</span>';
                            $currentRow.find('.qty-error').html(p);


                        }else{
                            $("#btnSubmit").prop("disabled", false);
                            var p='';
                            $currentRow.find('.qty-error').html(p);
                        }

                    },

                    error: function() {

                        toastr.error('Could not get Data from Database');

                    }

                });



            });
            $('#tblPurchase').on('keyup','.qty', function() {
                var qty=$(this).val();

                var $currentRow = $(this).closest('tr');
                var price = $currentRow.find('.price').val();
                var total = parseFloat(price) * parseFloat(qty);
                $currentRow.find('.total').val(total);
                $currentRow.find('.net').val(total);
                grandTotal();


            });

            $('#tblPurchase').on('keyup','.discount', function() {
                var discount=$(this).val();
                var $currentRow = $(this).closest('tr');
                var total = $currentRow.find('.total').val();
                var net= parseFloat(total) - parseFloat(discount);

                $currentRow.find('.net').val(net);
                grandTotal();


            });
            $('#footerSection').on('keyup','.disc_amount', function() {

                var discount=$(this).val();
                var grandTotal=0;
                $(".total").each(function() {
                    var subTotal=$(this).val();
                    (subTotal)? grandTotal=parseFloat(grandTotal) + parseFloat(subTotal):'';

                });

                var total =$('input[name=grand_total]').val();
                if(discount > 0) {
                    var net = parseFloat(grandTotal) - parseFloat(discount);
                    $('input[name=grand_total]').val(net);
                }else{
                    $('input[name=grand_total]').val(grandTotal);
                }
            });

                //discount perc
            $('#footerSection').on('keyup','.disc_perc', function() {

                var discount_perc=$(this).val();

                var grandTotal=0;
                $(".total").each(function() {
                    var subTotal=$(this).val();
                    (subTotal)? grandTotal=parseFloat(grandTotal) + parseFloat(subTotal):'';

                });

                if(discount_perc > 0) {
                    var amount=(parseFloat(discount_perc) / parseFloat(100)) * parseFloat(grandTotal)
                    var net = parseFloat(grandTotal) - parseFloat(amount);

                    $('input[name=grand_total]').val(net);
                }else{
                    $('input[name=grand_total]').val(grandTotal);
                }
            });
                //footerSection
            function  grandTotal(){
                var grandTotal=0;
                $(".total").each(function() {
                    var subTotal=$(this).val();
                    (subTotal)? grandTotal=parseFloat(grandTotal) + parseFloat(subTotal):'';

                });

                $('input[name=grand_total]').val(grandTotal);
            }
            //save sale
            //purchase form submit
            $('#purchaseForm').unbind().on('submit', function(e) {
                e.preventDefault();
                var formData = $('#purchaseForm').serialize();
                $.ajax({
                    type: 'ajax',
                    method: 'post',
                    url: '<?php echo e(url("regular-sale")); ?>',
                    data: formData,
                    async: false,
                    dataType: 'json',
                    beforeSend: function() {
                        $(".btn-submit").prop("disabled", true);
                        $(".btn-submit").html("please wait...");
                    },
                    success: function(data) {
                        if (data.success) {
                            $('#purchaseForm')[0].reset();
                            toastr.success(data.success);
                        }
                        if (data.errors) {
                            toastr.error(data.errors);
                        }
                    },
                    complete : function(data){
                        $(".btn-submit").html("Save");
                        $(".btn-submit").prop("disabled", false);
                    },
                    error: function() {
                        toastr.error('something went wrong');
                    },
                });
            });

            // fetch account balance
            $('select[name=client_id]').on('change', function() {
                var ac_id=$('select[name=client_id]').val();
                $.ajax({
                    type: 'ajax',
                    method: 'get',
                    url: '<?php echo e(url("get-account-balance")); ?>',
                    data: {ac_id: ac_id,ac_type:'clients'},
                    async: false,
                    dataType: 'json',
                    success: function(data) {
                        $(".balance-section").css("display", "block");
                        $('input[name=balance]').val(data);
                    },
                    error: function() {
                        toastr.error('something went wrong');
                    }
                });
            });

        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('setup.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rgms\resources\views/accounts/sale/regular-sale.blade.php ENDPATH**/ ?>